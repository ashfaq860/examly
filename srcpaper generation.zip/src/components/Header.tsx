// src/components/Header.tsx
'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function Header() {
  const [open, setOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Initialize dark mode from localStorage or system preference
  useEffect(() => {
    const storedMode = localStorage.getItem('darkMode');
    if (storedMode !== null) {
      setDarkMode(storedMode === 'true');
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }
  }, []);

  // Apply dark mode class to document and save preference
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <header className="header-nav dark:bg-gray-900 transition-colors duration-300">
      <div className="container">
        <nav className="navbar navbar-expand-lg p-0">
          <Link className="navbar-brand me-3 dark:text-white" href="/">Examly</Link>
          
          {/* Dark Mode Toggle Button */}
          <button 
            onClick={toggleDarkMode}
            className="me-3 p-2 rounded-full focus:outline-none hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors duration-200"
            aria-label="Toggle dark mode"
          >
            {darkMode ? (
              <i className="bi bi-sun-fill text-yellow-400"></i>
            ) : (
              <i className="bi bi-moon-fill text-gray-700"></i>
            )}
          </button>

          <button
            className="navbar-toggler dark:text-white"
            type="button"
            onClick={() => setOpen(v => !v)}
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className={`collapse navbar-collapse ${open ? 'show' : ''}`}>
            <ul className="navbar-nav ms-auto align-items-lg-center">
              <li className="nav-item">
                <Link className="nav-link text-white dark:text-gray-300 pe-3 hover:text-primary dark:hover:text-primary-300 transition-colors" href="#features">Features</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white dark:text-gray-300 pe-3 hover:text-primary dark:hover:text-primary-300 transition-colors" href="#how">How it works</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white dark:text-gray-300 pe-3 hover:text-primary dark:hover:text-primary-300 transition-colors" href="#pricing">Pricing</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white dark:text-gray-300 pe-3 hover:text-primary dark:hover:text-primary-300 transition-colors" href="/auth/login">Login</Link>
              </li>
              <li className="nav-item ms-2">
                <Link className="btn btn-light btn-sm dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600" href="/auth/signup">Sign Up</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>

      <style jsx>{`
        .header-nav {
          background: linear-gradient(135deg, #3a7bd5 0%, #00d2ff 100%);
          padding: 15px 0;
          position: fixed;
          width: 100%;
          top: 0;
          z-index: 1000;
        }
        
        .dark .header-nav {
          background: linear-gradient(135deg, #1e3a8a 0%, #0369a1 100%);
        }
        
        .navbar-toggler-icon {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(255, 255, 255, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        
        .dark .navbar-toggler-icon {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(255, 255, 255, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
      `}</style>
    </header>
  );
}