'use client';
import { useState, useEffect } from 'react';
import AdminLayout from '../../../../components/AdminLayout';
import { supabase } from '../../../../lib/supabaseClient';
import { FiEdit, FiTrash2, FiPlus } from 'react-icons/fi';
import toast from 'react-hot-toast';

interface Class {
  id: string;
  name: string;
  description: string;
}

interface Subject {
  id: string;
  name: string;
  class_id: string;
}

interface Chapter {
  id: string;
  name: string;
  subject_id: string;
  chapterNo?: number;
  subject?: {
    id: string;
    name: string;
    class_subjects?: {
      class_id: string;
      classes?: {
        id: string;
        name: string;
        description: string;
      };
    }[];
  };
}

export default function ChapterManagement() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);

  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');

  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    class_id: '',
    subject_id: '',
    chapterNo: ''
  });

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('classes')
        .select('*')
        .order('name', { ascending: true });
      if (error) throw error;
      setClasses(data || []);
      if (data && data.length > 0) setSelectedClass(data[0].id);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load classes');
    }
  };

  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass);
    } else {
      setSubjects([]);
      setSelectedSubject('');
    }
  }, [selectedClass]);

  const fetchSubjects = async (classId: string) => {
    try {
      const { data, error } = await supabase
        .from('class_subjects')
        .select(`
          class_id,
          subjects (
            id,
            name
          )
        `)
        .eq('class_id', classId);
      if (error) throw error;

      const mapped = (data || []).map((row: any) => ({
        id: row.subjects.id,
        name: row.subjects.name,
        class_id: row.class_id
      }));

      setSubjects(mapped);
      if (mapped.length > 0) setSelectedSubject(mapped[0].id);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load subjects');
    }
  };

  useEffect(() => {
    fetchChapters(selectedClass, selectedSubject);
  }, [selectedClass, selectedSubject]);

  const fetchChapters = async (classId?: string, subjectId?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from('chapters')
        .select(`
          id,
          name,
          subject_id,
          chapterNo,
          subject:subjects (
            id,
            name,
            class_subjects (
              class_id,
              classes (
                id,
                name,
                description
              )
            )
          )
        `)
        .order('chapterNo', { ascending: true })
        .order('name', { ascending: true });

      if (subjectId) {
        query = query.eq('subject_id', subjectId);
      } else if (classId) {
        query = query.in(
          'subject_id',
          (
            await supabase
              .from('class_subjects')
              .select('subject_id')
              .eq('class_id', classId)
          ).data?.map((cs) => cs.subject_id) || []
        );
      }

      const { data, error } = await query;
      if (error) throw error;
      setChapters(data || []);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load chapters');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        name: formData.name,
        subject_id: formData.subject_id,
        chapterNo: formData.chapterNo ? Number(formData.chapterNo) : null
      };

      if (currentChapter) {
        const { error } = await supabase
          .from('chapters')
          .update(payload)
          .eq('id', currentChapter.id);
        if (error) throw error;
        toast.success('Chapter updated successfully');
      } else {
        const { error } = await supabase
          .from('chapters')
          .insert([payload]);
        if (error) throw error;
        toast.success('Chapter created successfully');
      }
      //setShowForm(false);
      setCurrentChapter(null);
      fetchChapters(selectedClass, selectedSubject);
    } catch (err) {
      console.error(err);
      toast.error('Failed to save chapter');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this chapter?')) return;
    try {
      await supabase.from('chapters').delete().eq('id', id);
      toast.success('Chapter deleted successfully');
      fetchChapters(selectedClass, selectedSubject);
    } catch (err) {
      console.error(err);
      toast.error('Failed to delete chapter');
    }
  };

  return (
    <AdminLayout activeTab="management">
      <div className="container py-4">
        <h2>Chapter Management</h2>

        {/* Filters */}
        <div className="row mb-4">
          <div className="col-md-6">
            <label className="form-label">Select Class</label>
            <select
              className="form-select"
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
            >
              {classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name}-{cls.description}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-6">
            <label className="form-label">Select Subject</label>
            <select
              className="form-select"
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
            >
              <option value="">All Subjects</option>
              {subjects.map((sub) => (
                <option key={sub.id} value={sub.id}>
                  {sub.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Header */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2>Chapters</h2>
          <button
            className="btn btn-primary"
            onClick={() => {
              setCurrentChapter(null);
              setFormData({
                name: '',
                class_id: selectedClass,
                subject_id: selectedSubject,
                chapterNo: ''
              });
              setShowForm(true);
            }}
          >
            <FiPlus className="me-1" /> Add Chapter
          </button>
        </div>

        {/* Form */}
        {showForm && (
          <div className="card mb-4">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-3">
                    <label className="form-label">Class *</label>
                    <select
                      className="form-select"
                      value={formData.class_id}
                      onChange={(e) => {
                        setFormData({
                          ...formData,
                          class_id: e.target.value,
                          subject_id: ''
                        });
                        fetchSubjects(e.target.value);
                      }}
                      required
                    >
                      <option value="">Select class</option>
                      {classes.map((cls) => (
                        <option key={cls.id} value={cls.id}>
                          {cls.name}-{cls.description}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-3">
                    <label className="form-label">Subject *</label>
                    <select
                      className="form-select"
                      value={formData.subject_id}
                      onChange={(e) =>
                        setFormData({ ...formData, subject_id: e.target.value })
                      }
                      required
                    >
                      <option value="">Select subject</option>
                      {subjects
                        .filter((sub) => sub.class_id === formData.class_id)
                        .map((sub) => (
                          <option key={sub.id} value={sub.id}>
                            {sub.name}
                          </option>
                        ))}
                    </select>
                  </div>
                  <div className="col-md-3">
                    <label className="form-label">Chapter No *</label>
                    <input
                      type="number"
                      className="form-control"
                      value={formData.chapterNo}
                      onChange={(e) =>
                        setFormData({ ...formData, chapterNo: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="col-md-3">
                    <label className="form-label">Chapter Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="col-12 d-flex justify-content-end gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => setShowForm(false)}
                      disabled={loading}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={loading}
                    >
                      {loading ? 'Saving...' : 'Save Chapter'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Table */}
        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : (
          <div className="card">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Class</th>
                      <th>Subject</th>
                      <th>Chapter No</th>
                      <th>Chapter</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chapters.length > 0 ? (
                      chapters.map((chapter, i) => (
                        <tr key={chapter.id}>
                          <td>{i + 1}</td>
                          <td>
                            {chapter.subject?.class_subjects?.[0]?.classes
                              ?.name || '-'}
                            -
                            {chapter.subject?.class_subjects?.[0]?.classes
                              ?.description || '-'}
                          </td>
                          <td>{chapter.subject?.name || '-'}</td>
                          <td>{chapter.chapterNo || '-'}</td>
                          <td>{chapter.name}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-primary me-2"
                              onClick={() => {
                                setCurrentChapter(chapter);
                                setFormData({
                                  name: chapter.name,
                                  class_id:
                                    chapter.subject?.class_subjects?.[0]
                                      ?.class_id || '',
                                  subject_id: chapter.subject_id,
                                  chapterNo: chapter.chapterNo?.toString() || ''
                                });
                                fetchSubjects(
                                  chapter.subject?.class_subjects?.[0]
                                    ?.class_id || ''
                                );
                                setShowForm(true);
                              }}
                            >
                              <FiEdit />
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              onClick={() => handleDelete(chapter.id)}
                            >
                              <FiTrash2 />
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="text-center py-4">
                          <div className="alert alert-info">
                            No chapters found
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
