// src/app/auth/login/page.tsx
'use client';
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import Cookies from 'js-cookie';
import Link from 'next/link';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // ✅ Redirect if already logged in
  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", session.user.id)
          .single();

        if (profile?.role === "admin") {
          router.replace("/admin");
        } else if (profile?.role === "teacher") {
          router.replace("/academy");
        }
      }
    };

    checkUser();
  }, [router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);

    // sign in with Supabase
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);

    if (error) {
      setErr(error.message);
      return;
    }

    // check user role from profiles table
    const userId = data.user?.id;
    let role = null;

    if (userId) {
      const { data: profile, error: pErr } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userId)
        .single();

      if (!pErr && profile) {
        role = profile.role;
      }
    }

    // Allow only teacher/admin login
    if (role === 'teacher' || role === 'admin') {
      // No need to store user or token in localStorage!
      // Set role cookie for middleware
      Cookies.set('role', role, { expires: 7, path: '/' });

      if (role === 'teacher') {
        router.push('/academy');
      } else {
        router.push('/admin');
      }
    } else if (role === 'student') {
      setErr('Access denied: Students cannot log in here.');
      await supabase.auth.signOut();
    } else {
      setErr('Access denied: Role not recognized.');
      await supabase.auth.signOut();
    }
  };

  return (
    <AuthLayout title="Welcome back" subtitle="Admin & Teacher Login">
      <form onSubmit={submit}>
        {err && <div className="alert alert-danger">{err}</div>}

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            required
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            required
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button className="btn btn-primary w-100" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign In'}
        </button>

        <div className="mt-3 d-flex justify-content-between small">
          <Link href="/auth/forgot-password">Forgot password?</Link>
          <Link href="/auth/signup">Create account</Link>
        </div>
      </form>
    </AuthLayout>
  );
}
