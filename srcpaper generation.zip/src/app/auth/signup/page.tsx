'use client';
import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import AuthLayout from '@/components/AuthLayout';
import { supabase } from '@/lib/supabaseClient';
import Link from 'next/link';
import toast from 'react-hot-toast';
export default function SignupPage() {
  const search = useSearchParams();
  const preRole = search?.get('role') ?? 'student';
  const [role, setRole] = useState(preRole);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    setRole(preRole);
  }, [preRole]);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    // Check if email already exists in profiles table
    const { data: existingProfile, error: fetchError } = await supabase.from('profiles').select('email').eq('email', email).single();

    if (fetchError && fetchError.code !== 'PGRST116') {
   console.error('Email check error:', fetchError);
   setMessage('Error checking email availability.');
   setLoading(false);
   return;
}

    if (existingProfile) {
      setMessage('Email already exists. Please login or use a different email.');
      setLoading(false);
      return;
    }

    // Proceed with signup if email is free
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { role } },
    });

    if (error) {
      setMessage(error.message);
      setLoading(false);
      return;
    }

    if (data.user) {
      // Call your server API to create profile with service key (bypasses RLS)
      try {
        const res = await fetch('/api/auth/create-profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: data.user.id,
            role,
            email: data.user.email,
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          console.error('API profile creation error:', err);
          setMessage('Signup succeeded, but profile creation failed.');
        }
      } catch (err) {
        console.error('Fetch error:', err);
        setMessage('Signup succeeded, but profile creation failed.');
      }
    } else {
      // Email confirmation required, profile creation deferred or done via webhook
      
      console.log('Email confirmation required. Profile creation deferred.');
    }

    setLoading(false);
    toast.success('Signup successful! Check your email for confirmation.');
    setMessage('Signup success — check your email if confirmation is required.');
    router.push('/auth/login');
  };

  return (
    <AuthLayout title="Create account" subtitle="Start with a student or teacher account">
      <form onSubmit={handleSignup}>
        {message && <div className="alert alert-info">{message}</div>}

        <div className="mb-3">
          <label className="form-label">Role</label>

          <select className="form-select" value={role} onChange={(e) => setRole(e.target.value)}>
           <option value="student">Student</option> 
            <option value="teacher">Teacher / Academy</option>
           
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            required
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            required
            minLength={6}
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button className="btn btn-primary w-100" disabled={loading}>
          {loading ? 'Creating…' : 'Create Account'}
        </button>

        <div className="mt-3 d-flex justify-content-between small">
          <Link href="/auth/login">Already have an account?</Link>
          <Link href="/auth/forgot-password" className="link-muted">
            Forgot password?
          </Link>
        </div>
      </form>
    </AuthLayout>
  );
}
