'use client';
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
//import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import Cookies from 'js-cookie';
import Link from 'next/link';
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
const supabase = createClientComponentClient();
  // ✅ Redirect if already logged in
  useEffect(() => {
    const checkUser = async () => {
      console.log('🔍 Checking for existing session...');
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      //console.log("My setting session",session);
      if (sessionError) {
        console.error('Session error:', sessionError);
        return;
      }

      if (session?.user) {
        console.log('✅ Session found, user ID:', session.user.id);
        
        try {
          console.log('🔍 Calling RPC function get_user_role...');
          const { data: roleData, error: rpcError } = await supabase
            .rpc('get_user_role', { user_id: session.user.id });

          console.log('📋 RPC response:', { 
            roleData, 
            rpcError,
            hasRoleData: !!roleData,
            hasError: !!rpcError 
          });

          if (!rpcError && roleData) {
            console.log('🎯 Role determined:', roleData);
            if (roleData === "admin" || roleData === "super_admin") {
              console.log('➡️ Redirecting to /admin');
              router.replace("/admin");
            } else if (roleData === "teacher" || roleData === "academy") {
              console.log('➡️ Redirecting to /dashboard');
              router.replace("/dashboard");
            } else {
              console.log('❌ Unhandled role:', roleData);
            }
          } else {
            console.log('❌ No valid role found or RPC error:', rpcError);
          }
        } catch (error) {
          console.error('💥 Error in RPC call:', error);
        }
      } else {
        console.log('❌ No active session found');
      }
    };

    //checkUser();
  }, [router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    console.log('🚀 Login attempt started');

    try {
      // sign in with Supabase
      console.log('🔐 Attempting sign in with:', email);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('❌ Sign in error:', error);
        setErr(error.message);
        setLoading(false);
        return;
      }

      console.log('✅ Login successful, user ID:', data.user?.id);

      // Use RPC function to get user role
      const userId = data.user?.id;
      if (!userId) {
        console.error('❌ No user ID found after login');
        setErr('User ID not found');
        setLoading(false);
        return;
      }

      console.log('🔍 Calling RPC function for user:', userId);
      const { data: roleData, error: rpcError } = await supabase
        .rpc('get_user_role', { user_id: userId });

      console.log('📋 RPC result:', { 
        roleData, 
        rpcError,
        hasData: !!roleData,
        hasError: !!rpcError 
      });

      if (rpcError) {
        console.error('❌ RPC Error details:', rpcError);
        setErr('Unable to verify user role. Please contact support.');
        await supabase.auth.signOut();
        setLoading(false);
        return;
      }

      if (!roleData) {
        console.error('❌ No role data returned from RPC');
        setErr('User role not found. Please contact support.');
        await supabase.auth.signOut();
        setLoading(false);
        return;
      }

      console.log('🎯 User role determined:', roleData);
      
      // Handle role-based redirect
      handleRoleRedirect(roleData);

    } catch (catchError) {
      console.error('💥 Unexpected error:', catchError);
      setErr('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRoleRedirect = (role: string) => {
    console.log('🔄 Handling redirect for role:', role);
    
    // Allow only specific roles to login
    const allowedRoles = ['teacher', 'admin', 'academy'];
    
    if (!allowedRoles.includes(role)) {
      console.log('❌ Access denied for role:', role);
      setErr('Access denied: Your role cannot access this portal.');
      supabase.auth.signOut();
      return;
    }

    // Set role cookie for middleware
    Cookies.set('role', role, { expires: 7, path: '/' });
    console.log('🍪 Role set in cookie:', role);

    if (role === 'teacher' || role === 'academy') {
    //  console.log('➡️ Redirecting to /academy');
      router.push('/dashboard');
    } else if (role === 'admin') {
     // console.log('➡️ Redirecting to /admin');
      router.push('/admin');
    }
  };

  return (
    <AuthLayout title="Welcome back" subtitle="Admin & Teacher Login">
      <form onSubmit={submit}>
        {err && <div className="alert alert-danger">{err}</div>}

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            required
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            required
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button className="btn btn-primary w-100" disabled={loading}>
          {loading ? 'Signing in…' : 'Sign In'}
        </button>

        <div className="mt-3 d-flex justify-content-between small">
          <Link href="/auth/forgot-password">Forgot password?</Link>
          <Link href="/auth/signup">Create account</Link>
        </div>
      </form>
    </AuthLayout>
  );
}