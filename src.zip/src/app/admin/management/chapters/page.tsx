'use client';
import { useState, useEffect } from 'react';
import AdminLayout from '@/components/AdminLayout';
import { supabase } from '@/lib/supabaseClient';
import { FiEdit, FiTrash2, FiPlus, FiFilter, FiX } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { useRouter } from "next/navigation";
import { isUserAdmin } from "@/lib/auth-utils";
interface Class {
  id: string;
  name: string;
  description: string;
}

interface Subject {
  id: string;
  name: string;
}

interface ClassSubject {
  id: string;
  class_id: string;
  subject_id: string;
  subject: Subject;
}

interface Chapter {
  id: string;
  name: string;
  subject_id: string | null;
  class_id: string | null;
  chapterNo?: number;
  subject?: Subject;
  classes?: Class;
}

export default function ChapterManagement() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [classSubjects, setClassSubjects] = useState<ClassSubject[]>([]);
  const [filteredSubjects, setFilteredSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);

  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');

  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    class_id: '',
    subject_id: '',
    chapterNo: ''
  });
const router= useRouter();

    // ✅ Check admin
    useEffect(() => {
      async function init() {
        setLoading(true);
        const admin = await isUserAdmin();
        if (!admin) {
          router.replace("/unauthorized");
          return;
        }
        setLoading(false);
      }
      init();
    }, [router]);

  useEffect(() => {
    fetchClasses();
    fetchAllSubjects();
    fetchClassSubjects();
  }, []);

  // Fetch all classes
  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('classes')
        .select('*')
        .order('name', { ascending: true });
      if (error) throw error;
      setClasses(data || []);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load classes');
    }
  };

  // Fetch all subjects
  const fetchAllSubjects = async () => {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name', { ascending: true });
      if (error) throw error;
      setAllSubjects(data || []);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load subjects');
    }
  };

  // Fetch class-subject relationships
  const fetchClassSubjects = async () => {
    try {
      const { data, error } = await supabase
        .from('class_subjects')
        .select(`
          id,
          class_id,
          subject_id,
          subject:subjects(*)
        `);
      
      if (error) throw error;
      setClassSubjects(data || []);
    } catch (err) {
      console.error(err);
      toast.error('Failed to load class-subject relationships');
    }
  };

  // Update filtered subjects when class selection changes
  useEffect(() => {
    if (selectedClass) {
      const subjectsForClass = classSubjects
        .filter(cs => cs.class_id === selectedClass)
        .map(cs => cs.subject);
      
      setFilteredSubjects(subjectsForClass);
      
      // Reset subject selection if the current subject is not in the filtered list
      if (selectedSubject && !subjectsForClass.some(sub => sub.id === selectedSubject)) {
        setSelectedSubject('');
      }
    } else {
      setFilteredSubjects(allSubjects);
    }
  }, [selectedClass, classSubjects, allSubjects, selectedSubject]);

  useEffect(() => {
    fetchChapters();
  }, [selectedClass, selectedSubject]);

  const fetchChapters = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('chapters')
        .select(`
          *,
          subject:subjects(*),
          class:classes(*)
        `)
        .order('chapterNo', { ascending: true });

      // Apply filters if selected
      if (selectedClass) {
        query = query.eq('class_id', selectedClass);
      }
      if (selectedSubject) {
        query = query.eq('subject_id', selectedSubject);
      }

      const { data, error } = await query;
      
      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }
      
      // Transform the data to match our interface
      const transformedData = data ? data.map(item => ({
        ...item,
        classes: item.class,
        subjects: item.subject
      })) : [];
      
      setChapters(transformedData);
    } catch (err) {
      console.error('Error fetching chapters:', err);
      toast.error('Failed to load chapters');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        name: formData.name,
        class_id: formData.class_id || null,
        subject_id: formData.subject_id || null,
        chapterNo: formData.chapterNo ? Number(formData.chapterNo) : null
      };

      if (currentChapter) {
        const { error } = await supabase
          .from('chapters')
          .update(payload)
          .eq('id', currentChapter.id);
        if (error) throw error;
        toast.success('Chapter updated successfully');
      } else {
        const { error } = await supabase
          .from('chapters')
          .insert([payload]);
        if (error) throw error;
        toast.success('Chapter created successfully');
      }
      
      setCurrentChapter(null);
      setFormData({
        name: '',
        class_id: '',
        subject_id: '',
        chapterNo: ''
      });
      setShowForm(false);
      fetchChapters();
    } catch (err) {
      console.error(err);
      toast.error('Failed to save chapter');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this chapter?')) return;
    try {
      const { error } = await supabase.from('chapters').delete().eq('id', id);
      if (error) throw error;
      toast.success('Chapter deleted successfully');
      fetchChapters();
    } catch (err) {
      console.error(err);
      toast.error('Failed to delete chapter');
    }
  };

  // Helper function to safely get values for form
  const getSafeValue = (value: string | null | undefined): string => {
    return value || '';
  };

  // Helper to get subject name by ID
  const getSubjectName = (subjectId: string | null): string => {
    if (!subjectId) return 'N/A';
    const subject = allSubjects.find(sub => sub.id === subjectId);
    return subject ? subject.name : 'N/A';
  };

  // Helper to get class name by ID
  const getClassName = (classId: string | null): string => {
    if (!classId) return 'N/A';
    const cls = classes.find(c => c.id === classId);
    return cls ? `${cls.name} - ${cls.description}` : 'N/A';
  };

  const clearFilters = () => {
    setSelectedClass('');
    setSelectedSubject('');
  };

  return (
    <AdminLayout activeTab="management">
      <div className="container py-4">
        <h2>Chapter Management</h2>

        {/* Filters */}
        <div className="card mb-4">
          <div className="card-body">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h5 className="card-title mb-0">
                <FiFilter className="me-2" />
                Filters
              </h5>
              {(selectedClass || selectedSubject) && (
                <button 
                  className="btn btn-sm btn-outline-secondary"
                  onClick={clearFilters}
                >
                  <FiX className="me-1" />
                  Clear Filters
                </button>
              )}
            </div>
            <div className="row g-3">
              <div className="col-md-6">
                <label className="form-label">Filter by Class</label>
                <select
                  className="form-select"
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                >
                  <option value="">All Classes</option>
                  {classes.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} - {cls.description}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-6">
                <label className="form-label">Filter by Subject</label>
                <select
                  className="form-select"
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  disabled={!selectedClass && filteredSubjects.length > 0}
                >
                  <option value="">All Subjects</option>
                  {filteredSubjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
                {!selectedClass && (
                  <div className="form-text">
                    Select a class first to see available subjects
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h3>Chapters</h3>
          <button
            className="btn btn-primary"
            onClick={() => {
              setCurrentChapter(null);
              setFormData({
                name: '',
                class_id: selectedClass || '',
                subject_id: selectedSubject || '',
                chapterNo: ''
              });
              setShowForm(true);
            }}
            disabled={!selectedClass}
          >
            <FiPlus className="me-1" /> Add Chapter
          </button>
          {!selectedClass && (
            <div className="form-text ms-2">
              Select a class to add a new chapter
            </div>
          )}
        </div>

        {/* Form */}
        {showForm && (
          <div className="card mb-4">
            <div className="card-body">
              <h5 className="card-title">
                {currentChapter ? 'Edit Chapter' : 'Add New Chapter'}
              </h5>
              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-4">
                    <label className="form-label">Class</label>
                    <select
                      className="form-select"
                      value={formData.class_id}
                      onChange={(e) =>
                        setFormData({ ...formData, class_id: e.target.value })
                      }
                    >
                      <option value="">Select Class (Optional)</option>
                      {classes.map((cls) => (
                        <option key={cls.id} value={cls.id}>
                          {cls.name} - {cls.description}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Subject</label>
                    <select
                      className="form-select"
                      value={formData.subject_id}
                      onChange={(e) =>
                        setFormData({ ...formData, subject_id: e.target.value })
                      }
                    >
                      <option value="">Select Subject (Optional)</option>
                      {filteredSubjects.map((sub) => (
                        <option key={sub.id} value={sub.id}>
                          {sub.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-2">
                    <label className="form-label">Chapter No</label>
                    <input
                      type="number"
                      className="form-control"
                      value={formData.chapterNo}
                      onChange={(e) =>
                        setFormData({ ...formData, chapterNo: e.target.value })
                      }
                      placeholder="Optional"
                    />
                  </div>
                  <div className="col-md-2">
                    <label className="form-label">Chapter Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                      placeholder="Required"
                    />
                  </div>
                  <div className="col-12 d-flex justify-content-end gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => {
                        setShowForm(false);
                        setCurrentChapter(null);
                      }}
                      disabled={loading}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={loading}
                    >
                      {loading ? 'Saving...' : currentChapter ? 'Update Chapter' : 'Save Chapter'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Table */}
        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : (
          <div className="card">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Class</th>
                      <th>Subject</th>
                      <th>Chapter No</th>
                      <th>Chapter Name</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chapters.length > 0 ? (
                      chapters.map((chapter, i) => (
                        <tr key={chapter.id}>
                          <td>{i + 1}</td>
                          <td>{getClassName(chapter.class_id)}</td>
                          <td>{getSubjectName(chapter.subject_id)}</td>
                          <td>{chapter.chapterNo || '-'}</td>
                          <td>{chapter.name}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-primary me-2"
                              onClick={() => {
                                setCurrentChapter(chapter);
                                setFormData({
                                  name: chapter.name,
                                  class_id: getSafeValue(chapter.class_id),
                                  subject_id: getSafeValue(chapter.subject_id),
                                  chapterNo: chapter.chapterNo?.toString() || ''
                                });
                                setShowForm(true);
                              }}
                            >
                              <FiEdit />
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              onClick={() => handleDelete(chapter.id)}
                            >
                              <FiTrash2 />
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="text-center py-4">
                          <div className="alert alert-info">
                            No chapters found. {selectedClass || selectedSubject ? 'Try changing your filters.' : 'Add a chapter to get started.'}
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}