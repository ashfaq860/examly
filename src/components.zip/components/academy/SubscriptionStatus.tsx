import React from 'react';

interface SubscriptionStatusProps {
  subscription: {
    type: string;
    status: string;
    endDate: string;
    papersLeft: number;
    isTrial: boolean;
    trialDaysLeft: number;
    totalPapersInPlan: number;
  };
}

const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({ subscription }) => {
  if (subscription.isTrial) {
    return (
      <div className="alert alert-warning mb-4">
        <div className="d-flex justify-content-between align-items-center">
          <div>
            <strong>Free Trial Active</strong>
            <div className="small">
              {subscription.trialDaysLeft} days remaining in your trial
            </div>
          </div>
          <button className="btn btn-sm btn-primary">
            Upgrade Now
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`alert ${subscription.status === 'active' ? 'alert-success' : 'alert-danger'} mb-4`}>
      <div className="d-flex justify-content-between align-items-center">
        <div>
          <strong>{subscription.type} Plan</strong>
          <div className="small">
            {subscription.status === 'active' ? (
              <>
                {subscription.papersLeft !== undefined ? (
                  <>{subscription.papersLeft} of {subscription.totalPapersInPlan} papers remaining (expires {subscription.endDate})</>
                ) : (
                  <>Active until {subscription.endDate}</>
                )}
              </>
            ) : (
              <>Expired on {subscription.endDate}</>
            )}
          </div>
        </div>
        {subscription.status === 'active' && (
          <button className="btn btn-sm btn-outline-secondary">
            Manage Subscription
          </button>
        )}
      </div>
    </div>
  );
};

export default SubscriptionStatus;