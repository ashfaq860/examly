"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

const Header = () => {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [role, setRole] = useState<string>("");
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        // Fetch role from profiles table
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", session.user.id)
          .single();
        if (profile?.role) setRole(profile.role);
      }
    };
    fetchUser();

    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest(".dropdown")) setShowDropdown(false);
    };

    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    document.cookie = "role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    router.push("/auth/login");
  };

  return (
    <header className="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
      <div className="container-fluid px-3">
        {/* Brand / Logo */}
        <Link
          className="navbar-brand fw-bold d-flex align-items-center"
          href="/academy"
        >
          <img
            src="/school-logo.png"
            alt="School Logo"
            height="40"
            className="me-2"
          />
          <span className="text-primary d-none d-sm-inline">
            Academy Dashboard
          </span>
        </Link>

        {/* User Dropdown */}
        <div className="dropdown ms-auto">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="d-flex align-items-center bg-transparent border-0 p-0"
          >
            <img
              src={user?.user_metadata?.avatar_url || "/user-avatar.jpg"}
              alt="User"
              width="40"
              height="40"
              className="rounded-circle border"
            />
          </button>

          {showDropdown && (
            <ul className="dropdown-menu dropdown-menu-end shadow-sm mt-2 show">
              <li className="px-3 py-2">
                <div className="fw-semibold">
                  {user?.user_metadata?.full_name || "Academy User"}
                </div>
                <small className="text-muted">{role || "academy"}</small>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>
              <li>
                <Link
                  className="dropdown-item"
                  href="/academy/profile"
                  onClick={() => setShowDropdown(false)}
                >
                  <i className="bi bi-person me-2"></i>Profile
                </Link>
              </li>
              <li>
                <Link
                  className="dropdown-item"
                  href="/academy/settings"
                  onClick={() => setShowDropdown(false)}
                >
                  <i className="bi bi-gear me-2"></i>Settings
                </Link>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>
              <li>
                <button
                  className="dropdown-item text-danger"
                  onClick={handleLogout}
                >
                  <i className="bi bi-box-arrow-right me-2"></i>Sign out
                </button>
              </li>
            </ul>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
