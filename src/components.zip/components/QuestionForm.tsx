// components/QuestionForm.tsx
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { FiX } from 'react-icons/fi';
import toast from 'react-hot-toast';

interface QuestionFormProps {
  question?: any;
  classes: any[];
  subjects: any[];
  chapters: any[];
  topics: any[];
  classSubjects: any[]; // { id, class_id, subject_id, ... }
  onClose: () => void;
}

export default function QuestionForm({
  question,
  classes,
  subjects,
  chapters,
  topics,
  classSubjects,
  onClose
}: QuestionFormProps) {
  const toId = (v: any) => (v === null || v === undefined ? '' : String(v));

  const [formData, setFormData] = useState({
    question_text: '',
    option_a: '',
    option_b: '',
    option_c: '',
    option_d: '',
    correct_option: '',
    class_id: '',
    subject_id: '',
    chapter_id: '',
    topic_id: '',
    difficulty: 'medium',
    question_type: 'mcq' as 'mcq' | 'short' | 'long',
    answer_text: '',
    source_type: 'book' as 'book' | 'past_paper' | 'model_paper' | 'custom',
    source_year: ''
  });

  const [filteredSubjects, setFilteredSubjects] = useState<any[]>([]);
  const [filteredChapters, setFilteredChapters] = useState<any[]>([]);
  const [filteredTopics, setFilteredTopics] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // ---- Initialize form (Edit mode) ----
  useEffect(() => {
    if (!question) return;

    // Prefer deriving class via class_subject_id (authoritative)
    const fromClassSubjectLink = classSubjects.find(
      (cs) => toId(cs.id) === toId(question.class_subject_id)
    );
    // Fallbacks if class_subject_id missing in question payload
    const fromSubjectMap = classSubjects.find(
      (cs) => toId(cs.subject_id) === toId(question.subject_id)
    );
    const fromSubjectJoin = toId(
      question.subject?.class_subjects?.[0]?.class_id
    );

    const derivedClassId =
      toId(fromClassSubjectLink?.class_id) ||
      toId(fromSubjectMap?.class_id) ||
      fromSubjectJoin ||
      '';

    setFormData({
      question_text: question.question_text || '',
      option_a: question.option_a || '',
      option_b: question.option_b || '',
      option_c: question.option_c || '',
      option_d: question.option_d || '',
      correct_option: question.correct_option || '',
      class_id: derivedClassId,
      subject_id: toId(question.subject_id) || '',
      chapter_id: toId(question.chapter_id) || '',
      topic_id: toId(question.topic_id) || '',
      difficulty: question.difficulty || 'medium',
      question_type: (question.question_type || 'mcq') as 'mcq' | 'short' | 'long',
      answer_text: question.answer_text || '',
      source_type: (question.source_type || 'book') as 'book' | 'past_paper' | 'model_paper' | 'custom',
      source_year: question.source_year ? String(question.source_year) : ''
    });
  }, [question, classSubjects]);

  // ---- Filter subjects when class changes ----
  useEffect(() => {
    const classId = formData.class_id;

    if (classId) {
      const subjectsForClass = subjects.filter((subj) =>
        classSubjects.some(
          (cs) => toId(cs.class_id) === classId && toId(cs.subject_id) === toId(subj.id)
        )
      );
      setFilteredSubjects(subjectsForClass);

      if (
        formData.subject_id &&
        !subjectsForClass.some((s) => toId(s.id) === formData.subject_id)
      ) {
        setFormData((prev) => ({ ...prev, subject_id: '', chapter_id: '', topic_id: '' }));
      }
    } else {
      setFilteredSubjects([]);
      if (formData.subject_id) {
        setFormData((prev) => ({ ...prev, subject_id: '', chapter_id: '', topic_id: '' }));
      }
    }
  }, [formData.class_id, subjects, classSubjects]);

  // ---- Filter chapters when subject changes ----
  useEffect(() => {
    const subjectId = formData.subject_id;

    if (subjectId) {
      const chaptersForSubject = chapters.filter(
        (c) => toId(c.subject_id) === subjectId
      );
      setFilteredChapters(chaptersForSubject);

      if (
        formData.chapter_id &&
        !chaptersForSubject.some((c) => toId(c.id) === formData.chapter_id)
      ) {
        setFormData((prev) => ({ ...prev, chapter_id: '', topic_id: '' }));
      }
    } else {
      setFilteredChapters([]);
      if (formData.chapter_id) {
        setFormData((prev) => ({ ...prev, chapter_id: '', topic_id: '' }));
      }
    }
  }, [formData.subject_id, chapters]);

  // ---- Filter topics when chapter changes ----
  useEffect(() => {
    const chapterId = formData.chapter_id;

    if (chapterId) {
      const topicsForChapter = topics.filter(
        (t) => toId(t.chapter_id) === chapterId
      );
      setFilteredTopics(topicsForChapter);

      if (
        formData.topic_id &&
        !topicsForChapter.some((t) => toId(t.id) === formData.topic_id)
      ) {
        setFormData((prev) => ({ ...prev, topic_id: '' }));
      }
    } else {
      setFilteredTopics([]);
      if (formData.topic_id) {
        setFormData((prev) => ({ ...prev, topic_id: '' }));
      }
    }
  }, [formData.chapter_id, topics]);

  // ---- Submit ----
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Determine class_subject_id for the selected class + subject
      const classSubject = classSubjects.find(
        (cs) =>
          toId(cs.class_id) === formData.class_id &&
          toId(cs.subject_id) === formData.subject_id
      );

      const payload = {
        question_text: formData.question_text,
        option_a: formData.question_type === 'mcq' ? formData.option_a : null,
        option_b: formData.question_type === 'mcq' ? formData.option_b : null,
        option_c: formData.question_type === 'mcq' ? formData.option_c : null,
        option_d: formData.question_type === 'mcq' ? formData.option_d : null,
        correct_option: formData.question_type === 'mcq' ? formData.correct_option : null,
        subject_id: formData.subject_id || null,
        chapter_id: formData.chapter_id || null,
        topic_id: formData.topic_id || null,
        difficulty: formData.difficulty,
        question_type: formData.question_type,
        answer_text: formData.question_type !== 'mcq' ? formData.answer_text : null,
        source_type: formData.source_type,
        source_year: formData.source_year ? parseInt(formData.source_year) : null,
        class_subject_id: classSubject ? classSubject.id : null,
      };

      if (question) {
        const { error } = await supabase
          .from('questions')
          .update(payload)
          .eq('id', question.id);
        if (error) throw error;
        toast.success('Question updated successfully');
      } else {
        const { error } = await supabase.from('questions').insert([payload]);
        if (error) throw error;
        toast.success('Question added successfully');
      }
    //  onClose();
    } catch (error) {
      console.error('Error saving question:', error);
      toast.error('Failed to save question');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="modal-header">
        <h5 className="modal-title">
          {question ? 'Edit Question' : 'Add New Question'}
        </h5>
        <button
          type="button"
          className="btn-close"
          onClick={onClose}
          disabled={loading}
        >
          <FiX />
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="modal-body">
          <div className="row g-3">
            {/* Question text */}
            <div className="col-md-12">
              <label className="form-label">Question Text *</label>
              <textarea
                className="form-control"
                rows={3}
                value={formData.question_text}
                onChange={(e) =>
                  setFormData({ ...formData, question_text: e.target.value })
                }
                required
              />
            </div>

            {/* Class */}
            <div className="col-md-6">
              <label className="form-label">Class *</label>
              <select
                className="form-select"
                value={formData.class_id}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    class_id: e.target.value,
                    subject_id: '',
                    chapter_id: '',
                    topic_id: '',
                  })
                }
                required
              >
                <option value="">Select Class</option>
                {classes.map((cls) => (
                  <option key={toId(cls.id)} value={toId(cls.id)}>
                    {cls.name}
                    {cls.description ? ` — ${cls.description}` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Subject */}
            <div className="col-md-6">
              <label className="form-label">Subject *</label>
              <select
                className="form-select"
                value={formData.subject_id}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    subject_id: e.target.value,
                    chapter_id: '',
                    topic_id: '',
                  })
                }
                required
                disabled={!formData.class_id}
              >
                <option value="">Select Subject</option>
                {filteredSubjects.map((subject) => (
                  <option key={toId(subject.id)} value={toId(subject.id)}>
                    {subject.name}
                    {subject.description ? ` — ${subject.description}` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Chapter */}
            <div className="col-md-6">
              <label className="form-label">Chapter</label>
              <select
                className="form-select"
                value={formData.chapter_id}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    chapter_id: e.target.value,
                    topic_id: '',
                  })
                }
                disabled={!formData.subject_id}
              >
                <option value="">Select Chapter</option>
                {filteredChapters.map((chapter) => (
                  <option key={toId(chapter.id)} value={toId(chapter.id)}>
                    {chapter.name}
                    {chapter.description ? ` — ${chapter.description}` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Topic */}
            <div className="col-md-6">
              <label className="form-label">Topic</label>
              <select
                className="form-select"
                value={formData.topic_id}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    topic_id: e.target.value,
                  })
                }
                disabled={!formData.chapter_id}
              >
                <option value="">Select Topic</option>
                {filteredTopics.map((topic) => (
                  <option key={toId(topic.id)} value={toId(topic.id)}>
                    {topic.name}
                    {topic.description ? ` — ${topic.description}` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Question Type */}
            <div className="col-md-6">
              <label className="form-label">Question Type *</label>
              <select
                className="form-select"
                value={formData.question_type}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    question_type: e.target.value as 'mcq' | 'short' | 'long',
                    correct_option: '',
                    answer_text: '',
                  })
                }
                required
              >
                <option value="mcq">Multiple Choice</option>
                <option value="short">Short Answer</option>
                <option value="long">Long Answer</option>
              </select>
            </div>

            {/* Difficulty */}
            <div className="col-md-6">
              <label className="form-label">Difficulty *</label>
              <select
                className="form-select"
                value={formData.difficulty}
                onChange={(e) =>
                  setFormData({ ...formData, difficulty: e.target.value as any })
                }
                required
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>

            {/* Source Type */}
            <div className="col-md-6">
              <label className="form-label">Source Type *</label>
              <select
                className="form-select"
                value={formData.source_type}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    source_type: e.target.value as any,
                    source_year:
                      e.target.value === 'book' ? '' : formData.source_year,
                  })
                }
                required
              >
                <option value="book">Book</option>
                <option value="past_paper">Past Paper</option>
                <option value="model_paper">Model Paper</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            {/* Source Year */}
            {['past_paper', 'model_paper'].includes(formData.source_type) && (
              <div className="col-md-6">
                <label className="form-label">Year</label>
                <input
                  type="number"
                  className="form-control"
                  value={formData.source_year}
                  onChange={(e) =>
                    setFormData({ ...formData, source_year: e.target.value })
                  }
                  min="1900"
                  max={new Date().getFullYear()}
                />
              </div>
            )}

            {/* MCQ Options */}
            {formData.question_type === 'mcq' && (
              <>
                <div className="col-md-6">
                  <label className="form-label">Option A *</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.option_a}
                    onChange={(e) =>
                      setFormData({ ...formData, option_a: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Option B *</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.option_b}
                    onChange={(e) =>
                      setFormData({ ...formData, option_b: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Option C</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.option_c}
                    onChange={(e) =>
                      setFormData({ ...formData, option_c: e.target.value })
                    }
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Option D</label>
                  <input
                    type="text"
                    className="form-control"
                    value={formData.option_d}
                    onChange={(e) =>
                      setFormData({ ...formData, option_d: e.target.value })
                    }
                  />
                </div>
                <div className="col-md-12">
                  <label className="form-label">Correct Option *</label>
                  <select
                    className="form-select"
                    value={formData.correct_option}
                    onChange={(e) =>
                      setFormData({ ...formData, correct_option: e.target.value })
                    }
                    required
                  >
                    <option value="">Select correct option</option>
                    <option value="A">Option A</option>
                    <option value="B">Option B</option>
                    {formData.option_c && <option value="C">Option C</option>}
                    {formData.option_d && <option value="D">Option D</option>}
                  </select>
                </div>
              </>
            )}

            {/* Short/Long Answer */}
            {(formData.question_type === 'short' ||
              formData.question_type === 'long') && (
              <div className="col-md-12">
                <label className="form-label">Answer Text *</label>
                <textarea
                  className="form-control"
                  rows={3}
                  value={formData.answer_text}
                  onChange={(e) =>
                    setFormData({ ...formData, answer_text: e.target.value })
                  }
                  required
                />
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onClose}
            disabled={loading}
          >
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Saving...' : 'Save Question'}
          </button>
        </div>
      </form>
    </>
  );
}
