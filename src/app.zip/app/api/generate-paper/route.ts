
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300; // 5 minutes
import fontkit from '@pdf-lib/fontkit';
import fs from 'fs';
import path from 'path';
import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import type { PaperGenerationRequest } from '@/types/types';
import { createCanvas, registerFont } from 'canvas';
   // Validate required fields
    // Function to fix Urdu character rendering issues
function fixUrduText(text: string): string {
  if (!text) return text;
  
  // Normalize the text to ensure consistent representation
  let fixedText = text.normalize('NFC');
  
  // Keep zero-width joiners as they help with character joining
  // Only remove problematic characters
  fixedText = fixedText.replace(/\u200e/g, ''); // Remove left-to-right mark
  fixedText = fixedText.replace(/\u200f/g, ''); // Remove right-to-left mark
  
  // Fix common character substitution issues
  // Replace specific problematic character sequences if needed
  const replacements: [RegExp, string][] = [
    // Basic Arabic to Urdu character replacements
    [/\u0643\u0647/g, '\u06A9\u06BE'], // Replace ك + ه with proper کھ
    [/\u064A/g, '\u06CC'],             // Replace Arabic Ya with Farsi Ya
    [/\u0649/g, '\u06CC'],             // Replace Arabic Alef Maksura with Farsi Ya
    [/\u0643/g, '\u06A9'],             // Replace Arabic Kaf with Urdu Kaf
    [/\u0647\u0640/g, '\u06C1'],       // Fix final Heh
    [/\u0647$/g, '\u06C1'],            // Fix final Heh at end of word
    [/\u0647([^\u0627\u0648\u06CC\u06D2])/g, '\u06C1$1'], // Fix medial Heh
    
    // Fix specific ligatures
    [/\u0644\u0627/g, '\u0644\u0627'],  // Fix Lam-Alif ligature
    [/\u0628\u0647/g, '\u0628\u06BE'],  // Fix Beh + Heh
    [/\u062A\u0647/g, '\u062A\u06BE'],  // Fix Teh + Heh
    [/\u062C\u0647/g, '\u062C\u06BE'],  // Fix Jeem + Heh
    [/\u062F\u0647/g, '\u062F\u06BE'],  // Fix Dal + Heh
    [/\u0631\u0647/g, '\u0631\u06BE'],  // Fix Reh + Heh
    
    // Additional Urdu-specific characters
    [/\u0639\u06CC/g, '\u0639\u06CC'],  // Fix Ain + Yeh
    [/\u063A\u06CC/g, '\u063A\u06CC'],  // Fix Ghain + Yeh
    
    // Fix spacing and word boundaries
    [/ +/g, ' '],                     // Normalize spaces
  ];
  
  for (const [pattern, replacement] of replacements) {
    fixedText = fixedText.replace(pattern, replacement);
  }
  
  // Add zero-width joiners between certain character pairs to force joining
  // This is crucial for proper character joining in Urdu
  const joiningChars = '\u0628\u062A\u062B\u062C\u062D\u062E\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0644\u0645\u0646\u0647\u064A\u06A9\u06AF\u06C1\u06BE\u06CC';
  const followingChars = '\u0627\u0648\u06D2\u06CC';
  
  // Add joiners between characters
  for (let i = 0; i < fixedText.length - 1; i++) {
    if (joiningChars.includes(fixedText[i]) && followingChars.includes(fixedText[i+1])) {
      fixedText = fixedText.substring(0, i+1) + '\u200D' + fixedText.substring(i+1);
      i++; // Skip the inserted joiner
    }
  }
  
  // Normalize again after all replacements
  fixedText = fixedText.normalize('NFC');
  
  return fixedText;
}
    
    async function translateToUrdu(text: string): Promise<string> {
      try {
        console.log('Translating to Urdu:', text);
        
        // If text is empty or null, return empty string
        if (!text || text.trim() === '') {
          console.log('Empty text provided for translation');
          return '';
        }
        
        // For debugging - return original text without translation
        // Uncomment this line to bypass translation API for testing
        // return `${text} (ترجمہ)`;
        
        // Fallback translations for common terms to avoid API issues
        const fallbackTranslations: Record<string, string> = {
          'Artificial Intelligence': 'مصنوعی ذہانت',
          'AI': 'مصنوعی ذہانت',
          'Machine Learning': 'مشین لرننگ',
          'Deep Learning': 'ڈیپ لرننگ',
          'Computer Vision': 'کمپیوٹر ویژن',
          'Natural Language Processing': 'قدرتی زبان پروسیسنگ',
          'Robotics': 'روبوٹکس',
          'Data Science': 'ڈیٹا سائنس',
          'Big Data': 'بڑا ڈیٹا',
          'Internet of Things': 'انٹرنیٹ آف تھنگز',
          'IoT': 'انٹرنیٹ آف تھنگز',
          'Cloud Computing': 'کلاؤڈ کمپیوٹنگ',
          'Blockchain': 'بلاکچین',
          'Virtual Reality': 'ورچوئل ریئلٹی',
          'VR': 'ورچوئل ریئلٹی',
          'Augmented Reality': 'آگمینٹڈ ریئلٹی',
          'AR': 'آگمینٹڈ ریئلٹی',
          'Self-driving cars': 'خود ڈرائیونگ کاریں',
          'Autonomous vehicles': 'خود مختار گاڑیاں',
          'Facial recognition': 'چہرے کی شناخت',
          'Voice assistants': 'آواز اسسٹنٹس',
          'Smart home': 'سمارٹ گھر',
          'Cybersecurity': 'سائبر سیکیورٹی',
          'Encryption': 'انکرپشن',
          'Algorithm': 'الگورتھم',
          'Neural Network': 'نیورل نیٹ ورک',
          'Quantum Computing': 'کوانٹم کمپیوٹنگ',
          'Data Mining': 'ڈیٹا مائننگ',
          'Automation': 'آٹومیشن',
          'Digital Transformation': 'ڈیجیٹل ٹرانسفارمیشن',
          'Explain': 'وضاحت کریں',
          'Describe': 'بیان کریں',
          'Define': 'تعریف کریں',
          'What is': 'کیا ہے',
          'How does': 'کیسے',
          'Why is': 'کیوں ہے'
        };
        
        // Check if we have a direct fallback translation
        if (fallbackTranslations[text]) {
          console.log('Using fallback translation for:', text);
          return fallbackTranslations[text];
        }
        
        // Check if text contains any of our fallback keys and replace them
        let modifiedText = text;
        for (const [key, value] of Object.entries(fallbackTranslations)) {
          if (text.includes(key)) {
            modifiedText = modifiedText.replace(new RegExp(key, 'g'), value);
          }
        }
        
        // If we've made replacements, return the modified text
        if (modifiedText !== text) {
          console.log('Using partial fallback translation for:', text);
          return modifiedText;
        }
        
        try {
          const res = await fetch(
            'https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ur&dt=t&q=' +
              encodeURIComponent(text)
          );
          
          if (!res.ok) {
            console.error(`Translation API error: ${res.status} ${res.statusText}`);
            return `ترجمہ ناکام: ${text}`; // Translation failed: [original text]
          }
          
          const data = await res.json();
          console.log('Translation API response:', JSON.stringify(data).substring(0, 200) + '...');
          
          // Google Translate API returns a nested array structure
          // The first element contains translation segments
          // Each segment is an array where the first element is the translated text
          let translatedText = '';
          
          if (data && data[0] && Array.isArray(data[0])) {
            // Concatenate all translation segments
            translatedText = data[0]
              .filter(segment => Array.isArray(segment) && segment[0])
              .map(segment => segment[0])
              .join('');
            
            console.log('Translated text before fixes:', translatedText);
          } else {
            console.error('Unexpected translation API response format:', data);
            return `ترجمہ فارمیٹ غلط: ${text}`; // Translation format error: [original text]
          }
          
          // Apply Urdu text fixes
          if (translatedText) {
            translatedText = fixUrduText(translatedText);
            console.log('Translated text after fixes:', translatedText);
            return translatedText;
          } else {
            console.error('Empty translation result');
            return `خالی ترجمہ: ${text}`; // Empty translation: [original text]
          }
        } catch (apiError) {
          console.error('Translation API error:', apiError);
          // If API fails, return a basic translation with the original text
          return `${text} (ترجمہ دستیاب نہیں)`; // [original text] (translation not available)
        }
      } catch (error) {
        console.error('Translation error:', error);
        return `ترجمہ خرابی: ${text}`; // Translation error: [original text]
      }
    }
export async function POST(request: Request) {
  console.log('POST request received to generate paper');
  const token = request.headers.get('Authorization')?.split(' ')[1];
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { global: { headers: { Authorization: `Bearer ${token}` } } }
  );

  const { data: { user } } = await supabase.auth.getUser(token);

  if (!user) {
    console.error('Unauthorized request - no user found');
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  
  console.log('User authenticated:', user.id);

  try {
    const requestData: PaperGenerationRequest = await request.json();
const { language } = requestData
 
    if (!requestData.title || !requestData.subjectId) {
      return NextResponse.json(
        { error: 'Title and subject ID are required' },
        { status: 400 }
      );
    }

    // Create paper record
    const { data: paper, error: paperError } = await supabase
      .from('papers')
      .insert({
        title: requestData.title,
        subject_id: requestData.subjectId,
        created_by: user.id,
        paper_type: requestData.paperType || 'custom',
        chapter_ids: requestData.chapterOption === 'custom'
          ? requestData.selectedChapters
          : null,
        difficulty: requestData.difficulty || 'medium',
        is_trial: requestData.isTrial || false
      })
      .select()
      .single();

    if (paperError) {
      console.error('Paper insert error:', paperError);
      throw paperError;
    }

    // Determine chapters to include
    let chapterIds: string[] = [];
    if (requestData.chapterOption === 'full_book') {
      const { data: chapters, error: chaptersError } = await supabase
        .from('chapters')
        .select('id')
        .eq('subject_id', requestData.subjectId);

      if (chaptersError) throw chaptersError;
      chapterIds = chapters.map(c => c.id);
    } else if (requestData.chapterOption === 'custom' && requestData.selectedChapters) {
      chapterIds = requestData.selectedChapters;
    }

    // Process question types
    const questionInserts = [];
    const questionTypes = [
      { type: 'mcq', count: requestData.mcqCount, difficulty: requestData.mcqDifficulty },
      { type: 'short', count: requestData.shortCount, difficulty: requestData.shortDifficulty },
      { type: 'long', count: requestData.longCount, difficulty: requestData.longDifficulty }
    ];

    for (const qType of questionTypes) {
      if (qType.count > 0) {
        let query = supabase
          .from('questions')
          .select('id')
          .eq('question_type', qType.type)
          .eq('subject_id', requestData.subjectId)
          .limit(qType.count);

        if (chapterIds.length > 0) {
          query = query.in('chapter_id', chapterIds);
        }
        if (qType.difficulty !== 'any') {
          query = query.eq('difficulty', qType.difficulty);
        }

        const { data: questions, error: questionsError } = await query;

        if (questionsError) throw questionsError;

        questions.forEach((q, index) => {
          questionInserts.push({
            paper_id: paper.id,
            question_id: q.id,
            order_number: questionInserts.length + 1,
            question_type: qType.type
          });
        });
      }
    }

    // Insert paper questions in batch
    if (questionInserts.length > 0) {
      const { error: insertError } = await supabase
        .from('paper_questions')
        .insert(questionInserts);

      if (insertError) throw insertError;
    }

    // After inserting paper and paper_questions, fetch all questions for this paper:
    const { data: paperQuestions, error: pqError } = await supabase
      .from('paper_questions')
      .select('order_number, question_type, question_id, questions (question_text, option_a, option_b, option_c, option_d)')
      .eq('paper_id', paper.id)
      .order('order_number', { ascending: true });

    if (pqError) throw pqError;

    // Generate PDF
    const pdfDoc = await PDFDocument.create();
    pdfDoc.registerFontkit(fontkit);
    const page = pdfDoc.addPage();
    const { width, height } = page.getSize();
    //const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
// Use unicode Urdu-supported font
let font;
let fontPath;

// Function to register and load a custom font
async function loadCustomFont(fontPath: string) {
  try {
    console.log('Loading font from:', fontPath);
    const fontBytes = fs.readFileSync(fontPath);
    const fontName = path.basename(fontPath, path.extname(fontPath));
    
    // Disable subsetting to ensure all glyphs are included
    return await pdfDoc.embedFont(fontBytes, { 
      subset: false, 
      customName: fontName 
    });
  } catch (error) {
    console.error(`Error loading font from ${fontPath}:`, error);
    return null;
  }
}

// Helper function to safely draw text, handling null/undefined/empty values
function safeDrawText(page: PDFPage, text: string | null | undefined, options: any) {
  // Only draw if text exists and is not empty
  if (text && text.trim().length > 0) {
    // Check if text contains only placeholder characters (P)
    const isPlaceholder = /^P+\s*P+:?\s*P+\s*\(.*\)$/.test(text) || /^\[?P+\]?$/.test(text);
    if (isPlaceholder) {
      console.warn('Detected placeholder text, not rendering:', text);
      try {
        page.drawText('[Content unavailable]', {
          ...options,
          direction: 'ltr' as const // Force LTR for error message
        });
      } catch (innerError) {
        console.error('Failed to draw placeholder message', innerError);
      }
      return;
    }
    
    try {
      // Log the text being drawn for debugging
      console.log(`Drawing text at (${options.x}, ${options.y}): ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`);
      page.drawText(text, options);
    } catch (error) {
      console.error(`Error drawing text: "${text}"`, error);
      // Try to draw a placeholder if the original text fails
      try {
        page.drawText('[Text rendering error]', {
          ...options,
          direction: 'ltr' as const // Force LTR for error message
        });
      } catch (innerError) {
        console.error('Failed to draw error placeholder text', innerError);
      }
    }
  } else {
    console.log('Skipping empty or null text');
  }
}

try {
  // Try multiple fonts in order of preference
  const fontPaths = [
    './public/fonts/NotoNastaliqUrdu-Regular.ttf',
    './examly/public/fonts/NotoNastaliqUrdu-Regular.ttf',
    './public/fonts/Jameel Noori Nastaleeq Kasheeda.ttf',
    './examly/public/fonts/Jameel Noori Nastaleeq Kasheeda.ttf',
    './public/fonts/Scheherazade-Regular.ttf',
    './examly/public/fonts/Scheherazade-Regular.ttf'
  ];
  
  // Try each font in order until one works
  for (const relativePath of fontPaths) {
    const absolutePath = path.resolve(relativePath);
    if (fs.existsSync(absolutePath)) {
      const loadedFont = await loadCustomFont(absolutePath);
      if (loadedFont) {
        font = loadedFont;
        fontPath = absolutePath;
        console.log('Successfully loaded font:', path.basename(absolutePath));
        break;
      }
    }
  }
  
  // If no font was loaded, fall back to Helvetica
  if (!font) {
    console.warn('No Urdu fonts found, falling back to Helvetica');
    font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  }
} catch (error) {
  console.error('Error in font loading process:', error);
  // Fallback to standard font if Urdu font fails to load
  font = await pdfDoc.embedFont(StandardFonts.Helvetica);
}


    let y = height - 50;
    
    // For Urdu text, we need to handle right-to-left text direction
    const isUrdu = language === 'urdu';
    
    // Translate title if needed
    let title = paper.title;
    if (language === 'urdu' || language === 'bilingual') {
      const urTitle = await translateToUrdu(title);
      // Apply additional fixes to ensure proper rendering
      const fixedUrTitle = fixUrduText(urTitle);
      title = language === 'bilingual' ? `${title} (${fixedUrTitle})` : fixedUrTitle;
    }
    
    if (isUrdu) {
      // For Urdu, draw the title prefix and title text separately
      // First draw the title prefix left-aligned
      safeDrawText(page, 'Paper Title: ', {
        x: 50,
        y,
        size: 18,
        font,
        color: rgb(0, 0, 0)
      });
      
      // Then draw the Urdu title right-aligned
      // For Urdu text, we need to handle it specially to ensure proper joining
      // Draw the text with proper RTL direction and increased spacing
      safeDrawText(page, title, {
        x: width - 50,
        y,
        size: 18,
        font,
        color: rgb(0, 0, 0),
        direction: 'rtl' as const,
        lineHeight: 24, // Add more line height for Urdu text
        wordSpacing: 0.5 // Add slight word spacing to improve readability
      });
      
      // Log the text being drawn to help with debugging
      console.log('Drawing Urdu title:', title);
    } else {
      // For non-Urdu, draw the title normally
      safeDrawText(page, `Paper Title: ${title}`, {
        x: 50,
        y,
        size: 18,
        font,
        color: rgb(0, 0, 0)
      });
    }
    y -= 30;

  for (const pq of paperQuestions) {
  const q = pq.questions;

  // Handle translation
  let qt = q.question_text;
  let optA = q.option_a;
  let optB = q.option_b;
  let optC = q.option_c;
  let optD = q.option_d;

  if (language === 'urdu' || language === 'bilingual') {
    // Translate question text
    const ur = await translateToUrdu(qt);
    // Apply additional fixes to ensure proper rendering
    const fixedUr = fixUrduText(ur);
    qt = language === 'bilingual' ? `${qt} (${fixedUr})` : fixedUr;

    // Translate and fix option A
    if (optA) {
      const urA = await translateToUrdu(optA);
      const fixedUrA = fixUrduText(urA);
      optA = language === 'bilingual' ? `${optA} (${fixedUrA})` : fixedUrA;
    }
    
    // Translate and fix option B
    if (optB) {
      const urB = await translateToUrdu(optB);
      const fixedUrB = fixUrduText(urB);
      optB = language === 'bilingual' ? `${optB} (${fixedUrB})` : fixedUrB;
    }
    
    // Translate and fix option C
    if (optC) {
      const urC = await translateToUrdu(optC);
      const fixedUrC = fixUrduText(urC);
      optC = language === 'bilingual' ? `${optC} (${fixedUrC})` : fixedUrC;
    }
    
    // Translate and fix option D
    if (optD) {
      const urD = await translateToUrdu(optD);
      const fixedUrD = fixUrduText(urD);
      optD = language === 'bilingual' ? `${optD} (${fixedUrD})` : fixedUrD;
    }
  }

  // For Urdu text, we need to handle right-to-left text direction
  const isUrdu = language === 'urdu';
  
  // Create a separate text for the question number and type (always left-to-right)
  const questionPrefix = `${pq.order_number}. [${pq.question_type.toUpperCase()}] `;
  
  if (isUrdu) {
    // For Urdu, draw the question prefix (LTR) and question text (RTL) separately
    // First draw the question prefix (numbers and English text) left-aligned
    safeDrawText(page, questionPrefix, {
      x: 50,
      y,
      size: 12,
      font,
      color: rgb(0, 0, 0)
    });
    
    // Then draw the Urdu text right-aligned
    // Calculate width to position the text properly if qt exists
    if (qt) {
      const textWidth = font.widthOfTextAtSize(qt, 12);
    }
    
    // Log the question text being drawn to help with debugging
    console.log('Drawing Urdu question:', qt);
    
    // Use safeDrawText to handle null/undefined/empty values
    safeDrawText(page, qt, {
      x: width - 50,
      y,
      size: 12,
      font,
      color: rgb(0, 0, 0),
      direction: 'rtl' as const,
      lineHeight: 18, // Add more line height for Urdu text
      wordSpacing: 0.5 // Add slight word spacing to improve readability
    });
  } else {
    // For non-Urdu, draw the full text normally
    const text = `${questionPrefix}${qt}`;
    safeDrawText(page, text, {
      x: 50,
      y,
      size: 12,
      font,
      color: rgb(0, 0, 0)
    });
  }
  y -= 20;

  if (pq.question_type === 'mcq') {
    // Handle MCQ options with proper text direction
    if (isUrdu) {
      // For Urdu, draw option letter (LTR) and option text (RTL) separately
      if (optA) {
        // Draw option letter left-aligned
        safeDrawText(page, 'A) ', {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        
        // Draw Urdu option text right-aligned
        // Log the option text being drawn to help with debugging
        console.log('Drawing Urdu option A:', optA);
        
        // Use safeDrawText to handle null/undefined/empty values
        safeDrawText(page, optA, {
          x: width - 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0),
          direction: 'rtl' as const,
          lineHeight: 15, // Add more line height for Urdu text
          wordSpacing: 0.5 // Add slight word spacing to improve readability
        });
        y -= 15;
      }
      
      if (optB) {
        safeDrawText(page, 'B) ', {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        
        // Log the option text being drawn to help with debugging
        console.log('Drawing Urdu option B:', optB);
        
        // Use safeDrawText to handle null/undefined/empty values
        safeDrawText(page, optB, {
          x: width - 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0),
          direction: 'rtl' as const,
          lineHeight: 15, // Add more line height for Urdu text
          wordSpacing: 0.5 // Add slight word spacing to improve readability
        });
        y -= 15;
      }
      
      if (optC) {
        safeDrawText(page, 'C) ', {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        
        // Log the option text being drawn to help with debugging
        console.log('Drawing Urdu option C:', optC);
        
        // Use safeDrawText to handle null/undefined/empty values
        safeDrawText(page, optC, {
          x: width - 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0),
          direction: 'rtl' as const,
          lineHeight: 15, // Add more line height for Urdu text
          wordSpacing: 0.5 // Add slight word spacing to improve readability
        });
        y -= 15;
      }
      
      if (optD) {
        safeDrawText(page, 'D) ', {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        
        // Log the option text being drawn to help with debugging
        console.log('Drawing Urdu option D:', optD);
        
        // Use safeDrawText to handle null/undefined/empty values
        safeDrawText(page, optD, {
          x: width - 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0),
          direction: 'rtl' as const,
          lineHeight: 15, // Add more line height for Urdu text
          wordSpacing: 0.5 // Add slight word spacing to improve readability
        });
        y -= 15;
      }
    } else {
      // For non-Urdu, draw options normally
      if (optA) {
        safeDrawText(page, `A) ${optA}`, {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        y -= 15;
      }
      
      if (optB) {
        safeDrawText(page, `B) ${optB}`, {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        y -= 15;
      }
      
      if (optC) {
        safeDrawText(page, `C) ${optC}`, {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        y -= 15;
      }
      
      if (optD) {
        safeDrawText(page, `D) ${optD}`, {
          x: 70,
          y,
          size: 11,
          font,
          color: rgb(0, 0, 0)
        });
        y -= 15;
      }
    }
  }
  y -= 10;
  if (y < 60) { y = height - 50; pdfDoc.addPage(); }
}


    // Log before saving PDF
    console.log('Saving PDF document...');
    const pdfBytes = await pdfDoc.save();
    console.log('PDF document saved successfully, size:', pdfBytes.length, 'bytes');

    // Create buffer from PDF bytes
    const buffer = Buffer.from(pdfBytes);
    console.log('Buffer created, size:', buffer.length, 'bytes');
    
    // For debugging - return a simple JSON response instead of PDF
    // This helps identify if the issue is with PDF generation or response handling
    //return NextResponse.json({ success: true, message: 'PDF generated successfully', size: buffer.length }, { status: 200 });
    
    // Comment out the PDF response for debugging
 
    // Return the PDF as a response with explicit headers
    const response = new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="paper.pdf"`,
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'no-cache'
      },
    });
    
    console.log('Returning PDF response with headers:', response.headers);
    return response;
 

  } catch (error) {
    console.error('Paper generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate paper', details: error instanceof Error ? error.message : JSON.stringify(error) },
      { status: 500 }
    );
  }
}

