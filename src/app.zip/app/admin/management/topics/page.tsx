'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import AdminLayout from '@/components/AdminLayout';
import { toast } from 'react-hot-toast';

export default function TopicsPage() {
  const [topics, setTopics] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [chapters, setChapters] = useState([]);

  const [filters, setFilters] = useState({ classId: '', subjectId: '', chapterId: '' });

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    classId: '',
    subjectId: '',
    chapterId: '',
  });

  const [loading, setLoading] = useState(false);

  // Fetch classes
  const fetchClasses = async () => {
    const { data, error } = await supabase.from('classes').select('*').order('name');
    if (error) toast.error(error.message);
    else setClasses(data);
  };

  // Fetch subjects
  const fetchSubjects = async () => {
    const { data, error } = await supabase
      .from('subjects')
      .select(`
        *,
        class_subjects!inner(class_id)
      `)
      .order('name');
    if (error) toast.error(error.message);
    else setSubjects(data.map(s => ({
      ...s,
      class_id: s.class_subjects?.[0]?.class_id || null
    })));
  };

  // Fetch chapters
  const fetchChapters = async () => {
    const { data, error } = await supabase
      .from('chapters')
      .select(`
        *,
        subjects!inner(id, name,
          class_subjects!inner(class_id)
        )
      `)
      .order('name');
    if (error) toast.error(error.message);
    else setChapters(data.map(ch => ({
      ...ch,
      subject_id: ch.subjects?.id || null,
      class_id: ch.subjects?.class_subjects?.[0]?.class_id || null
    })));
  };

  // Fetch topics with explicit joins
  const fetchTopics = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('topics')
      .select(`
        id,
        name,
        chapters (
          id,
          name,
          subjects (
            id,
            name,
            class_subjects!inner(
              class_id,
              classes(id, name,description)
            )
          )
        )
      `)
      .order('name');
    if (error) toast.error(error.message);
    else {
      // Flatten class_id for easier filtering
      const flatData = data.map(t => ({
        ...t,
        class_id: t.chapters?.subjects?.class_subjects?.[0]?.class_id || null
      }));
      setTopics(flatData);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchClasses();
    fetchSubjects();
    fetchChapters();
    fetchTopics();
  }, []);

  // Filtered topics for table display
  const filteredTopics = topics.filter((t) => {
    const matchClass = !filters.classId || t.class_id === filters.classId;
    const matchSubject =
      !filters.subjectId || t.chapters?.subjects?.id === filters.subjectId;
    const matchChapter =
      !filters.chapterId || t.chapters?.id === filters.chapterId;
    return matchClass && matchSubject && matchChapter;
  });

 

  const resetForm = () => {
  setFormData(prev => ({
    id: '',
    name: '',
    classId: prev.classId,   // keep existing selected class
    subjectId: prev.subjectId, // keep existing selected subject
    chapterId: prev.chapterId, // keep existing selected chapter
  }));
};

const handleSave = async () => {
  if (!formData.name || !formData.chapterId) {
    toast.error('Please fill all required fields');
    return;
  }

  setLoading(true);

  try {
    if (formData.id) {
      // Update existing topic
      const { error } = await supabase
        .from('topics')
        .update({
          name: formData.name,
          chapter_id: formData.chapterId,
        })
        .eq('id', formData.id);

      if (error) toast.error(error.message);
      else toast.success('Topic updated');

      // Refresh topics
      fetchTopics();
      // Reset only id and name to exit edit mode
      setFormData((prev) => ({ ...prev, id: '', name: '' }));

    } else {
      // Insert new topic
      const { data: newTopic, error } = await supabase
        .from('topics')
        .insert([
          {
            name: formData.name,
            chapter_id: formData.chapterId,
          },
        ])
        .select(`
          id,
          name,
          chapters (
            id,
            name,
            subjects (
              id,
              name,
              class_subjects!inner(
                class_id,
                classes(id, name)
              )
            )
          )
        `)
        .single();

      if (error) {
        toast.error(error.message);
        return;
      }

      // Flatten class_id for filtering
      const flatNewTopic = {
        ...newTopic,
        class_id: newTopic.chapters?.subjects?.class_subjects?.[0]?.class_id || null,
      };

      // Add new topic to the top of the list
      setTopics((prev) => [flatNewTopic, ...prev]);

      toast.success('Topic added');

      // Reset only topic name, keep class/subject/chapter selected
      setFormData((prev) => ({ ...prev, name: '', id: '' }));
    }
  } finally {
    setLoading(false);
  }
};




  const handleEdit = (topic) => {
    setFormData({
      id: topic.id,
      name: topic.name,
      classId: topic.class_id || '',
      subjectId: topic.chapters?.subjects?.id || '',
      chapterId: topic.chapters?.id || '',
    });
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this topic?')) return;
    const { error } = await supabase.from('topics').delete().eq('id', id);
    if (error) toast.error(error.message);
    else {
      toast.success('Deleted');
      fetchTopics();
    }
  };

  return (
    <AdminLayout activeTab="management">
      <div className="container py-4">
        <h2 className="mb-4">Manage Topics</h2>

        {/* Filters */}
        <div className="row mb-3">
          <div className="col-md-3">
            <select
              className="form-control"
              value={filters.classId}
              onChange={(e) => setFilters({ ...filters, classId: e.target.value, subjectId: '', chapterId: '' })}
            >
              <option value="">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.description}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-control"
              value={filters.subjectId}
              onChange={(e) => setFilters({ ...filters, subjectId: e.target.value, chapterId: '' })}
            >
              <option value="">All Subjects</option>
              {subjects
                .filter((s) => !filters.classId || s.class_id === filters.classId)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-control"
              value={filters.chapterId}
              onChange={(e) => setFilters({ ...filters, chapterId: e.target.value })}
            >
              <option value="">All Chapters</option>
              {chapters
                .filter((ch) => !filters.subjectId || ch.subject_id === filters.subjectId)
                .map((ch) => (
                  <option key={ch.id} value={ch.id}>
                    {ch.name}
                  </option>
                ))}
            </select>
          </div>
        </div>

        {/* Form */}
        <div className="card mb-4">
          <div className="card-body">
            <h5>{formData.id ? 'Edit Topic' : 'Add Topic'}</h5>
            <div className="row mb-2">
              <div className="col-md-3">
                <select
                  className="form-control"
                  value={formData.classId}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      classId: e.target.value,
                      subjectId: '',
                      chapterId: '',
                    })
                  }
                >
                  <option value="">Select Class</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.description}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-control"
                  value={formData.subjectId}
                  onChange={(e) =>
                    setFormData({ ...formData, subjectId: e.target.value, chapterId: '' })
                  }
                >
                  <option value="">Select Subject</option>
                  {subjects
                    .filter((s) => !formData.classId || s.class_id === formData.classId)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-control"
                  value={formData.chapterId}
                  onChange={(e) =>
                    setFormData({ ...formData, chapterId: e.target.value })
                  }
                >
                  <option value="">Select Chapter</option>
                  {chapters
                    .filter((ch) => !formData.subjectId || ch.subject_id === formData.subjectId)
                    .map((ch) => (
                      <option key={ch.id} value={ch.id}>
                        {ch.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="col-md-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Topic Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
            </div>
            <div className="d-flex justify-content-end mb-3">
            <button className="btn btn-primary me-2 text-right" onClick={handleSave}>
              {formData.id ? 'Update' : 'Add'}
            </button>
            {formData.id && (
              <button
                className="btn btn-secondary"
                onClick={resetForm}
              >
                Cancel
              </button>
            )}
            </div>
          </div>
        </div>

        {/* Topics Table */}
        <div className="table-responsive">
          <table className="table table-bordered text-center">
            <thead>
              <tr>
                <th>#</th>
                <th>Class</th>
                <th>Subject</th>
                <th>Chapter</th>
                <th>Topic</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTopics.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center">
                    No topics found
                  </td>
                </tr>
              )}
              {filteredTopics.map((t,i) => (
                <tr key={t.id}>
                  <td>{i+1}</td>
                  <td>{t.chapters?.subjects?.class_subjects?.[0]?.classes?.name || '-'}-{t.chapters?.subjects?.class_subjects?.[0]?.classes?.description || '-'}</td>
                  <td>{t.chapters?.subjects?.name || '-'}</td>
                  <td>{t.chapters?.name || '-'}</td>
                  <td>{t.name}</td>
                  <td>
                    <button
                      className="btn btn-sm btn-info me-2"
                      onClick={() => handleEdit(t)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(t.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
