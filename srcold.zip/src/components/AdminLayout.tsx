'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { supabase } from '../lib/supabaseClient';
import {
  FiHome, FiUsers, FiBook, FiFileText,
  FiSettings, FiMenu, FiLogOut, FiAward,
  FiLayers, FiBookOpen, FiGrid, FiFilePlus,
  FiChevronDown, FiChevronRight
} from 'react-icons/fi';

export default function AdminLayout({
  children,
  activeTab, // e.g. "questions" or "management/questions"
}: {
  children: React.ReactNode;
  activeTab: string;
}) {
  const [showSidebar, setShowSidebar] = useState(false);
  const [showManagementSubmenu, setShowManagementSubmenu] = useState(false);
  const router = useRouter();

  // Helper: get last path segment (leaf) so both "questions" and "management/questions" match
  const leaf = (s: string) => (s || '').split('/').filter(Boolean).pop() || '';
  const activeLeaf = leaf(activeTab);

  const navItems = [
    { id: '', label: 'Dashboard', icon: <FiHome /> },
    { id: 'users', label: 'User Management', icon: <FiUsers /> },
    {
      id: 'management',
      label: 'System Management',
      icon: <FiSettings />,
      subItems: [
        { id: 'management/questions', label: 'Question Bank', icon: <FiBook /> },
        { id: 'management/classes', label: 'Classes', icon: <FiLayers /> },
        { id: 'management/subjects', label: 'Subjects', icon: <FiGrid /> },
        { id: 'management/chapters', label: 'Chapters', icon: <FiBookOpen /> },
        { id: 'management/topics', label: 'Topics', icon: <FiFilePlus /> }
      ]
    },
    { id: 'papers', label: 'Papers', icon: <FiFileText /> },
    { id: 'results', label: 'Results', icon: <FiAward /> },
    { id: 'academies', label: 'Academies', icon: <FiSettings /> }
  ];

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/auth/login');
  };

  // Parent active if any child leaf matches the active leaf
  const isParentActive = (parentId: string) => {
    const parent = navItems.find(n => n.id === parentId);
    if (!parent || !parent.subItems) return false;
    return parent.subItems.some(si => leaf(si.id) === activeLeaf);
  };

  // Single item active if its own leaf matches the active leaf
  const isItemActive = (id: string) => leaf(id) === activeLeaf;

  // Auto-open System Management when any of its children is active
  useEffect(() => {
    setShowManagementSubmenu(isParentActive('management'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeLeaf]);

  const toggleManagementSubmenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setShowManagementSubmenu(v => !v);
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      {/* Top Navigation */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div className="container-fluid">
          <button
            className="navbar-toggler d-lg-none border-0"
            type="button"
            onClick={() => setShowSidebar(true)}
          >
            <FiMenu size={24} />
          </button>
          <span className="navbar-brand ms-2">Admin Dashboard</span>
          <div className="ms-auto d-flex align-items-center">
            <button
              className="btn btn-outline-light btn-sm d-flex align-items-center gap-1"
              onClick={handleLogout}
            >
              <FiLogOut /> Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="container-fluid flex-grow-1">
        <div className="row h-100">
          {/* Sidebar - Desktop */}
          <div className="col-lg-2 d-none d-lg-block bg-light p-0 border-end">
            <div className="p-3 h-100 d-flex flex-column">
              <ul className="nav nav-pills flex-column mb-auto">
                {/* Dashboard */}
                <li className="nav-item">
                  <Link
                    href="/admin"
                    className={`nav-link d-flex align-items-center gap-2 ${activeLeaf === '' ? 'active' : ''}`}
                  >
                    <FiHome />
                    Dashboard
                  </Link>
                </li>

                {/* User Management */}
                <li className="nav-item">
                  <Link
                    href="/admin/users"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('users') ? 'active' : ''}`}
                  >
                    <FiUsers />
                    User Management
                  </Link>
                </li>

                {/* System Management (parent) */}
                <li className="nav-item">
                  <div className="mb-2">
                    <div className="d-flex align-items-center">
                      <Link
                        href="#"
                        className={`nav-link flex-grow-1 d-flex align-items-center gap-2 ${
                          isParentActive('management') ? 'active' : ''
                        }`}
                        onClick={toggleManagementSubmenu}
                      >
                        <FiSettings />
                        System Management
                      </Link>
                      <button className="btn btn-link p-0" onClick={toggleManagementSubmenu}>
                        {showManagementSubmenu ? (
                          <FiChevronDown className="text-muted" />
                        ) : (
                          <FiChevronRight className="text-muted" />
                        )}
                      </button>
                    </div>

                    <div className={`collapse ${showManagementSubmenu ? 'show' : ''}`}>
                      <ul className="nav nav-pills flex-column ps-4 mt-1">
                        {navItems.find(n => n.id === 'management')!.subItems!.map(subItem => (
                          <li className="nav-item" key={subItem.id}>
                            <Link
                              href={`/admin/${subItem.id}`}
                              className={`nav-link d-flex align-items-center gap-2 ${
                                isItemActive(subItem.id) ? 'active' : ''
                              }`}
                            >
                              {subItem.icon}
                              {subItem.label}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </li>

                {/* Papers */}
                <li className="nav-item">
                  <Link
                    href="/admin/papers"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('papers') ? 'active' : ''}`}
                  >
                    <FiFileText />
                    Papers
                  </Link>
                </li>

                {/* Results */}
                <li className="nav-item">
                  <Link
                    href="/admin/results"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('results') ? 'active' : ''}`}
                  >
                    <FiAward />
                    Results
                  </Link>
                </li>

                {/* Academies */}
                <li className="nav-item">
                  <Link
                    href="/admin/academies"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('academies') ? 'active' : ''}`}
                  >
                    <FiSettings />
                    Academies
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Sidebar - Mobile */}
          <div
            className={`offcanvas offcanvas-start w-75 ${showSidebar ? 'show' : ''}`}
            tabIndex={-1}
            id="offcanvasSidebar"
            aria-labelledby="offcanvasSidebarLabel"
          >
            <div className="offcanvas-header">
              <h5 className="offcanvas-title" id="offcanvasSidebarLabel">Menu</h5>
              <button
                type="button"
                className="btn-close text-reset"
                onClick={() => setShowSidebar(false)}
              />
            </div>
            <div className="offcanvas-body">
              <ul className="nav nav-pills flex-column">
                {/* Repeat with same active logic */}
                <li className="nav-item">
                  <Link
                    href="/admin"
                    className={`nav-link d-flex align-items-center gap-2 ${activeLeaf === '' ? 'active' : ''}`}
                    onClick={() => setShowSidebar(false)}
                  >
                    <FiHome />
                    Dashboard
                  </Link>
                </li>

                <li className="nav-item">
                  <Link
                    href="/admin/users"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('users') ? 'active' : ''}`}
                    onClick={() => setShowSidebar(false)}
                  >
                    <FiUsers />
                    User Management
                  </Link>
                </li>

                <li className="nav-item">
                  <div className="mb-2">
                    <div className="d-flex align-items-center">
                      <Link
                        href="#"
                        className={`nav-link flex-grow-1 d-flex align-items-center gap-2 ${
                          isParentActive('management') ? 'active' : ''
                        }`}
                        onClick={(e) => {
                          e.preventDefault();
                          setShowManagementSubmenu(!showManagementSubmenu);
                        }}
                      >
                        <FiSettings />
                        System Management
                      </Link>
                      <button
                        className="btn btn-link p-0"
                        onClick={(e) => {
                          e.preventDefault();
                          setShowManagementSubmenu(!showManagementSubmenu);
                        }}
                      >
                        {showManagementSubmenu ? (
                          <FiChevronDown className="text-muted" />
                        ) : (
                          <FiChevronRight className="text-muted" />
                        )}
                      </button>
                    </div>

                    <div className={`collapse ${showManagementSubmenu ? 'show' : ''}`}>
                      <ul className="nav nav-pills flex-column ps-4 mt-1">
                        {navItems.find(n => n.id === 'management')!.subItems!.map(subItem => (
                          <li className="nav-item" key={subItem.id}>
                            <Link
                              href={`/admin/${subItem.id}`}
                              className={`nav-link d-flex align-items-center gap-2 ${
                                isItemActive(subItem.id) ? 'active' : ''
                              }`}
                              onClick={() => setShowSidebar(false)}
                            >
                              {subItem.icon}
                              {subItem.label}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </li>

                <li className="nav-item">
                  <Link
                    href="/admin/papers"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('papers') ? 'active' : ''}`}
                    onClick={() => setShowSidebar(false)}
                  >
                    <FiFileText />
                    Papers
                  </Link>
                </li>

                <li className="nav-item">
                  <Link
                    href="/admin/results"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('results') ? 'active' : ''}`}
                    onClick={() => setShowSidebar(false)}
                  >
                    <FiAward />
                    Results
                  </Link>
                </li>

                <li className="nav-item">
                  <Link
                    href="/admin/academies"
                    className={`nav-link d-flex align-items-center gap-2 ${isItemActive('academies') ? 'active' : ''}`}
                    onClick={() => setShowSidebar(false)}
                  >
                    <FiSettings />
                    Academies
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Main Content */}
          <div className="col-lg-10 p-4">{children}</div>
        </div>
      </div>

      <style jsx>{`
        .nav-link {
          border-radius: 0.25rem;
          transition: all 0.2s ease;
        }
        .nav-link.active {
          background-color: #0d6efd;
          color: white !important;
        }
        .nav-link:hover:not(.active) {
          background-color: rgba(0, 0, 0, 0.05);
        }
        .offcanvas-start {
          width: 75% !important;
        }
        .collapse {
          transition: height 0.3s ease;
        }
        .btn-link {
          text-decoration: none;
        }
      `}</style>
    </div>
  );
}
