//import { supabase } from '@/lib/supabaseClient';
import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);
export async function POST(req: Request) {
  try {
    const { subjectId, selectedChapters, paperTitle, chapterOption, selectionMethod, selectedQuestions } = await req.json();

    // Validate input
    if (!subjectId) {
      return NextResponse.json({ message: 'Subject ID is required' }, { status: 400 });
    }

    // Fetch MCQs based on selection method
    let mcqs = [];
    if (selectionMethod === 'manual' && selectedQuestions?.length > 0) {
      const { data, error } = await supabase
        .from('questions')
        .select(`
          id,
          question_text,
          option_a,
          option_b,
          option_c,
          option_d,
          correct_option,
          chapters!inner(chapterNo, name)
        `)
        .in('id', selectedQuestions)
        .order('id', { ascending: true });

      if (error) throw error;
      mcqs = data || [];
    } else {
      let query = supabase
        .from('questions')
        .select(`
          id,
          question_text,
          option_a,
          option_b,
          option_c,
          option_d,
          correct_option,
          chapters!inner(chapterNo, name)
        `)
        .eq('question_type', 'mcq')
        .eq('subject_id', subjectId)
        .order('id', { ascending: true });

      if (chapterOption === 'custom' && selectedChapters?.length > 0) {
        query = query.in('chapter_id', selectedChapters);
      }

      const { data, error } = await query;
      if (error) throw error;
      mcqs = data || [];
    }

    if (mcqs.length === 0) {
      return NextResponse.json({ message: 'No MCQs found for this selection' }, { status: 404 });
    }

    // Generate PDF
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([600, 800]);
    const { height, width } = page.getSize();
    const font = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const regularFont = await pdfDoc.embedFont(StandardFonts.Helvetica);

    // Header
    page.drawText(`${paperTitle || 'Generated Paper'} - MCQ Answer Key`, {
      x: 50,
      y: height - 50,
      size: 18,
      font,
      color: rgb(0, 0, 0),
    });

    // Chapter Info
    const chapterText = chapterOption === 'custom' 
      ? Array.from(new Set(mcqs.map(mcq => mcq.chapters?.chapterNo)))
          .filter(Boolean)
          .sort()
          .join(', ')
      : chapterOption;
    
    page.drawText(`Chapters: ${chapterText}`, {
      x: 50,
      y: height - 80,
      size: 12,
      font: regularFont,
    });

    // MCQ Answers
    let yPosition = height - 120;
    const startY = yPosition;
    let currentPage = page;
    
    mcqs.forEach((mcq, index) => {
      // Check if we need a new page
      if (yPosition < 100) {
        currentPage = pdfDoc.addPage([600, 800]);
        yPosition = height - 50;
        
        // Add header to new page
        currentPage.drawText(`${paperTitle || 'Generated Paper'} - MCQ Answer Key (cont.)`, {
          x: 50,
          y: height - 50,
          size: 18,
          font,
          color: rgb(0, 0, 0),
        });
      }

      // Question number and text
      currentPage.drawText(`${index + 1}. ${mcq.question_text}`, {
        x: 50,
        y: yPosition,
        size: 10,
        font: regularFont,
        maxWidth: width - 100,
      });
      yPosition -= 15;

      // Correct answer
      const correctOption = mcq[`option_${mcq.correct_option.toLowerCase()}`];
      currentPage.drawText(`✓ ${String.fromCharCode(65 + mcq.correct_option.charCodeAt(0) - 97)}. ${correctOption}`, {
        x: 60,
        y: yPosition,
        size: 10,
        font: regularFont,
        color: rgb(0, 0.5, 0),
      });
      yPosition -= 25;
    });

    // Footer
    const lastPage = pdfDoc.getPages()[pdfDoc.getPageCount() - 1];
    lastPage.drawText(`Generated on ${new Date().toLocaleDateString()}`, {
      x: 50,
      y: 30,
      size: 8,
      font: regularFont,
      color: rgb(0.5, 0.5, 0.5),
    });

    const pdfBytes = await pdfDoc.save();
    return new Response(pdfBytes, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${(paperTitle || 'mcq-key').replace(/[^a-z0-9]/gi, '_')}-key.pdf"`,
      },
    });

  } catch (error) {
    console.error('Error generating MCQ key:', error);
    return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
  }
}