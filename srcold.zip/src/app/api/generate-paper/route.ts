// app/api/generate-paper/route.ts
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300; // 5 minutes

import fs from 'fs';
import path from 'path';
import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import type { PaperGenerationRequest } from '@/types/types';
import {translate} from '@vitalets/google-translate-api';

// Get Puppeteer with proper error handling
async function getPuppeteer() {
  try {
    const puppeteer = await import('puppeteer');
    return puppeteer;
  } catch (error) {
    console.error('Failed to import puppeteer:', error);
    throw new Error('PDF generation is not available at this time');
  }
}

// Get Chrome executable path for different environments
function getChromePath() {
  const platform = process.platform;
  
  if (platform === 'win32') {
    const paths = [
      process.env.PROGRAMFILES + '\\Google\\Chrome\\Application\\chrome.exe',
      process.env['PROGRAMFILES(X86)'] + '\\Google\\Chrome\\Application\\chrome.exe',
      process.env.LOCALAPPDATA + '\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
    ];
    
    for (const p of paths) {
      if (p && fs.existsSync(p)) return p;
    }
  } else if (platform === 'darwin') {
    const paths = [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary',
      '/Applications/Chromium.app/Contents/MacOS/Chromium'
    ];
    
    for (const p of paths) {
      if (fs.existsSync(p)) return p;
    }
  } else {
    const paths = [
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
      '/usr/bin/chromium-browser',
      '/usr/bin/chromium',
      '/snap/bin/chromium'
    ];
    
    for (const p of paths) {
      if (fs.existsSync(p)) return p;
    }
  }
  
  return null;
}

// Function to load font as base64
function loadFontAsBase64(fontFileName: string): string {
  try {
    const fontPath = path.join(process.cwd(), 'public', 'fonts', fontFileName);
    console.log(fontPath);
    if (fs.existsSync(fontPath)) {
      const fontBuffer = fs.readFileSync(fontPath);
      return fontBuffer.toString('base64');
    } else {
      console.warn(`Font file not found: ${fontPath}`);
      return '';
    }
  } catch (error) {
    console.error('Error loading font:', error);
    return '';
  }
}

// Fallback function to find questions with relaxed filters
async function findQuestionsWithFallback(
  supabase: any,
  type: string,
  subjectId: string,
  chapterIds: string[],
  paperType: string | undefined,
  difficulty: string | undefined,
  count: number
) {
  console.log(`\n🔍 Finding ${count} ${type} questions with fallback...`);
  
  // Try with all filters first
  let query = supabase
    .from('questions')
    .select('id')
    .eq('question_type', type)
    .eq('subject_id', subjectId);

  if (chapterIds.length > 0) {
    query = query.in('chapter_id', chapterIds);
  }
  
  if (paperType && paperType !== 'all') {
    query = query.eq('source_type', paperType);
  }
  
  if (difficulty && difficulty !== 'any') {
    query = query.eq('difficulty', difficulty);
  }

  query = query.order('id', { ascending: false }).limit(count);
  const { data: questions, error } = await query;

  if (error) {
    console.error(`Error in initial query:`, error);
    return [];
  }

  if (questions && questions.length >= count) {
    console.log(`✅ Found ${questions.length} questions with all filters`);
    return questions;
  }

  // Fallback 1: Remove difficulty filter
  console.log(`🔄 Fallback 1: Removing difficulty filter for ${type}`);
  let fallbackQuery = supabase
    .from('questions')
    .select('id')
    .eq('question_type', type)
    .eq('subject_id', subjectId);

  if (chapterIds.length > 0) {
    fallbackQuery = fallbackQuery.in('chapter_id', chapterIds);
  }
  
  if (paperType && paperType !== 'all') {
    fallbackQuery = fallbackQuery.eq('source_type', paperType);
  }

  fallbackQuery = fallbackQuery.order('id', { ascending: false }).limit(count);
  const { data: fallbackQuestions1 } = await fallbackQuery;

  if (fallbackQuestions1 && fallbackQuestions1.length >= count) {
    console.log(`✅ Found ${fallbackQuestions1.length} questions without difficulty filter`);
    return fallbackQuestions1;
  }

  // Fallback 2: Remove paper type filter
  console.log(`🔄 Fallback 2: Removing paper type filter for ${type}`);
  let fallbackQuery2 = supabase
    .from('questions')
    .select('id')
    .eq('question_type', type)
    .eq('subject_id', subjectId);

  if (chapterIds.length > 0) {
    fallbackQuery2 = fallbackQuery2.in('chapter_id', chapterIds);
  }

  fallbackQuery2 = fallbackQuery2.order('id', { ascending: false }).limit(count);
  const { data: fallbackQuestions2 } = await fallbackQuery2;

  if (fallbackQuestions2 && fallbackQuestions2.length >= count) {
    console.log(`✅ Found ${fallbackQuestions2.length} questions without paper type filter`);
    return fallbackQuestions2;
  }

  // Fallback 3: Only subject and type filter
  console.log(`🔄 Fallback 3: Using only subject and type filter for ${type}`);
  const { data: fallbackQuestions3 } = await supabase
    .from('questions')
    .select('id')
    .eq('question_type', type)
    .eq('subject_id', subjectId)
    .order('id', { ascending: false })
    .limit(count);

  if (fallbackQuestions3 && fallbackQuestions3.length > 0) {
    console.log(`✅ Found ${fallbackQuestions3.length} questions with basic filters`);
    return fallbackQuestions3;
  }

  console.log(`❌ No ${type} questions found even with fallbacks`);
  return [];
}

// Function to format question text for better display
function formatQuestionText(text: string): string {
  if (!text) return '';
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold text
    .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italic text
    .replace(/\n/g, '<br>'); // Line breaks
}

// Function to simplify HTML content
function simplifyHtmlContent(html: string): string {
  // Remove unnecessary whitespace and comments
  return html
    .replace(/\s+/g, ' ')
    .replace(/<!--.*?-->/g, '')
    .trim();
}

export async function POST(request: Request) {
  console.log('📄 POST request received to generate paper');
  
  const token = request.headers.get('Authorization')?.split(' ')[1];
  if (!token) {
    return NextResponse.json({ error: 'Authorization token required' }, { status: 401 });
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { global: { headers: { Authorization: `Bearer ${token}` } } }
  );

  // Verify user
  const { data: { user }, error: userError } = await supabase.auth.getUser(token);
  if (userError || !user) {
    console.error('Authentication error:', userError);
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const requestData: PaperGenerationRequest = await request.json();
    console.log('📋 Request data received');

    const { 
      language = 'bilingual', 
      mcqMarks = 1, 
      shortMarks = 2, 
      longMarks = 5, 
      mcqPlacement = 'separate',
      selectionMethod,
      selectedQuestions,
      paperType = 'all',
      title,
      subjectId,
      classId,
      chapterOption = 'full_book',
      selectedChapters = [],
      mcqCount = 0,
      shortCount = 0,
      longCount = 0,
      mcqDifficulty = 'any',
      shortDifficulty = 'any',
      longDifficulty = 'any',
      easyPercent,
      mediumPercent,
      hardPercent,
      timeMinutes = 60,
      mcqToAttempt,
      shortToAttempt,
      longToAttempt
    } = requestData;

    // Validation
    if (!title || !subjectId) {
      return NextResponse.json(
        { error: 'Title and subject ID are required' },
        { status: 400 }
      );
    }

    // Test database connection
    const { data: testQuestions, error: testError } = await supabase
      .from('questions')
      .select('id')
      .limit(1);

    if (testError) {
      console.error('Database test failed:', testError);
      return NextResponse.json(
        { error: 'Database connection failed', details: testError.message },
        { status: 500 }
      );
    }

    console.log('✅ Database connection successful');

    // Determine chapters to include
    let chapterIds: string[] = [];
    if (chapterOption === 'full_book') {
      const { data: chapters, error: chaptersError } = await supabase
        .from('chapters')
        .select('id')
        .eq('subject_id', subjectId);
      
      if (chaptersError) {
        console.error('Error fetching chapters:', chaptersError);
        return NextResponse.json(
          { error: 'Failed to fetch chapters' },
          { status: 500 }
        );
      }
      
      chapterIds = chapters?.map(c => c.id) || [];
      console.log(`📚 Full book chapters found: ${chapterIds.length}`);
    } else if (chapterOption === 'custom' && selectedChapters && selectedChapters.length > 0) {
      chapterIds = selectedChapters;
      console.log(`🎯 Custom chapters selected: ${chapterIds.length}`);
    }

    // Calculate total marks
    const totalMarks = (mcqToAttempt || mcqCount || 0) * mcqMarks + 
                      (shortToAttempt || shortCount || 0) * shortMarks + 
                      (longToAttempt || longCount || 0) * longMarks;

    // Create paper record
    const { data: paper, error: paperError } = await supabase
      .from('papers')
      .insert({
        title: title,
        subject_id: subjectId,
        class_id: classId,
        created_by: user.id,
        paper_type: paperType,
        chapter_ids: chapterOption === 'custom' ? selectedChapters : null,
        difficulty: 'medium',
        total_marks: totalMarks,
        time_minutes: timeMinutes,
        mcq_to_attempt: mcqToAttempt,
        short_to_attempt: shortToAttempt,
        long_to_attempt: longToAttempt,
        language: language
      })
      .select()
      .single();

    if (paperError) {
      console.error('Error creating paper:', paperError);
      throw paperError;
    }

    console.log(`✅ Paper created with ID: ${paper.id}`);

    // Process question types with fallback
    const questionInserts = [];
    const questionTypes = [
      { type: 'mcq', count: mcqCount, difficulty: mcqDifficulty },
      { type: 'short', count: shortCount, difficulty: shortDifficulty },
      { type: 'long', count: longCount, difficulty: longDifficulty }
    ];

    for (const qType of questionTypes) {
      if (qType.count > 0) {
        const questions = await findQuestionsWithFallback(
          supabase,
          qType.type,
          subjectId,
          chapterIds,
          paperType,
          qType.difficulty,
          qType.count
        );

        if (questions.length > 0) {
          questions.forEach((q) => {
            questionInserts.push({
              paper_id: paper.id,
              question_id: q.id,
              order_number: questionInserts.length + 1,
              question_type: qType.type
            });
          });
          console.log(`✅ Added ${questions.length} ${qType.type} questions`);
        } else {
          console.warn(`⚠️ No ${qType.type} questions found`);
        }
      }
    }

    // Insert paper questions
    if (questionInserts.length > 0) {
      console.log(`📝 Inserting ${questionInserts.length} questions into paper_questions`);
      
      const { error: insertError } = await supabase
        .from('paper_questions')
        .insert(questionInserts);

      if (insertError) {
        console.error('Error inserting paper questions:', insertError);
        
        // Delete the paper since questions couldn't be added
        await supabase
          .from('papers')
          .delete()
          .eq('id', paper.id);
        
        throw insertError;
      }

      console.log(`✅ Successfully inserted ${questionInserts.length} questions`);
    } else {
      console.warn('⚠️ No questions to insert');
      
      // Delete the empty paper
      await supabase
        .from('papers')
        .delete()
        .eq('id', paper.id);
      
      return NextResponse.json(
        { 
          error: 'No questions found matching your criteria. Please try different filters.',
          details: {
            subjectId,
            chapterIds,
            paperType,
            mcqCount,
            shortCount,
            longCount
          }
        },
        { status: 400 }
      );
    }

    // Fetch paper questions with full question data
    console.log('📋 Fetching paper questions with details...');
    const { data: paperQuestions, error: pqError } = await supabase
      .from('paper_questions')
      .select(`
        order_number, 
        question_type, 
        question_id, 
        questions (
          question_text, 
          question_text_ur,
          option_a, 
          option_a_ur,
          option_b, 
          option_b_ur,
          option_c, 
          option_c_ur,
          option_d, 
          option_d_ur,
          answer_text,
          answer_text_ur,
          difficulty,
          chapter_id,
          correct_option
        )
      `)
      .eq('paper_id', paper.id)
      .order('order_number', { ascending: true });

    if (pqError) {
      console.error('Error fetching paper questions:', pqError);
      throw pqError;
    }

    console.log(`✅ Found ${paperQuestions?.length || 0} paper questions`);

    if (!paperQuestions || paperQuestions.length === 0) {
      // Delete the paper if no questions were found
      await supabase
        .from('papers')
        .delete()
        .eq('id', paper.id);
      
      return NextResponse.json(
        { error: 'No questions found for the generated paper' },
        { status: 404 }
      );
    }

    // Generate HTML content for PDF
    const isUrdu = language === 'urdu';
    const isBilingual = language === 'bilingual';
    const separateMCQ = mcqPlacement === 'separate';

    // Handle title
    const englishTitle = `${paper.title}`;
    const urduTitle = paper.title;

    // Load fonts
    //const jameelNooriBase64 = loadFontAsBase64('JameelNooriNastaleeqKasheeda.ttf');
   // const notoNastaliqBase64 = loadFontAsBase64('NotoNastaliqUrdu-Regular.ttf');

// Function to check if Urdu text exists and is not just English
function hasActualUrduText(text: string | null): boolean {
  if (!text) return false;
  
  // Check if text contains Urdu characters (Unicode range for Urdu/Arabic)
  const urduRegex = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
  return urduRegex.test(text);
}
  const jameelNooriBase64 = loadFontAsBase64('JameelNooriNastaleeqKasheeda.ttf');
    const notoNastaliqBase64 = loadFontAsBase64('NotoNastaliqUrdu-Regular.ttf');
let paperClass='';
let subject='';
let subject_ur  = '';
    try {
  // Fetch subject details
  const { data: subjectData, error: subjectError } = await supabaseAdmin
    .from('subjects')
    .select('name')
    .eq('id', subjectId)
    .single();

  if (!subjectError && subjectData) {
    subject = subjectData.name ;
    const translatedSubject = await translate(subject, { to: 'ur' });
  subject_ur  = translatedSubject.text;
  } else {
    console.warn('Using fallback subject data due to error:', subjectError);
  }

  // Fetch class details
  const { data: classData, error: classError } = await supabaseAdmin
    .from('classes')
    .select('name')
    .eq('id', classId)
    .single();

  if (!classError && classData) {
    paperClass = classData.name;
  } else {
    console.warn('Using fallback class data due to error:', classError);
  }
} catch (error) {
  console.error('Error fetching subject/class details:', error);
  // Continue with fallback values
}
/** CONVERT PAPER MINUTS INTO HOURS */
function convertMinutesToTimeFormat(minutes: number): string {
  if (minutes <= 0) return '0:00';
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  // Format with leading zero for minutes
  const formattedMinutes = remainingMinutes.toString().padStart(2, '0');
  
  return `${hours}:${formattedMinutes}`;
}// Build HTML content
let htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Computer Science Paper</title>
  
  <style>
   @font-face {
      font-family: 'Jameel Noori Nastaleeq';
      src: url('${jameelNooriBase64}') format('truetype');
      font-weight: normal;
      font-style: normal;
    }
    
    @font-face {
      font-family: 'Noto Nastaliq Urdu';
      src: url('${notoNastaliqBase64}') format('truetype');
      font-weight: normal;
      font-style: normal;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 10px; }
    .container { max-width: 900px; margin: 0 auto; background: white; padding: 0;  }

    .header {text-align:center; font-size: 14px;  }
    .header h1 { font-size: 20px; }
    .header h2 { font-size: 16px; }
    .urdu { font-family: "Jameel Noori Nastaleeq", "Noto Nastaliq Urdu", serif; direction: rtl; }
    .eng { font-family: "Times New Roman", serif; direction: ltr; }
     .options .urdu {
    font-family: "Jameel Noori Nastaleeq", "Noto Nastaliq Urdu";
    direction: rtl;
  }
  .options .eng {
    font-family: "Times New Roman", serif;
    direction: ltr;
  }
    .meta { display: flex; justify-content: space-between; margin: 0 0; font-size: 14px; font-weight:bold }
    .note {  padding: 0px; margin:0 0; font-size: 13px; line-height: 1.5; }
    
    table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 14px; direction:rtl}
    table, th, td { border: 1px solid #000; }
    td { padding: 8px; vertical-align: top; }
    .qnum { width: 40px; text-align: center; font-weight: bold; }
    .question { display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 0 0; 
    }
    .options { margin-top: 5px; display: flex; justify-content: space-between; font-size: 13px; }
    .footer { text-align: left; margin-top: 20px; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
  <div class="header">
      <h1 class="eng">${englishTitle}</h1>
     </div>
  <div class="heade">
      <p class="urdu"><span>رولنمبر۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔۔</span> <span> (اُمیدوار خُود پٗر کرے) </span> <span> (تعلیمی سال  20025-2026) </span></p>
    </div>


  <div class="meta">
      <span class="eng">${subject}</span>
      <span><strong>${paperClass} کلاس  </strong></span>
      <span class="urdu">${subject_ur}</span>
    </div>

    <div class="meta">
      <span class="eng">Time Allowed: ${convertMinutesToTimeFormat(timeMinutes)} Minutes</span>
      <span class="urdu">وقت:${convertMinutesToTimeFormat(timeMinutes)} منٹ</span>
    </div>
    <div class="meta">
      <span class="eng">Maximum Marks: ${totalMarks}</span>
      <span class="urdu"><span>${totalMarks}:</span> نمبر  </span>
    </div>
`;
       
// Get MCQ questions
const mcqQuestions = paperQuestions.filter((pq: any) => 
  pq.question_type === 'mcq' && pq.questions
);

// Add MCQ questions if they exist
if (mcqQuestions.length > 0) {
  htmlContent += `
    
    <div class="note">
      <p class="urdu">
        نوٹ: ہر سوال کے چار ممکنہ جوابات A,B,C اور D دیئے گئے ہیں۔ درست جواب کے مطابق دائرہ پُر کریں۔ ایک سے زیادہ دائروں کو پُر کرنے کی صورت میں جواب غلط تصور ہوگا۔
      </p>
      <p class="eng">
        Note: Four possible answers A, B, C and D to each question are given. Fill the correct option’s circle. More than one filled circle will be treated wrong.
      </p>
    </div>

    <table>
  `;

  // Process MCQ questions
  mcqQuestions.forEach((pq: any, index: number) => {
    const q = pq.questions;
    const englishQuestion = formatQuestionText(q.question_text || 'No question text available');
    const hasUrduQuestion = hasActualUrduText(q.question_text_ur);
    const urduQuestion = hasUrduQuestion ? formatQuestionText(q.question_text_ur) : '';
    
    const options = [
      { 
        letter: 'A', 
        english: q.option_a || '', 
        urdu: hasActualUrduText(q.option_a_ur) ? q.option_a_ur : '',
        hasUrdu: hasActualUrduText(q.option_a_ur)
      },
      { 
        letter: 'B', 
        english: q.option_b || '', 
        urdu: hasActualUrduText(q.option_b_ur) ? q.option_b_ur : '',
        hasUrdu: hasActualUrduText(q.option_b_ur)
      },
      { 
        letter: 'C', 
        english: q.option_c || '', 
        urdu: hasActualUrduText(q.option_c_ur) ? q.option_c_ur : '',
        hasUrdu: hasActualUrduText(q.option_c_ur)
      },
      { 
        letter: 'D', 
        english: q.option_d || '', 
        urdu: hasActualUrduText(q.option_d_ur) ? q.option_d_ur : '',
        hasUrdu: hasActualUrduText(q.option_d_ur)
      }
    ];

    const hasAnyUrduOptions = options.some(opt => opt.hasUrdu);

    htmlContent += `
     <tr>
        <td class="qnum">${pq.order_number}</td>
        <td>
          <div class="question">
           <span class="urdu">${hasUrduQuestion ? `${urduQuestion}` : ''}</span> 
          <span class="eng">${englishQuestion}</span>
           
          </div>
          <div class="options">
    `;

    options.forEach(option => {
      if (option.english || option.urdu) {
       htmlContent += `
  <span>
    (${option.letter}) 
    ${option.hasUrdu || hasAnyUrduOptions ? `<span><span class="urdu">${option.urdu}</span> <span class="eng">${option.english}</span></span>` : option.english}
  </span>
`;
      
            }
    });

    htmlContent += `
            </div>
        </td>
      </tr>
    `;
  });

  htmlContent += `
         </table>

    <div class="footer">
      <p>117-023-I (Objective Type) - 14500 (5833) (New Course)</p>
    </div>
  </div>
    
    <!-- Page break before subjective section -->
    <div style="page-break-before: always;"></div>
  `;
}

// Get subjective questions
const subjectiveQuestions = paperQuestions.filter((pq: any) => 
  pq.question_type !== 'mcq' && pq.questions
);
// Helper: Convert number to roman style (i, ii, iii …)
function toRoman(num: number): string {
  const romans = ['i','ii','iii','iv','v','vi','vii','viii','ix','x','xi','xii','xiii','xiv','xv','xvi','xvii','xviii'];
  return romans[num - 1] || num.toString();
}

if (subjectiveQuestions.length > 0) {
  htmlContent += `
    <!-- Short Questions Section -->
    <div class="header">
     
      (<span class="english">Part I<span><span class="urdu">حصہ اول </span>)
    </div>
  
  `;

  // Separate short and long questions
  const shortQuestions = subjectiveQuestions.filter((pq: any) => pq.question_type === 'short');

  // Add short questions
   // Grouping: 6 questions per groupe
   // Grouping: 6 questions per group
  const questionsPerGroup = 6;
  const totalGroups = Math.ceil(shortQuestions.length / questionsPerGroup);

  for (let g = 0; g < totalGroups; g++) {
    const groupQuestions = shortQuestions.slice(
      g * questionsPerGroup,
      (g + 1) * questionsPerGroup
    );

    // Q. numbering starts from 2
    const questionNumber = g + 2;

    htmlContent += `
      
      
      <div class="short-questions">
        <div style="display:flex; justify-content:space-between; margin-bottom:0px; font-weight:bold">
          <div class="eng"><strong>${questionNumber}.</strong>Write short answers to any four(4) questions.<span></span></div>
          <div class="urdu" style="direction:rtl;"><strong><span>${questionNumber}.</span>کوئی سے چار سوالات کے مختصر جوابات لکھئے  </strong></div>
        </div>
    `;

    groupQuestions.forEach((pq: any, idx: number) => {
      const q = pq.questions;
      const englishQuestion = formatQuestionText(q.question_text || 'No question text available');
      const hasUrduQuestion = hasActualUrduText(q.question_text_ur);
      const urduQuestion = hasUrduQuestion ? formatQuestionText(q.question_text_ur) : '';

      htmlContent += `
         <div class="short-question-item" style="display:flex; justify-content:space-between; margin-bottom:0px;">
          <div class="eng">(${toRoman(idx + 1)}) ${englishQuestion}</div>
          ${hasUrduQuestion ? `<div class="urdu" style="direction:rtl;">(${toRoman(idx + 1)}) ${urduQuestion}</div>` : ''}
        </div>
      `;
    });

    htmlContent += `
       </div>
    `;
  }
}

  const longQuestions = subjectiveQuestions.filter((pq: any) => pq.question_type === 'long');

  // Add long questions
if (longQuestions.length > 0) {
  htmlContent += `
    <div class="header">
      (<span class="eng">Part-II</span> <span class="urdu">حصہ دوم</span>)
    </div>
    <div class="instructions" style="font-weight:bold">
      <div class="instruction-text eng">
        <span>Note:</span> Attempt any 2 questions.
      </div>
      <div class="instruction-text urdu" style="direction: rtl;">
        <span>نوٹ:</span> کوئی دو سوالات حل کریں۔
      </div>
    </div>
  `;

  longQuestions.forEach((pq: any, idx: number) => {
    const q = pq.questions;
    const englishQuestion = formatQuestionText(q.question_text || 'No question text available');
    const hasUrduQuestion = hasActualUrduText(q.question_text_ur);
    const urduQuestion = hasUrduQuestion ? formatQuestionText(q.question_text_ur) : '';

    // Sub-questions
    const subQuestions = pq.sub_questions || [];
    let subQsHTML = '';

    if (subQuestions.length > 0) {
      subQsHTML += `
        <div style="display: flex; justify-content: space-between; margin-top:6px;">
          <div class="eng" style="width: 48%;">
            <ol type="a">
              ${subQuestions.map((sq: any) => `<li>${formatQuestionText(sq.question_text || '')}</li>`).join('')}
            </ol>
          </div>
          ${
            hasUrduQuestion
              ? `<div class="urdu" style="width: 48%; direction: rtl; text-align: right;">
                  <ol type="a">
                    ${subQuestions.map((sq: any) => `<li>${formatQuestionText(sq.question_text_ur || '')}</li>`).join('')}
                  </ol>
                </div>`
              : ''
          }
        </div>
      `;
    }

    htmlContent += `
      <div class="long-question" style="margin-bottom:12px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div class="eng" ${hasUrduQuestion ? 'style="width:48%;"' : 'style="width:100%;"'}>
            <strong>Q.${idx + 1}.</strong> ${englishQuestion}
          </div>
          ${
            hasUrduQuestion
              ? `<div class="urdu" style="width:48%; direction:rtl; text-align:right;">
                  <strong>سوال ${idx + 1}:</strong> ${urduQuestion}
                </div>`
              : ''
          }
        </div>
        ${subQsHTML}
      </div>
    `;
  });
}


  htmlContent += `
    </div>
  `;


// Footer
htmlContent += `
    <div style="margin-top: 30px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ccc; padding-top: 10px;">
      <p class="english">Generated on ${new Date().toLocaleDateString()} | Paper ID: ${paper.id} | BISE Lahore Pattern</p>
    </div>
  </div>
</body>
</html>
`;

// Simplify HTML content
// ... (rest of the code remains the same)
// ... (rest of the code remains the same)    // Simplify HTML content
    htmlContent = simplifyHtmlContent(htmlContent);

    // Generate PDF
    let browser = null;
    try {
      const puppeteer = await getPuppeteer();
      const launchOptions: any = {
        args: [
          '--no-sandbox', 
          '--disable-setuid-sandbox', 
          '--disable-dev-shm-usage',
          '--disable-gpu',
          '--disable-software-rasterizer',
          '--disable-setuid-sandbox',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ],
        defaultViewport: { width: 1200, height: 800 },
        headless: 'new',
        timeout: 120000 // Increase timeout to 2 minutes
      };

      const chromePath = getChromePath();
      if (chromePath) {
        launchOptions.executablePath = chromePath;
      }

      browser = await puppeteer.launch(launchOptions);
      const page = await browser.newPage();
      
      // Set a longer timeout for page operations
      page.setDefaultTimeout(60000);
      page.setDefaultNavigationTimeout(60000);
      
      // Use a temporary HTML file instead of setContent for large documents
      const tempHtmlPath = path.join(process.cwd(), 'temp', `paper-${paper.id}.html`);
      const tempDir = path.dirname(tempHtmlPath);
      
      // Ensure temp directory exists
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      // Write HTML to a temporary file
      fs.writeFileSync(tempHtmlPath, htmlContent, 'utf8');
      
      // Use file:// protocol to load the HTML
      const fileUrl = `file://${tempHtmlPath}`;
      await page.goto(fileUrl, { 
        waitUntil: 'networkidle0',
        timeout: 60000
      });
      
      // Wait for fonts to load (especially important for Urdu fonts)
      await page.evaluate(() => {
        return document.fonts.ready;
      });
      
      // Add a small delay to ensure all content is rendered (fixed version)
      await new Promise(resolve => setTimeout(resolve, 2000));

      const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: { top: '40px', right: '40px', bottom: '40px', left: '40px' },
        preferCSSPageSize: true
      });

      await browser.close();
      
      // Clean up temporary file
      if (fs.existsSync(tempHtmlPath)) {
        fs.unlinkSync(tempHtmlPath);
      }

      console.log('✅ PDF generated successfully');
      
      return new NextResponse(pdfBuffer, {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${paper.title.replace(/\s+/g, '_')}.pdf"`,
          'Content-Length': pdfBuffer.length.toString(),
        },
      });

    } catch (error) {
      console.error('❌ Puppeteer error:', error);
      if (browser) await browser.close();
      
      // Clean up temporary file if it exists
      const tempHtmlPath = path.join(process.cwd(), 'temp', `paper-${paper.id}.html`);
      if (fs.existsSync(tempHtmlPath)) {
        fs.unlinkSync(tempHtmlPath);
      }
      
      // Return paper data even if PDF generation fails
      return NextResponse.json(
        { 
          success: true, 
          paperId: paper.id, 
          message: 'Paper created but PDF generation failed',
          questionsCount: paperQuestions.length,
          error: error instanceof Error ? error.message : 'Unknown error'
        },
        { status: 200 }
      );
    }

  } catch (error) {
    console.error('❌ Paper generation error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate paper', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}