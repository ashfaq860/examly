// components/AcademyLayout.tsx
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Header from '@/components/academy/Header'
export default function AcademyLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
    }

    // Close sidebar when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.querySelector('.sidebar');
      const toggleButton = document.querySelector('.sidebar-toggle');
      
      if (sidebarOpen && 
          !(event.target as Element).closest('.sidebar') && 
          !(event.target as Element).closest('.sidebar-toggle')) {
        setSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [sidebarOpen]);

  useEffect(() => {
    // Apply theme class to body
    if (darkMode) {
      document.body.classList.add('dark-mode');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-mode');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const isActive = (path: string) => pathname?.startsWith(path);

  return (
    <div className={`d-flex ${darkMode ? 'bg-dark text-light' : 'bg-light text-dark'}`} style={{ minHeight: '100vh' }}>
      {/* Sidebar Toggle Button (Mobile) */}
      <button 
        className="sidebar-toggle d-lg-none btn btn-link position-fixed start-0 mt-2 ms-2 z-3"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        <i className="bi bi-list" style={{ fontSize: '1.5rem' }}></i>
      </button>

      {/* Sidebar */}
      <div 
        className={`sidebar d-flex flex-column flex-shrink-0 p-3 border-end ${sidebarOpen ? 'open' : ''}`}
        style={{ width: '280px' }}
      >
        <Link href="/academy" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none">
          <span className="fs-4">Examly Academy</span>
        </Link>
        <hr />
        <ul className="nav nav-pills flex-column mb-auto">
          <li className="nav-item">
            <Link href="/academy" className={`nav-link ${isActive('/academy') ? 'active' : ''}`}>
              <i className="bi bi-speedometer2 me-2"></i>
              Dashboard
            </Link>
          </li>
          <li>
            <Link href="/academy/question-bank" className={`nav-link ${isActive('/academy/question-bank') ? 'active' : ''}`}>
              <i className="bi bi-journal-bookmark me-2"></i>
              Question Bank
            </Link>
          </li>
          <li>
            <Link href="/academy/generate-paper" className={`nav-link ${isActive('/academy/generate-paper') ? 'active' : ''}`}>
              <i className="bi bi-file-earmark-text me-2"></i>
              Generate Paper
            </Link>
          </li>
          <li>
            <Link href="/academy/templates" className={`nav-link ${isActive('/academy/templates') ? 'active' : ''}`}>
              <i className="bi bi-collection me-2"></i>
              Templates
            </Link>
          </li>
          <li>
            <Link href="/academy/settings" className={`nav-link ${isActive('/academy/settings') ? 'active' : ''}`}>
              <i className="bi bi-gear me-2"></i>
              Settings
            </Link>
          </li>
        </ul>
        <hr />
        <div className="alert alert-warning p-2 text-center">
          <small>Free Trial: 5 days left</small>
          <Link href="/upgrade" className="btn btn-sm btn-primary w-100 mt-2">
            Upgrade Now
          </Link>
        </div>
        <div className="form-check form-switch mt-3">
          <input
            className="form-check-input"
            type="checkbox"
            checked={darkMode}
            onChange={() => setDarkMode(!darkMode)}
          />
          <label className="form-check-label">
            {darkMode ? 'Dark' : 'Light'} Mode
          </label>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1">
        <Header />
        <main className="p-4">
          {children}
        </main>
      </div>

      {/* Add some CSS for the sidebar behavior */}
      <style jsx>{`
        @media (max-width: 992px) {
          .sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            height: 100vh;
            z-index: 2;
            background: ${darkMode ? '#212529' : '#fff'};
            transition: left 0.3s ease;
          }
          .sidebar.open {
            left: 0;
          }
          .sidebar-toggle {
            z-index: 3;
          }
        }
      `}</style>
    </div>
  );
}
