import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get('userId');

  if (!userId) {
    return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
  }

  try {
    // Use admin client to bypass RLS
    const { data: profile, error } = await supabaseAdmin
      .from('profiles')
      .select('trial_ends_at, subscription_status, papers_generated')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching profile:', error);
      return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 });
    }

    const trialEndsAt = profile.trial_ends_at ? new Date(profile.trial_ends_at) : null;
    const isTrial = trialEndsAt !== null && trialEndsAt.getTime() > Date.now();
    const daysRemaining = trialEndsAt ? Math.max(0, Math.ceil((trialEndsAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24))) : 0;
    const papersGenerated = profile.papers_generated || 0;
    const papersRemaining = isTrial ? Math.max(0, 5 - papersGenerated) : 0;

    return NextResponse.json({
      isTrial,
      trialEndsAt: trialEndsAt?.toISOString() || null,
      daysRemaining,
      hasActiveSubscription: profile.subscription_status === 'active',
      papersGenerated,
      papersRemaining
    });

  } catch (error) {
    console.error('Error fetching trial status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Add this to handle unsupported methods
export async function POST() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function PUT() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function DELETE() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}