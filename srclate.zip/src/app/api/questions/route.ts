// src/app/api/questions/route.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);

  try {
    const subjectId = searchParams.get('subjectId');
    const questionType = searchParams.get('questionType');
    const difficulty = searchParams.get('difficulty');
    const chapterIds = searchParams.get('chapterIds');
    const sourceType = searchParams.get('source_type');
    const limit = parseInt(searchParams.get('limit') || '10', 10);

    if (!subjectId || !questionType) {
      return NextResponse.json(
        { error: 'subjectId and questionType are required' },
        { status: 400 }
      );
    }

    let query = supabaseAdmin
      .from('questions')
      .select('*')
      .eq('subject_id', subjectId)
      .eq('question_type', questionType)
      .limit(limit);

    if (difficulty && difficulty !== 'any') {
      query = query.eq('difficulty', difficulty);
    }

    if (chapterIds) {
      const chapterIdArray = chapterIds.split(',');
      query = query.in('chapter_id', chapterIdArray);
    }
  if (sourceType && sourceType !== 'all') {
      query = query.eq('source_type', sourceType);
    }
    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json(data || []);
  } catch (error) {
    console.error('Error fetching questions:', error);
    return NextResponse.json(
      { error: 'Failed to fetch questions' },
      { status: 500 }
    );
  }
}
