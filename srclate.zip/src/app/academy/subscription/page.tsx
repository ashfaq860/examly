// pages/academy/subscription.tsx
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import AcademyLayout from '@/components/AcademyLayout';

interface Package {
  id: string;
  name: string;
  type: 'paper_pack' | 'subscription';
  paper_quantity?: number;
  duration_days?: number;
  price: number;
  description: string;
}

export default function SubscriptionPage() {
  const [packages, setPackages] = useState<Package[]>([]);
  const [userPackage, setUserPackage] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPackages();
    fetchUserSubscription();
  }, []);

  const fetchPackages = async () => {
    try {
      const { data, error } = await supabase
        .from('packages')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;
      setPackages(data || []);
    } catch (error) {
      console.error('Error fetching packages:', error);
    }
  };

  const fetchUserSubscription = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('user_packages')
        .select(`
          *,
          packages (*)
        `)
        .eq('user_id', session.user.id)
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      setUserPackage(data?.[0] || null);
    } catch (error) {
      console.error('Error fetching user subscription:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async (packageId: string) => {
    // Implement your payment integration here (Stripe, etc.)
    console.log('Subscribe to package:', packageId);
    // Redirect to payment page or show payment modal
  };

  if (loading) {
    return (
      <AcademyLayout>
        <div className="container text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </AcademyLayout>
    );
  }

  return (
    <AcademyLayout>
      <div className="container py-4">
        <h1 className="h2 mb-4">Subscription Plans</h1>

        {userPackage && (
          <div className="alert alert-success mb-4">
            <h4 className="alert-heading">Current Plan</h4>
            <p>You are subscribed to: <strong>{userPackage.packages?.name}</strong></p>
            <p>Expires on: {new Date(userPackage.expires_at).toLocaleDateString()}</p>
            {userPackage.packages?.type === 'paper_pack' && (
              <p>Papers remaining: {userPackage.papers_remaining}</p>
            )}
          </div>
        )}

        <div className="row row-cols-1 row-cols-md-3 g-4">
          {packages.map((pkg) => (
            <div key={pkg.id} className="col">
              <div className="card h-100">
                <div className="card-body">
                  <h3 className="card-title">{pkg.name}</h3>
                  <h4 className="text-primary">${pkg.price}</h4>
                  <p className="card-text">{pkg.description}</p>
                  
                  {pkg.type === 'paper_pack' && pkg.paper_quantity && (
                    <p>{pkg.paper_quantity} papers</p>
                  )}
                  
                  {pkg.type === 'subscription' && pkg.duration_days && (
                    <p>{pkg.duration_days} days access</p>
                  )}
                </div>
                <div className="card-footer">
                  <button
                    className="btn btn-primary w-100"
                    onClick={() => handleSubscribe(pkg.id)}
                    disabled={userPackage?.package_id === pkg.id}
                  >
                    {userPackage?.package_id === pkg.id ? 'Current Plan' : 'Subscribe'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5">
          <h3>Why Subscribe?</h3>
          <ul>
            <li>Unlimited paper generation</li>
            <li>No watermarks on downloaded papers</li>
            <li>Priority support</li>
            <li>Access to advanced features</li>
          </ul>
        </div>
      </div>
    </AcademyLayout>
  );
}
/* academy/subscription/page.tsx */