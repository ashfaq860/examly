'use client';
import { useState, useEffect } from 'react'
import AdminLayout from '../../components/AdminLayout'
import { supabase } from '../../lib/supabaseClient'
import { Bar, Pie } from 'react-chartjs-2'
import { Chart, registerables } from 'chart.js'
Chart.register(...registerables)

export default function Overview() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Fetch all data in parallel
      const [
        { count: teacherCount },
        { count: studentCount },
        { count: academyCount },
        { count: paperCount },
        { count: questionCount },
        { data: papersByMonth },
        { data: questionsBySubject }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact' }).eq('role', 'teacher'),
        supabase.from('profiles').select('*', { count: 'exact' }).eq('role', 'student'),
        supabase.from('academies').select('*', { count: 'exact' }),
        supabase.from('papers').select('*', { count: 'exact' }),
        supabase.from('questions').select('*', { count: 'exact' }),
        supabase.rpc('get_papers_by_month'),
        supabase.rpc('get_questions_by_subject')
      ])

      setStats({
        teacherCount,
        studentCount,
        academyCount,
        paperCount,
        questionCount,
        papersByMonth,
        questionsBySubject
      })
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const papersChartData = {
    labels: stats?.papersByMonth?.map(item => item.month) || [],
    datasets: [{
      label: 'Papers Generated',
      data: stats?.papersByMonth?.map(item => item.count) || [],
      backgroundColor: 'rgba(54, 162, 235, 0.5)',
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1
    }]
  }

  const questionsChartData = {
    labels: stats?.questionsBySubject?.map(item => item.subject_name) || [],
    datasets: [{
      data: stats?.questionsBySubject?.map(item => item.count) || [],
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.5)',
        'rgba(255, 206, 86, 0.5)',
        'rgba(75, 192, 192, 0.5)',
        'rgba(153, 102, 255, 0.5)'
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)'
      ],
      borderWidth: 1
    }]
  }

  if (loading) {
    return (
      <AdminLayout activeTab="overview">
        <div className="d-flex justify-content-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout activeTab="overview">
      <h2 className="mb-4">Dashboard Overview</h2>
      
      {/* Stats Cards */}
      <div className="row g-4 mb-4">
        <div className="col-md-3">
          <div className="card border-primary shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title text-primary">Total Teachers</h5>
              <p className="card-text display-5 fw-bold">
                {stats?.teacherCount || 0}
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-success shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title text-success">Total Students</h5>
              <p className="card-text display-5 fw-bold">
                {stats?.studentCount || 0}
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-info shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title text-info">Academies</h5>
              <p className="card-text display-5 fw-bold">
                {stats?.academyCount || 0}
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-warning shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title text-warning">Papers Generated</h5>
              <p className="card-text display-5 fw-bold">
                {stats?.paperCount || 0}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Second Row of Stats */}
      <div className="row g-4 mb-4">
        <div className="col-md-6">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Question Bank Size</h5>
              <p className="card-text display-3 fw-bold">
                {stats?.questionCount || 0}
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Average Papers per Academy</h5>
              <p className="card-text display-3 fw-bold">
                {stats?.academyCount ? Math.round(stats.paperCount / stats.academyCount) : 0}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="row g-4">
        <div className="col-lg-6">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Monthly Paper Generation</h5>
              <div style={{ height: '300px' }}>
                <Bar 
                  data={papersChartData} 
                  options={{ 
                    responsive: true,
                    maintainAspectRatio: false 
                  }} 
                />
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <h5 className="card-title">Subject-wise Question Distribution</h5>
              <div style={{ height: '300px' }}>
                <Pie 
                  data={questionsChartData} 
                  options={{ 
                    responsive: true,
                    maintainAspectRatio: false 
                  }} 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}