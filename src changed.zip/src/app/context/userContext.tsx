'use client';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

const supabase = createClientComponentClient();

interface TrialStatus {
  isTrial: boolean;
  trialEndsAt: Date | null;
  daysRemaining: number;
  hasActiveSubscription: boolean;
  papersGenerated: number;
  papersRemaining: number;
}

interface UserContextType {
  trialStatus: TrialStatus | null;
  isLoading: boolean;
  refreshTrialStatus: () => Promise<void>;
  incrementPapersGenerated: () => void;
}

const UserContext = createContext<UserContextType>({
  trialStatus: null,
  isLoading: true,
  refreshTrialStatus: async () => {},
  incrementPapersGenerated: () => {}
});

export const useUser = () => useContext(UserContext);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [trialStatus, setTrialStatus] = useState<TrialStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const calculateDaysRemaining = (trialEndsAt: string) => {
    const now = new Date();
    const endDate = new Date(trialEndsAt);
    const diffTime = endDate.getTime() - now.getTime();
    return Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  };

  const calculateRemainingPapers = (generatedPapers: number) => {
    return Math.max(0, 5 - (generatedPapers || 0));
  };

  const fetchTrialStatus = async () => {
    setIsLoading(true);

    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();

      if (sessionError || !session) {
        console.log('No active session found');
        setTrialStatus({
          isTrial: false,
          trialEndsAt: null,
          daysRemaining: 0,
          hasActiveSubscription: false,
          papersGenerated: 0,
          papersRemaining: 0
        });
        setIsLoading(false);
        return;
      }

      const response = await fetch(`/api/user/trial-status?userId=${session.user.id}`);
      if (!response.ok) throw new Error('Failed to fetch trial status');

      const trialData = await response.json();

      setTrialStatus({
        isTrial: trialData.isTrial,
        trialEndsAt: trialData.trialEndsAt ? new Date(trialData.trialEndsAt) : null,
        daysRemaining: calculateDaysRemaining(trialData.trialEndsAt),
        hasActiveSubscription: trialData.hasActiveSubscription,
        papersGenerated: trialData.papersGenerated,
        papersRemaining: calculateRemainingPapers(trialData.papersGenerated)
      });
    } catch (error) {
      console.error('Error fetching trial status:', error);
      setTrialStatus({
        isTrial: false,
        trialEndsAt: null,
        daysRemaining: 0,
        hasActiveSubscription: false,
        papersGenerated: 0,
        papersRemaining: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  const incrementPapersGenerated = () => {
    if (trialStatus) {
      setTrialStatus(prev => prev ? {
        ...prev,
        papersGenerated: prev.papersGenerated + 1,
        papersRemaining: Math.max(0, (prev.isTrial ? 5 - (prev.papersGenerated + 1) : prev.papersRemaining))
      } : null);
    }
  };

  useEffect(() => {
    fetchTrialStatus();

    // 👇 Listen for login/logout/session changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, _session) => {
      fetchTrialStatus();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const value = {
    trialStatus,
    isLoading,
    refreshTrialStatus: fetchTrialStatus,
    incrementPapersGenerated
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};
