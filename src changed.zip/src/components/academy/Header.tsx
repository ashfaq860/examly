"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

const Header = ({ onMenuToggle }: { onMenuToggle: () => void }) => {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [role, setRole] = useState<string>("");
  const supabase = createClientComponentClient();

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", session.user.id)
          .single();
        if (profile?.role) setRole(profile.role);
      }
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    document.cookie = "role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    router.push("/auth/login");
  };

  return (
    <header className="header-glass sticky-top shadow-sm">
      <div className="container-fluid d-flex justify-content-between align-items-center py-2 px-3">
        {/* Mobile Menu Button and Logo */}
        <div className="d-flex align-items-center">
          <button
            className="btn btn-link text-dark d-lg-none me-2"
            onClick={onMenuToggle}
            style={{ padding: '5px' }}
          >
            <i className="bi bi-list" style={{ fontSize: '1.5rem' }}></i>
          </button>
          <Link href="/academy" className="text-decoration-none fw-bold fs-5 text-primary">
            <i className="bi bi-mortarboard me-2"></i> Examly Academy
          </Link>
        </div>

        {/* User Info + Logout */}
        <div className="d-flex align-items-center gap-3">
          <div className="text-muted small text-end d-none d-md-block">
            <div className="fw-semibold text-dark">
              {user?.user_metadata?.full_name || "User"}
            </div>
            <div>
              <span>{user?.email}</span>
              <span className="mx-2">•</span>
              <span className="text-capitalize">{role || "user"}</span>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="btn btn-outline-danger btn-sm d-flex align-items-center shadow-sm rounded-pill px-3"
          >
            <i className="bi bi-box-arrow-right me-1"></i>
            <span className="d-none d-sm-inline">Logout</span>
          </button>
        </div>
      </div>

      <style jsx>{`
        .header-glass {
          background: rgba(255, 255, 255, 0.9);
          backdrop-filter: blur(10px);
        }
        @media (max-width: 768px) {
          .header-glass {
            padding: 0.5rem 0;
          }
        }
      `}</style>
    </header>
  );
};

export default Header;