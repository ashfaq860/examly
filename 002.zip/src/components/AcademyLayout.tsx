'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Header from '@/components/academy/Header';
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { useUser } from '@/app/context/userContext';

export default function AcademyLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { trialStatus, isLoading } = useUser();
  const supabase = createClientComponentClient();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
    }
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-mode');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const isActive = (path: string) => pathname?.startsWith(path);

  // Calculate days remaining from context
  const daysRemaining = trialStatus?.daysRemaining ?? 0;
  const hasActiveSubscription = trialStatus?.hasActiveSubscription ?? false;

  return (
    <div className={`d-flex ${darkMode ? 'bg-dark text-light' : 'bg-light text-dark'}`} style={{ minHeight: '100vh' }}>
      {/* Sidebar Overlay for Mobile */}
      {sidebarOpen && (
        <div 
          className="d-lg-none position-fixed w-100 h-100"
          style={{ 
            backgroundColor: 'rgba(0,0,0,0.5)', 
            zIndex: 999, 
            top: 0, 
            left: 0 
          }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div 
        className={`sidebar d-flex flex-column flex-shrink-0 p-3 shadow-sm ${sidebarOpen ? 'open' : ''}`}
        style={{ 
          width: '260px',
          zIndex: 1000,
          backgroundColor: darkMode ? '#212529' : '#fff'
        }}
      >
        <div className="d-flex justify-content-between align-items-center mb-3">
          <Link 
            href="/dashboard" 
            className="text-decoration-none fs-5 fw-bold text-primary"
            onClick={() => setSidebarOpen(false)}
          >
            <i className="bi bi-mortarboard me-2"></i> Dashboard
          </Link>
          <button 
            className="btn btn-close d-lg-none"
            onClick={() => setSidebarOpen(false)}
          />
        </div>
        <hr />
        <ul className="nav nav-pills flex-column gap-2">
          <li>
            <Link 
              href="/dashboard" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-speedometer2 me-2"></i> Dashboard
            </Link>
          </li>
          
          <li>
            <Link 
              href="/dashboard/generate-paper" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/generate-paper') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-file-earmark-text me-2"></i> Generate Paper
            </Link>
          </li>
          <li>
            <Link 
              href="/dashboard/profile" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/profile') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-person me-2"></i> Profile
            </Link>
          </li>
          <li>
            <Link 
              href="/dashboard/settings" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/settings') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-gear me-2"></i> Settings
            </Link>
          </li>
           <li>
            <Link 
              href="/dashboard/packages" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/packages') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-box-seam me-2"></i> Best Packages
            </Link>
          </li>
        </ul>
        <hr />
        
        {/* Trial Status Card */}
        {!hasActiveSubscription && (
          <div className="alert alert-info text-center small shadow-sm">
            <strong>Free Trial</strong> <br /> 
            {isLoading ? (
              <div className="spinner-border spinner-border-sm" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              `${daysRemaining} days left`
            )}
            <Link 
              href="/dashboard/packages" 
              className="btn btn-sm btn-primary w-100 mt-2 shadow-sm rounded-pill"
              onClick={() => setSidebarOpen(false)}
            >
              Upgrade Now
            </Link>
          </div>
        )}
        
        {/* Subscription Status for Paid Users */}
        {hasActiveSubscription && (
          <div className="alert alert-success text-center small shadow-sm">
            <strong>Premium Account</strong> <br /> 
            <span>Active Subscription</span>
            <Link 
              href="/dashboard/settings" 
              className="btn btn-sm btn-outline-success w-100 mt-2 shadow-sm rounded-pill"
              onClick={() => setSidebarOpen(false)}
            >
              Manage Account
            </Link>
          </div>
        )}
        
        <div className="form-check form-switch mt-3">
          <input
            className="form-check-input"
            type="checkbox"
            checked={darkMode}
            onChange={() => setDarkMode(!darkMode)}
          />
          <label className="form-check-label">{darkMode ? '🌙 Dark' : '☀️ Light'} Mode</label>
        </div>
      </div>

      {/* Main */}
      <div className="flex-grow-1">
        <Header onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />
        <main className="p-4">{children}</main>
      </div>

      {/* Sidebar Responsive */}
      <style jsx>{`
        @media (max-width: 992px) {
          .sidebar {
            position: fixed;
            top: 0;
            left: -260px;
            height: 100vh;
            transition: all 0.3s ease;
            overflow-y: auto;
          }
          .sidebar.open {
            left: 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
          }
        }
        .nav-link.active {
          background-color: #0d6efd;
          color: white !important;
          border-radius: 10px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .nav-link:hover {
          background-color: rgba(13,110,253,0.15);
          color: #0d6efd !important;
          border-radius: 10px;
          transition: background-color 0.2s ease, color 0.2s ease;
        }
      `}</style>
    </div>
  );
}
