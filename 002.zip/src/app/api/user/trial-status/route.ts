import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 })
    }

    // Fetch user profile
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()

    if (profileError) {
      console.error('Profile fetch error:', profileError)
      return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 })
    }

    // Fetch latest subscription (if any)
    const { data: subscription, error: subscriptionError } = await supabaseAdmin
      .from('user_packages')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (subscriptionError && subscriptionError.code !== 'PGRST116') { 
      // PGRST116 = no rows found
      console.error('Subscription fetch error:', subscriptionError)
    }

    // Calculate subscription activeness dynamically
    const now = new Date()
    const hasActiveSubscription = subscription?.expires_at
      ? new Date(subscription.expires_at) > now
      : false

    // Calculate trial status
    const createdAt = new Date(profile.created_at)
    const trialEndsAt = profile.trial_ends_at ? new Date(profile.trial_ends_at) : null

    // Default trial period: 7 days from signup
    const defaultTrialEndsAt = new Date(createdAt)
    defaultTrialEndsAt.setDate(defaultTrialEndsAt.getDate() + 7)
    
    const effectiveTrialEndsAt = trialEndsAt || defaultTrialEndsAt
    const daysRemaining = Math.max(
      0,
      Math.ceil((effectiveTrialEndsAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    )

    const isInTrialPeriod = daysRemaining > 0
    const isTrial = isInTrialPeriod && !hasActiveSubscription
    
    // Trial papers: 5 papers during trial
    const papersRemaining = isTrial
      ? Math.max(0, 5 - (profile.papers_generated || 0))
      : 0

    return NextResponse.json({
      isTrial,
      trialEndsAt: effectiveTrialEndsAt.toISOString(),
      daysRemaining,
      hasActiveSubscription,
      papersGenerated: profile.papers_generated || 0,
      papersRemaining,
      subscriptionStatus: hasActiveSubscription ? 'active' : 'inactive',
      subscriptionExpiresAt: subscription?.expires_at || null
    })
  } catch (error) {
    console.error('Server error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
