'use client';
import { useState, useEffect, useCallback, useMemo, useContext } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import { Class, Subject, Chapter, Question, paperType, Difficulty, QuestionType, ChapterOption, SelectionMethod } from '@/types/types';
//import { supabase } from "@/lib/supabaseClient";
import AcademyLayout from '@/components/AcademyLayout';
//import { useUser } from '@/contexts/UserContext';
import { useUser } from '@/app/context/userContext';
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

  const supabase = createClientComponentClient();
// Form validation schema
const paperSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  paperType: z.enum(['model', 'custom']),
  source_type: z.enum(['all', 'model_paper', 'past_paper', 'book']),
  classId: z.string().min(1, 'Class is required'),
  subjectId: z.string().min(1, 'Subject is required'),
  chapterOption: z.enum(['full_book', 'half_book', 'single_chapter', 'custom']),
  selectedChapters: z.array(z.string()).optional(),
  selectionMethod: z.enum(['auto', 'manual']),
  mcqCount: z.number().min(0),
  mcqDifficulty: z.enum(['easy', 'medium', 'hard', 'any']),
  shortCount: z.number().min(0),
  shortDifficulty: z.enum(['easy', 'medium', 'hard', 'any']),
  longCount: z.number().min(0),
  longDifficulty: z.enum(['easy', 'medium', 'hard', 'any']),
  easyPercent: z.number().min(0).max(100),
  mediumPercent: z.number().min(0).max(100),
  hardPercent: z.number().min(0).max(100),
  timeMinutes: z.number().min(1),
  mcqTimeMinutes: z.number().min(1).optional(),
  subjectiveTimeMinutes: z.number().min(1).optional(),
  language: z.enum(['english', 'urdu', 'bilingual']),
  mcqMarks: z.number().min(1),
  shortMarks: z.number().min(1),
  longMarks: z.number().min(1),
  mcqPlacement: z.enum(['same_page', 'separate']),
  mcqToAttempt: z.number().min(0).optional(),
  shortToAttempt: z.number().min(0).optional(),
  longToAttempt: z.number().min(0).optional(),
}).refine((data) => {
  if (data.mcqPlacement === 'separate') {
    return data.mcqTimeMinutes !== undefined && data.subjectiveTimeMinutes !== undefined;
  }
  return true;
}, {
  message: "Both objective and subjective time are required when MCQ placement is separate",
  path: ["mcqTimeMinutes"]
});

type PaperFormData = z.infer<typeof paperSchema>;

// Trial status interface
interface TrialStatus {
  isTrial: boolean;
  trialEndsAt: Date | null;
  daysRemaining: number;
  hasActiveSubscription: boolean;
  papersGenerated: number;
  papersRemaining: number;
}



// TrialStatusBanner component
const TrialStatusBanner = ({ trialStatus }: { trialStatus: TrialStatus | null }) => {
  if (!trialStatus) return null;

  if (trialStatus.hasActiveSubscription) {
    return (
      <div className="alert alert-success mb-4">
        <i className="bi bi-check-circle-fill me-2"></i>
        You have an active subscription. Enjoy unlimited paper generation!
      </div>
    );
  }

  if (trialStatus.isTrial) {
    return (
      <div className={`alert ${trialStatus.daysRemaining <= 2 ? 'alert-warning' : 'alert-info'} mb-4`}>
        <i className="bi bi-clock-history me-2"></i>
        Free Trial: {trialStatus.papersRemaining} paper(s) remaining, {trialStatus.daysRemaining} day(s) left
      </div>
    );
  }

  return (
    <div className="alert alert-danger mb-4">
      <i className="bi bi-exclamation-triangle-fill me-2"></i>
      Your free trial has ended. Please subscribe to continue generating papers.
    </div>
  );
};

// SubscriptionModal component
const SubscriptionModal = ({ 
  show, 
  onClose, 
  trialStatus 
}: { 
  show: boolean; 
  onClose: () => void; 
  trialStatus: TrialStatus | null;
}) => (
  <div className={`modal fade ${show ? 'show d-block' : ''}`} tabIndex={-1}>
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Subscription Required</h5>
          <button 
            type="button" 
            className="btn-close" 
            onClick={onClose}
          ></button>
        </div>
        <div className="modal-body">
          {trialStatus?.isTrial ? (
            <p>You have used all {trialStatus.papersGenerated} papers from your free trial.</p>
          ) : (
            <p>Your free trial has ended. Please subscribe to continue generating papers.</p>
          )}
          <div className="alert alert-info">
            <strong>Free Trial:</strong> 7 days with 5 papers
          </div>
        </div>
        <div className="modal-footer">
          <button 
            type="button" 
            className="btn btn-secondary" 
            onClick={onClose}
          >
            Later
          </button>
          <button 
            type="button" 
            className="btn btn-primary"
            onClick={() => {
              onClose();
              window.location.href = '/dashboard/packages';
            }}
          >
            View Package Plans
          </button>
        </div>
      </div>
    </div>
  </div>
);

interface ManualQuestionSelectionProps {
  subjectId: string;
  classId: string;
  chapterOption: ChapterOption;
  selectedChapters: string[];
  chapters: Chapter[];
  onQuestionsSelected: (questions: Record<QuestionType, string[]>) => void;
  mcqCount: number;
  shortCount: number;
  longCount: number;
  language: 'english' | 'urdu' | 'bilingual';
  source_type: string;
}

function ManualQuestionSelection({
  subjectId,
  classId,
  chapterOption,
  selectedChapters,
  chapters,
  onQuestionsSelected,
  mcqCount,
  shortCount,
  longCount,
  language,
  source_type,
}: ManualQuestionSelectionProps) {
  const [questions, setQuestions] = useState<Record<QuestionType, Question[]>>({
    mcq: [],
    short: [],
    long: [],
  });
  const [selected, setSelected] = useState<Record<QuestionType, string[]>>({
    mcq: [],
    short: [],
    long: [],
  });
  const [currentStep, setCurrentStep] = useState<QuestionType>('mcq');
  const [filters, setFilters] = useState({
    difficulty: 'all' as 'all' | Difficulty,
    chapter: 'all' as 'all' | string,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [requiredCounts, setRequiredCounts] = useState({
    mcq: mcqCount,
    short: shortCount,
    long: longCount
  });

  useEffect(() => {
    onQuestionsSelected(selected);
  }, [selected, onQuestionsSelected]);

  // Filter chapters by subject
  const subjectChapters = useMemo(() => {
    return chapters.filter(chapter => chapter.subject_id === subjectId);
  }, [chapters, subjectId]);

  // Determine which chapters to use based on chapterOption
  const getChapterIdsToUse = useCallback(() => {
    if (!subjectChapters || subjectChapters.length === 0) return [];
    
    if (chapterOption === 'full_book') {
      return subjectChapters.map(c => c.id);
    } else if (chapterOption === 'half_book') {
      // Get first half of chapters
      const halfIndex = Math.ceil(subjectChapters.length / 2);
      return subjectChapters.slice(0, halfIndex).map(c => c.id);
    } else if (chapterOption === 'single_chapter' || chapterOption === 'custom') {
      return selectedChapters || [];
    }
    return [];
  }, [chapterOption, subjectChapters, selectedChapters]);

  const fetchQuestions = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const chapterIds = getChapterIdsToUse();
      
      console.log('Fetching questions for subject:', subjectId, 'chapters:', chapterIds);
      
      // Only fetch questions if we have valid chapter IDs
      if (chapterIds.length === 0) {
        setQuestions({ mcq: [], short: [], long: [] });
        return;
      }

      const [mcqResponse, shortResponse, longResponse] = await Promise.all([
        axios.get(`/api/questions`, {
          params: {
            subjectId,
            classId: classId, // Pass class ID
            questionType: 'mcq',
            chapterIds: chapterIds.join(','),
            language,
            includeUrdu: language !== 'english',
            sourceType: source_type !== 'all' ? source_type : undefined
          },
        }),
        axios.get(`/api/questions`, {
          params: {
            subjectId,
            classId: classId, // Pass class ID
            questionType: 'short',
            chapterIds: chapterIds.join(','),
            language,
            includeUrdu: language !== 'english',
            sourceType: source_type !== 'all' ? source_type : undefined
          },
        }),
        axios.get(`/api/questions`, {
          params: {
            subjectId,
            classId: classId, // Pass class ID
            questionType: 'long',
            chapterIds: chapterIds.join(','),
            language,
            includeUrdu: language !== 'english',
            sourceType: source_type !== 'all' ? source_type : undefined
          },
        }),
      ]);

      const result = {
        mcq: mcqResponse.data,
        short: shortResponse.data,
        long: longResponse.data,
      };

      console.log('Questions fetched:', {
        mcq: result.mcq.length,
        short: result.short.length,
        long: result.long.length
      });

      // Use pre-translated content instead of Google Translate
      if (language !== 'english') {
        const isBi = language === 'bilingual';
        
        for (const type of ['mcq','short','long'] as QuestionType[]) {
          for (const q of result[type]) {
            if (q.question_text_ur) {
              q.question_text = isBi ? 
                `${q.question_text}\n(${q.question_text_ur})` : 
                q.question_text_ur;
            }
            
            if (type === 'mcq') {
              const options = ['option_a', 'option_b', 'option_c', 'option_d'];
              options.forEach(opt => {
                const urduField = `${opt}_ur`;
                if (q[urduField]) {
                  q[opt] = isBi ? 
                    `${q[opt]}\n(${q[urduField]})` : 
                    q[urduField];
                }
              });
            }
          }
        }
      }

      setQuestions(result);

    } catch (err) {
      console.error('Error fetching questions:', err);
      setError('Failed to load questions. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [subjectId, getChapterIdsToUse, language, source_type]);
  
  useEffect(() => {
    if (subjectId && subjectChapters && subjectChapters.length > 0) {
      console.log('Subject chapters available:', subjectChapters);
      fetchQuestions();
      setRequiredCounts({
        mcq: mcqCount,
        short: shortCount,
        long: longCount
      });
    }
  }, [subjectId, fetchQuestions, mcqCount, shortCount, longCount, subjectChapters]);

useEffect(() => {
  console.log('ManualQuestionSelection props:', {
    subjectId,
    chapterOption,
    selectedChapters,
    chapters: chapters.length,
    subjectChapters: subjectChapters.length,
    chapterIdsToUse: getChapterIdsToUse()
  });
}, [subjectId, chapterOption, selectedChapters, chapters, subjectChapters, getChapterIdsToUse]);
  // [toggleQuestionSelection, filteredQuestions, getCompletionStatus, etc.]
  const toggleQuestionSelection = useCallback((questionId: string, type: QuestionType) => {
    setSelected(prev => {
      const newSelected = { ...prev };
      if (newSelected[type].includes(questionId)) {
        newSelected[type] = newSelected[type].filter(id => id !== questionId);
      } else if (newSelected[type].length < requiredCounts[type]) {
        newSelected[type] = [...newSelected[type], questionId];
      }
      return newSelected;
    });
  }, [requiredCounts]);

  const filteredQuestions = useMemo(() => {
    return questions[currentStep].filter(q => {
      const matchesDifficulty = filters.difficulty === 'all' || q.difficulty === filters.difficulty;
      const matchesChapter = filters.chapter === 'all' || q.chapter_id === filters.chapter;
      return matchesDifficulty && matchesChapter;
    });
  }, [questions, currentStep, filters]);

  const getCompletionStatus = (type: QuestionType) => {
    const required = requiredCounts[type];
    const selectedCount = selected[type].length;
    return {
      completed: selectedCount >= required,
      progress: `${selectedCount}/${required}`,
      remaining: required - selectedCount
    };
  };

  const handleNext = () => {
    if (currentStep === 'mcq' && selected.mcq.length >= requiredCounts.mcq) {
      setCurrentStep('short');
    } else if (currentStep === 'short' && selected.short.length >= requiredCounts.short) {
      setCurrentStep('long');
    }
  };

  const handleBack = () => {
    if (currentStep === 'short') {
      setCurrentStep('mcq');
    } else if (currentStep === 'long') {
      setCurrentStep('short');
    }
  };

  // Get the actual chapter names for display
const getSelectedChapterNames = useCallback(() => {
  const chapterIds = getChapterIdsToUse();
  const subjectChapters = chapters.filter(c => c.subject_id === subjectId);

  if (chapterIds.length === 0) return "No chapters selected";
  if (chapterOption === 'full_book') return `${subjectChapters.length} chapters (Full Book)`;
  if (chapterOption === 'half_book') return `${Math.ceil(subjectChapters.length/2)} chapters (Half Book)`;

  return subjectChapters
    .filter(chapter => chapterIds.includes(chapter.id))
    .map(chapter => `${chapter.chapterNo}. ${chapter.name}`)
    .join(", ");
}, [getChapterIdsToUse, chapterOption, chapters, subjectId]);

  return (
    <div className="card mt-4">
      <div className="card-body">
        <h2 className="h4 card-title mb-3">Manual Question Selection</h2>
        
        {/* Chapter selection info */}
        <div className="alert alert-info mb-3">
          <strong>Selected Chapters:</strong> {getChapterIdsToUse().length} chapters
          {chapterOption === 'full_book' && ' (Full Book)'}
          {chapterOption === 'half_book' && ' (First Half)'}
          {chapterOption === 'single_chapter' && ' (Single Chapter)'}
          {chapterOption === 'custom' && ' (Custom Selection)'}
          <br />
          <small>{getSelectedChapterNames()}</small>
        </div>
        
        {/* Selection Summary at the top */}
        <div className="card bg-light mb-4">
          <div className="card-body">
            <h3 className="h6 card-title mb-3">Selection Progress</h3>
            <div className="row">
              <div className="col">
                <p className="fw-bold mb-1">MCQs</p>
                <div className="d-flex align-items-center">
                  <span className={`badge ${currentStep === 'mcq' ? 'bg-primary' : 
                                  getCompletionStatus('mcq').completed ? 'bg-success' : 'bg-secondary'} me-2`}>
                    {getCompletionStatus('mcq').progress}
                  </span>
                  {currentStep === 'mcq' && !getCompletionStatus('mcq').completed && (
                    <small className="text-muted">{getCompletionStatus('mcq').remaining} more needed</small>
                  )}
                </div>
              </div>
              <div className="col">
                <p className="fw-bold mb-1">Short Questions</p>
                <div className="d-flex align-items-center">
                  <span className={`badge ${currentStep === 'short' ? 'bg-primary' : 
                                  getCompletionStatus('short').completed ? 'bg-success' : 'bg-secondary'} me-2`}>
                    {getCompletionStatus('short').progress}
                  </span>
                  {currentStep === 'short' && !getCompletionStatus('short').completed && (
                    <small className="text-muted">{getCompletionStatus('short').remaining} more needed</small>
                  )}
                </div>
              </div>
              <div className="col">
                <p className="fw-bold mb-1">Long Questions</p>
                <div className="d-flex align-items-center">
                  <span className={`badge ${currentStep === 'long' ? 'bg-primary' : 
                                  getCompletionStatus('long').completed ? 'bg-success' : 'bg-secondary'} me-2`}>
                    {getCompletionStatus('long').progress}
                  </span>
                  {currentStep === 'long' && !getCompletionStatus('long').completed && (
                    <small className="text-muted">{getCompletionStatus('long').remaining} more needed</small>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="alert alert-danger mb-3" role="alert">
            {error}
          </div>
        )}

        {/* Current step indicator */}
        <div className="alert alert-info mb-4">
          {currentStep === 'mcq' && `Select ${requiredCounts.mcq} MCQs`}
          {currentStep === 'short' && `Select ${requiredCounts.short} Short Questions`}
          {currentStep === 'long' && `Select ${requiredCounts.long} Long Questions`}
        </div>
        
        {/* Filters */}
        <div className="row mb-4">
          <div className="col-md-6">
            <label className="form-label">Difficulty</label>
            <select
              className="form-select"
              value={filters.difficulty}
              onChange={(e) => setFilters(prev => ({ ...prev, difficulty: e.target.value as any }))}
            >
              <option value="all">All</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
          
          <div className="col-md-6">
            <label className="form-label">Chapter</label>
             <select
    className="form-select"
    value={filters.chapter}
    onChange={(e) => setFilters(prev => ({ ...prev, chapter: e.target.value }))}
  >
    <option value="all">All Chapters</option>
    {subjectChapters // Use subjectChapters instead of chapters
      .filter(chapter => getChapterIdsToUse().includes(chapter.id))
      .map(chapter => (
        <option key={chapter.id} value={chapter.id}>
          {chapter.chapterNo}. {chapter.name}
        </option>
      ))
    }
  </select>
          </div>
        </div>
        
        {isLoading ? (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-2">
              Showing {filteredQuestions.length} questions
              {filters.difficulty !== 'all' && ` (${filters.difficulty} difficulty)`}
              {filters.chapter !== 'all' && ` from chapter ${chapters.find(c => c.id === filters.chapter)?.chapterNo}`}
            </div>
            <div className="list-group mb-4" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {filteredQuestions.length === 0 ? (
                <div className="text-center py-4">
                  <p>No questions found matching your criteria.</p>
                  <p>Try adjusting your filters or chapter selection.</p>
                </div>
              ) : (
                filteredQuestions.map(question => (
                  <div
                    key={question.id}
                    className={`list-group-item list-group-item-action ${selected[currentStep].includes(question.id) ? 'active' : ''}`}
                    onClick={() => toggleQuestionSelection(question.id, currentStep)}
                  >
                    <div className="d-flex align-items-start">
                      <input
                        type="checkbox"
                        checked={selected[currentStep].includes(question.id)}
                        onChange={() => toggleQuestionSelection(question.id, currentStep)}
                        className="form-check-input me-3 mt-1"
                        onClick={(e) => e.stopPropagation()}
                        disabled={selected[currentStep].length >= requiredCounts[currentStep] && 
                                  !selected[currentStep].includes(question.id)}
                      />
                      <div>
                        <p className="mb-1 fw-bold">{question.question_text}</p>
                        {currentStep === 'mcq' && (
                          <div className="row mt-2">
                            {question.option_a && <div className="col-md-6">A) {question.option_a}</div>}
                            {question.option_b && <div className="col-md-6">B) {question.option_b}</div>}
                            {question.option_c && <div className="col-md-6">C) {question.option_c}</div>}
                            {question.option_d && <div className="col-md-6">D) {question.option_d}</div>}
                          </div>
                        )}
                        <div className="d-flex gap-2 mt-2">
                          <span className={`badge ${
                            question.difficulty === 'easy' ? 'bg-success' :
                            question.difficulty === 'medium' ? 'bg-warning text-dark' : 'bg-danger'
                          }`}>
                            {question.difficulty}
                          </span>
                         <span className="badge bg-secondary">
                                Chapter {subjectChapters.find(c => c.id === question.chapter_id)?.chapterNo}
                         </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </>
        )}

        <div className="d-flex justify-content-between">
          <button 
            className="btn btn-secondary" 
            onClick={handleBack}
            disabled={currentStep === 'mcq'}
          >
            Back
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleNext}
            disabled={selected[currentStep].length < requiredCounts[currentStep]}
          >
            {currentStep === 'long' ? 'Finish Selection' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
}
export default function GeneratePaperPage() {
  const [step, setStep] = useState(1);
  const [classes, setClasses] = useState<Class[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [selectedQuestions, setSelectedQuestions] = useState<Record<QuestionType, string[]>>({
    mcq: [],
    short: [],
    long: [],
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloadingKey, setIsDownloadingKey] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [isManualNavigation, setIsManualNavigation] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Use the UserContext
  const { trialStatus, isLoading: trialLoading, refreshTrialStatus } = useUser();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
    getValues,
    reset,
  } = useForm<PaperFormData>({
    resolver: zodResolver(paperSchema),
    defaultValues: {
      paperType: 'model',
      chapterOption: 'full_book',
      selectionMethod: 'auto',
      mcqCount: 10,
      mcqDifficulty: 'any',
      shortCount: 5,
      shortDifficulty: 'any',
      longCount: 3,
      longDifficulty: 'any',
      easyPercent: 33,
      mediumPercent: 33,
      hardPercent: 34,
      timeMinutes: 60,
      mcqTimeMinutes: 15,
      subjectiveTimeMinutes: 30,
      language: 'english',
      mcqMarks: 1,
      shortMarks: 2,
      longMarks: 5,
      mcqPlacement: 'separate',
      source_type: 'all',
      mcqToAttempt: 0,
      shortToAttempt: 0,
      longToAttempt: 0,
      title:'BISE LAHORE'
    },
  });

  const watchedClassId = watch('classId');
  const watchedSubjectId = watch('subjectId');
  const watchedChapterOption = watch('chapterOption');
  const watchedSelectionMethod = watch('selectionMethod');
  const watchedMcqCount = watch('mcqCount');
  const watchedShortCount = watch('shortCount');
  const watchedLongCount = watch('longCount');

  // Check authentication status
  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setIsAuthenticated(!!session);
    };
    checkAuth();
  }, []);

  // Check if user can generate paper
  const canGeneratePaper = () => {
    if (!trialStatus) return false;
    
    // Active subscription always allows generation
    if (trialStatus.hasActiveSubscription) return true;
    
    // Trial period: must have valid trial end date, days remaining AND papers remaining
    if (trialStatus.isTrial && 
        trialStatus.trialEndsAt &&
        trialStatus.trialEndsAt.getTime() > Date.now() && 
        trialStatus.papersRemaining > 0) {
      return true;
    }
    
    return false;
  };

  // Fetch classes on mount
  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await axios.get('/api/classes');
        setClasses(response.data);
      } catch (error) {
        console.error('Error fetching classes:', error);
      }
    };
    fetchClasses();
  }, []);

  // Fetch subjects when class changes
  useEffect(() => {
    const fetchSubjects = async () => {
      if (!watchedClassId) {
        setSubjects([]);
        return;
      }
      try {
        const response = await axios.get(`/api/subjects?classId=${watchedClassId}`);
        setSubjects(response.data);
      } catch (error) {
        console.error('Error fetching subjects:', error);
      }
    };
    fetchSubjects();
  }, [watchedClassId]);

  // Fetch chapters when subject changes
// Fetch chapters when subject changes
useEffect(() => {
  const fetchChapters = async () => {
    if (!watchedSubjectId || !watchedClassId) {
      setChapters([]);
      return;
    }
    try {
      console.log('Fetching chapters for subject:', watchedSubjectId, 'and class:', watchedClassId);
      const response = await axios.get(`/api/chapters?subjectId=${watchedSubjectId}&classId=${watchedClassId}`);
      console.log('Chapters response:', response.data);
      setChapters(response.data);
    } catch (error) {
      console.error('Error fetching chapters:', error);
    }
  };
  fetchChapters();
}, [watchedSubjectId, watchedClassId]); 
// Add watchedClassId dependency
  // Auto-advance steps when selections are made
  useEffect(() => {
    if (step === 1 && watchedClassId) {
      setStep(2);
    }
  }, [watchedClassId, step]);

  // Modify your auto-advance useEffect
  useEffect(() => {
    if (step === 2 && watchedSubjectId && !isManualNavigation) {
      setStep(3);
    }
  }, [watchedSubjectId, step, isManualNavigation]);

  // Enhanced back button functionality
  const prevStep = () => {
    if (step === 2) {
      setValue('classId', '');
      setValue('subjectId', '');
      setSubjects([]);
      setChapters([]);
      setStep(1);
    } else if (step === 3) {
      setIsManualNavigation(true);
      setValue('chapterOption', 'full_book');
      setValue('selectedChapters', []);
      setStep(2);
      
      // Reset the flag after a short delay
      setTimeout(() => {
        setIsManualNavigation(false);
      }, 1000);
    } else if (step === 4) {
      setStep(3);
    } else if (step === 5) {
      setStep(4);
    } else if (step === 6) {
      setStep(5);
    } else if (step === 7) {
      if (watchedSelectionMethod === 'manual') {
        setStep(6);
      } else {
        setStep(5);
      }
    }
  };

  // Final submit handler with trial check
  const onSubmit = async (formData: PaperFormData) => {
    // Check trial status before proceeding
    if (!canGeneratePaper()) {
      setShowSubscriptionModal(true);
      return;
    }

    // Check authentication
    if (!isAuthenticated) {
      alert('Please login to generate papers');
      return;
    }

    // If trial is active but papers are running out, show warning
    if (trialStatus?.isTrial && trialStatus.papersRemaining === 1) {
      if (!confirm(`This is your last paper in the free trial. Continue?`)) {
        return;
      }
    }

    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        alert('You must be logged in to generate a paper.');
        setIsLoading(false);
        return;
      }

      const user = session.user;
      const accessToken = session.access_token;
      const payload = {
        ...formData,
        userId: user.id,
        mcqToAttempt: formData.mcqToAttempt || formData.mcqCount,
        shortToAttempt: formData.shortToAttempt || formData.shortCount,
        longToAttempt: formData.longToAttempt || formData.longCount,
        ...(formData.selectionMethod === 'manual' ? { selectedQuestions } : {}),
        language: formData.language,
      };
      
      console.log('Submitting payload:', payload);
      
      const response = await fetch("/api/generate-paper", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${accessToken}`,
        },
        body: JSON.stringify(payload),
      });

      const contentType = response.headers.get("content-type") || "";

      console.log('Response status:', response.status);
      console.log('Content-Type:', contentType);
      
      // Update papers count after successful generation
      if (response.ok) {
        const { count: newPapersCount } = await supabase
          .from('papers')
          .select('*', { count: 'exact', head: true })
          .eq('created_by', user.id);

        // Refresh trial status to update the papers count
        await refreshTrialStatus();
      }
      
      if (response.ok && contentType.includes("application/pdf")) {
        console.log('Received PDF response, creating blob...');
        const blob = await response.blob();
        console.log('Blob created, size:', blob.size, 'bytes');
        const url = window.URL.createObjectURL(blob);
        console.log('Created object URL:', url);
        const a = document.createElement("a");
        a.href = url;
        a.download = "paper.pdf";
        document.body.appendChild(a);
        console.log('Triggering download...');
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        console.log('Download triggered');
      } else if (contentType.includes("application/json")) {
        console.log('Received JSON response');
        const result = await response.json();
        console.error('Error from server:', result.error);
        alert(result.error || "Paper generated, but no PDF was returned.");
      } else {
        console.log('Received unknown response type');
        const text = await response.text();
        console.error('Error text:', text);
        alert(text || "Failed to generate paper (unknown error)");
      }
    } catch (error) {
      console.error('Error generating paper:', error);
      alert("Failed to generate paper (client error)");
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    reset({
      paperType: 'model',
      chapterOption: 'full_book',
      selectionMethod: 'auto',
      mcqCount: 10,
      mcqDifficulty: 'any',
      shortCount: 5,
      shortDifficulty: 'any',
      longCount: 3,
      longDifficulty: 'any',
      easyPercent: 33,
      mediumPercent: 33,
      hardPercent: 34,
      timeMinutes: 60,
      language: 'english',
    });
    setSubjects([]);
    setChapters([]);
    setSelectedQuestions({
      mcq: [],
      short: [],
      long: [],
    });
  };

  const handleChapterSelection = (chapterId: string) => {
    if (watchedChapterOption === 'single_chapter') {
      setValue('selectedChapters', [chapterId]);
      setStep(4);
    } else if (watchedChapterOption === 'custom') {
      const currentSelected = watch('selectedChapters') || [];
      if (currentSelected.includes(chapterId)) {
        setValue('selectedChapters', currentSelected.filter(id => id !== chapterId));
      } else {
        setValue('selectedChapters', [...currentSelected, chapterId]);
      }
    } else if (watchedChapterOption === 'full_book' || watchedChapterOption === 'half_book') {
      setStep(4);
    }
  };

  return (
    <AcademyLayout>
      <div className="container mx-auto px-4 py-4">
        {/* Show loading state while trial status is being fetched */}
        {trialLoading && (
          <div className="alert alert-info mb-4">
            <div className="spinner-border spinner-border-sm me-2" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            Loading your account information...
          </div>
        )}

        {/* Add Trial Status Banner */}
        <TrialStatusBanner trialStatus={trialStatus} />
        
        {/* Add Subscription Modal */}
        {showSubscriptionModal && (
          <>
            <div className="modal-backdrop fade show"></div>
            <SubscriptionModal 
              show={showSubscriptionModal} 
              onClose={() => setShowSubscriptionModal(false)}
              trialStatus={trialStatus}
            />
          </>
        )}

        {/* Login prompt for unauthenticated users */}
        {!isAuthenticated && (
          <div className="alert alert-warning mb-4">
            <i className="bi bi-exclamation-triangle me-2"></i>
            Please <a href="/login" className="alert-link">login</a> to generate papers.
          </div>
        )}

        {/* Disable form if trial expired and no subscription or not authenticated */}
        <div style={{ 
          opacity: canGeneratePaper() && isAuthenticated ? 1 : 0.6,
          pointerEvents: canGeneratePaper() && isAuthenticated ? 'auto' : 'none'
        }}>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1 className="h2 mb-0">Generate New Paper</h1>
            {step > 1 && (
              <button className="btn btn-outline-secondary" onClick={prevStep}>
                <i className="bi bi-arrow-left me-2"></i>
                {step === 2 && 'Back to Class Selection'}
                {step === 3 && 'Back to Subject Selection'}
                {step === 4 && 'Back to Chapter Selection'}
                {step === 5 && 'Back to Paper Details'}
                {step === 6 && 'Back to Selection Method'}
                {step === 7 && 'Back'}
              </button>
            )}
          </div>

          {/* Step 1: Class selection */}
          {step === 1 && (
            <div>
              <label className="form-label">Select Class</label>
              {classes.length === 0 && (
                <div className="text-center py-4">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading classes...</span>
                  </div>
                  <p className="mt-2">Loading classes...</p>
                </div>
              )}
           
              <div className="row row-cols-2 row-cols-md-4 g-4">
                {classes.map(cls => (
                  <div key={cls.id} className="col">
                    <div 
                      className={`card h-100 cursor-pointer p-3 border ${watchedClassId === cls.id ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                      onClick={() => setValue('classId', cls.id)}
                    >
                      <div className="card-body text-center">
                        <span className="display-6 mb-2">🎓</span>
                        <h5 className="card-title">Class {cls.name}</h5>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {errors.classId && (
                <div className="text-danger small mt-1">{errors.classId.message}</div>
              )}
            </div>
          )}

          {/* Step 2: Subject selection */}
          {step === 2 && (
            <div>
                <label className="form-label">Select Subject</label>
              {watchedClassId && subjects.length === 0 && (
                <div className="text-center py-4">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading subjects...</span>
                  </div>
                  <p className="mt-2">Loading subjects...</p>
                </div>
              )}
            
              <div className="row row-cols-2 row-cols-md-4 g-4">
                {subjects.map(subject => (
                  <div key={subject.id} className="col">
                    <div 
                      className={`card h-100 cursor-pointer p-3 border ${watchedSubjectId === subject.id ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                      onClick={() => setValue('subjectId', subject.id)}
                    >
                      <div className="card-body text-center">
                        <span className="display-6 mb-2">📚</span>
                        <h5 className="card-title">{subject.name}</h5>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {errors.subjectId && (
                <div className="text-danger small mt-1">{errors.subjectId.message}</div>
              )}
            </div>
          )}

          {/* Step 3: Chapter selection */}
        
{step === 3 && (
  <div>
    <label className="form-label">Select Chapter Coverage</label>
   <div className="row row-cols-1 row-cols-md-2 g-4 mb-4">
      <div className="col">
        <div className={`card h-100 cursor-pointer p-3 border ${watchedChapterOption === 'full_book' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
          onClick={() => {
            setValue('chapterOption', 'full_book');
            setValue('selectedChapters', []);
            setStep(4); 
          }}
        >
          <div className="card-body text-center">
            <span className="display-6 mb-2">📖</span>
            <h5 className="card-title">Full Book</h5>
            <p className="card-text">Cover all chapters in the subject</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div 
          className={`card h-100 cursor-pointer p-3 border ${watchedChapterOption === 'half_book' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
          onClick={() => {
            setValue('chapterOption', 'half_book');
            setValue('selectedChapters', []);
            setStep(4); 
          }}
        >
          <div className="card-body text-center">
            <span className="display-6 mb-2">📘</span>
            <h5 className="card-title">Half Book</h5>
            <p className="card-text">Cover first half of the chapters</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div 
          className={`card h-100 cursor-pointer p-3 border ${watchedChapterOption === 'single_chapter' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
          onClick={() => setValue('chapterOption', 'single_chapter')}
        >
          <div className="card-body text-center">
            <span className="display-6 mb-2">📄</span>
            <h5 className="card-title">Single Chapter</h5>
            <p className="card-text">Select one specific chapter</p>
          </div>
        </div>
      </div>
      <div className="col">
        <div 
          className={`card h-100 cursor-pointer p-3 border ${watchedChapterOption === 'custom' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
          onClick={() => setValue('chapterOption', 'custom')}
        >
          <div className="card-body text-center">
            <span className="display-6 mb-2">🎛️</span>
            <h5 className="card-title">Custom Selection</h5>
            <p className="card-text">Choose multiple chapters</p>
          </div>
        </div>
      </div>
    </div>

    {(watchedChapterOption === 'custom' || watchedChapterOption === 'single_chapter') && (
      <>
        <label className="form-label">
          {watchedChapterOption === 'single_chapter' ? 'Select Chapter' : 'Select Chapters'}
        </label>
        
        {/* Show loading state while chapters are loading */}
        {chapters.length === 0 && (
          <div className="text-center py-4">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading chapters...</span>
            </div>
            <p className="mt-2">Loading chapters...</p>
          </div>
        )}
        
        {/* Show message if no chapters found for this subject */}
        {chapters.length > 0 && chapters.filter(chapter => chapter.subject_id === watchedSubjectId).length === 0 && (
          <div className="alert alert-warning">
            No chapters found for the selected subject.
          </div>
        )}
        
        <div className="row row-cols-2 row-cols-md-4 g-4">
          {/* Filter chapters by selected subject */}
          {chapters
            .filter(chapter => chapter.subject_id === watchedSubjectId)
            .map(chapter => {
              const selectedChapters = watch('selectedChapters') || [];
              const isSelected = selectedChapters.includes(chapter.id);
              return (
                <div key={chapter.id} className="col">
                  <div
                    className={`card h-100 cursor-pointer p-3 border ${isSelected ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                    onClick={() => handleChapterSelection(chapter.id)}
                  >
                    <div className="card-body text-center">
                      <span className="display-6 mb-2">📖</span>
                      <h5 className="card-title">{chapter.chapterNo}. {chapter.name}</h5>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
        
        {watchedChapterOption === 'custom' && (
          <button 
            className="btn btn-primary mt-3"
            onClick={() => setStep(4)}
            disabled={!watch('selectedChapters')?.length}
          >
            Continue
          </button>
        )}
      </>
    )}
  </div>
)}
          {/* Step 4: Paper details and settings */}
          {step === 4 && (
            <div>
              <div className="mb-4">
                <label className="form-label">Paper Type Selection</label>
                <div className="row row-cols-1 row-cols-md-2 g-4">
                  <div className="col">
                    <div 
                      className={`card h-100 cursor-pointer p-3 border ${watch('paperType') === 'model' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                      onClick={() => {
                        setValue('paperType', 'model');
                        setValue('language', 'bilingual');
                        // Set values for Board Paper pattern
                        setValue('mcqCount', 12);
                        setValue('mcqToAttempt', 12); // All MCQs to attempt
                        setValue('shortCount', 24);
                        setValue('shortToAttempt', 16); // 4 from each section (4 sections × 4 questions)
                        setValue('longCount', 3);
                        setValue('longToAttempt', 2); // Attempt any 2 out of 3
                        setValue('mcqMarks', 1);
                        setValue('shortMarks', 2);
                        setValue('longMarks', 8);
                        setValue('mcqPlacement', 'separate');
                        setValue('timeMinutes', 180);
                        setValue('easyPercent', 20);
                        setValue('mediumPercent', 50);
                        setValue('hardPercent', 30);
                      }}
                    >
                      <div className="card-body text-center">
                        <span className="display-6 mb-2">🏛️</span>
                        <h5 className="card-title">Board Paper Pattern</h5>
                        <p className="card-text">
                          Standard board pattern: 12 MCQs (1 mark each), 24 short questions 
                          (4 sections of 6 questions, 2 marks each), 3 long questions (8 marks each)
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col">
                    <div 
                      className={`card h-100 cursor-pointer p-3 border ${watch('paperType') === 'custom' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                      onClick={() => {
                        setValue('paperType', 'custom');
                        // Reset to default values for custom selection
                        setValue('mcqCount', 10);
                        setValue('shortCount', 5);
                        setValue('longCount', 3);
                        setValue('mcqMarks', 1);
                        setValue('shortMarks', 2);
                        setValue('longMarks', 5);
                        setValue('mcqPlacement', 'separate');
                        setValue('timeMinutes', 60);
                        setValue('easyPercent', 33);
                        setValue('mediumPercent', 34);
                        setValue('hardPercent', 33);
                      }}
                    >
                      <div className="card-body text-center">
                        <span className="display-6 mb-2">⚙️</span>
                        <h5 className="card-title">Custom Paper</h5>
                        <p className="card-text">Customize all settings including marks per question, placement, and difficulty</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Show settings only for custom paper type */}
              {watch('paperType') === 'custom' && (
                <>
                  <div className="mb-3">
                    <label className="form-label">Paper Title</label>
                    <input
                      type="text"
                      defaultValue="BISE LAHORE"
                      {...register('title')}
                      className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                      placeholder="Enter paper title"
                    />
                    {errors.title && (
                      <div className="invalid-feedback">{errors.title.message}</div>
                    )}
                  </div>
                  
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label className="form-label d-block">Language</label>
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="radio"
                          value="english"
                          {...register('language')}
                          id="langEnglish"
                        />
                        <label className="form-check-label" htmlFor="langEnglish">English</label>
                      </div>
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="radio"
                          value="urdu"
                          {...register('language')}
                          id="langUrdu"
                        />
                        <label className="form-check-label" htmlFor="langUrdu">Urdu</label>
                      </div>
                      <div className="form-check form-check-inline">
                        <input
                          className="form-check-input"
                          type="radio"
                          value="bilingual"
                          {...register('language')}
                          id="langBilingual"
                        />
                        <label className="form-check-label" htmlFor="langBilingual">Bilingual</label>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Source Type</label>
                      <select
                        {...register('source_type')}
                        className="form-select"
                      >
                        <option value="all">All</option>
                        <option value="book">Book Questions</option>
                        <option value="model_paper">Model Paper Questions</option>
                        <option value="past_paper">Past Paper Questions</option>
                      </select>
                      <small className="form-text text-muted">
                        Select "All" to include questions from all sources
                      </small>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label className="form-label">MCQ Placement</label>
                      <select
                        {...register('mcqPlacement')}
                        className="form-select"
                      >
                        <option value="same_page">On the same page</option>
                        <option value="separate">Separate page</option>
                      </select>
                    </div>

                    <div className="col-md-6">
                      {watch('mcqPlacement') === 'separate' ? (
                        <div className="row">
                          <div className="col">
                            <label className="form-label">Objective Time (minutes)</label>
                            <input
                              type="number"
                              {...register('mcqTimeMinutes', { valueAsNumber: true })}
                              className="form-control"
                              min="1"
                            />
                          </div>
                          <div className="col">
                            <label className="form-label">Subjective Time (minutes)</label>
                            <input
                              type="number"
                              {...register('subjectiveTimeMinutes', { valueAsNumber: true })}
                              className="form-control"
                              min="1"
                            />
                          </div>
                        </div>
                      ) : (
                        <>
                          <label className="form-label">Exam Time (minutes)</label>
                          <input
                            type="number"
                            {...register('timeMinutes', { valueAsNumber: true })}
                            className="form-control"
                            min="1"
                          />
                        </>
                      )}
                      {errors.mcqTimeMinutes && (
                        <div className="text-danger small mt-1">{errors.mcqTimeMinutes.message}</div>
                      )}
                    </div>
                  </div>

                  <div className="card mb-4">
                    <div className="card-body">
                      <h2 className="h5 card-title mb-3">Question Distribution</h2>
                      
                      <div className="row mb-3 align-items-center">
                        <label className="col-sm-2 col-form-label">MCQs:Attempts:Marks</label>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('mcqCount', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="Total"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('mcqToAttempt', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="To Attempt"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('mcqMarks', { valueAsNumber: true })}
                            className="form-control"
                            min="1"
                            placeholder="Marks each"
                          />
                        </div>
                        <div className="col-sm-3">
                          <select
                            {...register('mcqDifficulty')}
                            className="form-select"
                          >
                            <option value="any">Any Difficulty</option>
                            <option value="easy">Easy</option>
                            <option value="medium">Medium</option>
                            <option value="hard">Hard</option>
                          </select>
                        </div>
                      </div>
                      
                      <div className="row mb-3 align-items-center">
                        <label className="col-sm-2 col-form-label">Short Questions:Attempts:Marks</label>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('shortCount', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="Total"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('shortToAttempt', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="To Attempt"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('shortMarks', { valueAsNumber: true })}
                            className="form-control"
                            min="1"
                            placeholder="Marks each"
                          />
                        </div>
                        <div className="col-sm-3">
                          <select
                            {...register('shortDifficulty')}
                            className="form-select"
                          >
                            <option value="any">Any Difficulty</option>
                            <option value="easy">Easy</option>
                            <option value="medium">Medium</option>
                            <option value="hard">Hard</option>
                          </select>
                        </div>
                      </div>
                      
                      <div className="row align-items-center">
                        <label className="col-sm-2 col-form-label">Long Questions::Attempts:Marks</label>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('longCount', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="Total"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('longToAttempt', { valueAsNumber: true })}
                            className="form-control"
                            min="0"
                            placeholder="To Attempt"
                          />
                        </div>
                        <div className="col-sm-2">
                          <input
                            type="number"
                            {...register('longMarks', { valueAsNumber: true })}
                            className="form-control"
                            min="1"
                            placeholder="Marks each"
                          />
                        </div>
                        <div className="col-sm-3">
                          <select
                            {...register('longDifficulty')}
                            className="form-select"
                          >
                            <option value="any">Any Difficulty</option>
                            <option value="easy">Easy</option>
                            <option value="medium">Medium</option>
                            <option value="hard">Hard</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col">
                      <label className="form-label">Easy %</label>
                      <input
                        type="number"
                        {...register('easyPercent', { valueAsNumber: true })}
                        className="form-control"
                        min="0"
                        max="100"
                      />
                    </div>
                    <div className="col">
                      <label className="form-label">Medium %</label>
                      <input
                        type="number"
                        {...register('mediumPercent', { valueAsNumber: true })}
                        className="form-control"
                        min="0"
                        max="100"
                      />
                    </div>
                    <div className="col">
                      <label className="form-label">Hard %</label>
                      <input
                        type="number"
                        {...register('hardPercent', { valueAsNumber: true })}
                        className="form-control"
                        min="0"
                        max="100"
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Show summary for board paper type */}
              {watch('paperType') === 'model' && (
                <div className="card mb-4">
                  <div className="card-body">
                    <h2 className="h5 card-title mb-3">Board Paper Pattern Settings</h2>
                    <div className="row">
                      <div className="col-md-6">
                        <p><strong>Language:</strong> Bilingual (English + Urdu)</p>
                        <p><strong>MCQs:</strong> 12 questions (1 mark each)</p>
                        <p><strong>Short Questions:</strong> 24 questions divided into 4 sections and 16 to attempt</p>
                      </div>
                      <div className="col-md-6">
                        <p><strong>Long Questions:</strong> 3 questions (8 marks each, attempt any 2)</p>
                        <p><strong>Exam Time:</strong> 180 minutes (3 hours)</p>
                        <p><strong>Difficulty:</strong> 20% Easy, 50% Medium, 30% Hard</p>
                      </div>
                    </div>
                    <div className="mt-3 p-3 bg-light rounded">
                      <h6 className="fw-bold">Short Questions Structure:</h6>
                      <ul className="mb-0">
                        <li>4 sections with 6 questions each</li>
                        <li>Each question carries 2 marks</li>
                        <li>Attempt any 4 questions from each section</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-3">
                <button className="btn btn-primary" onClick={() => setStep(5)}>
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 5: Selection method */}
          {step === 5 && (
            <div>
              <label className="form-label">Question Selection Method</label>
              <div className="row row-cols-1 row-cols-md-2 g-4">
                <div className="col">
                  <div 
                    className={`card h-100 cursor-pointer p-3 border ${watchedSelectionMethod === 'auto' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                    onClick={() => {
                      setValue('selectionMethod', 'auto');
                      setStep(7);
                    }}
                  >
                    <div className="card-body text-center">
                      <span className="display-6 mb-2">🤖</span>
                      <h5 className="card-title">Auto Generate</h5>
                      <p className="card-text">System will automatically select questions based on your criteria</p>
                    </div>
                  </div>
                </div>
                <div className="col">
                  <div 
                    className={`card h-100 cursor-pointer p-3 border ${watchedSelectionMethod === 'manual' ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'}`}
                    onClick={() => {
                      setValue('selectionMethod', 'manual');
                      setStep(6);
                    }}
                  >
                    <div className="card-body text-center">
                      <span className="display-6 mb-2">✍️</span>
                      <h5 className="card-title">Manual Selection</h5>
                      <p className="card-text">You will manually select each question</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 6: Manual Question Selection */}
          {step === 6 && watchedSelectionMethod === 'manual' && (
            <div>
              <ManualQuestionSelection
                subjectId={watchedSubjectId}

                chapterOption={watchedChapterOption}
                 classId={watchedClassId} 
                selectedChapters={watch('selectedChapters') || []}
                chapters={chapters}
                onQuestionsSelected={setSelectedQuestions}
                mcqCount={Number(watchedMcqCount)}
                shortCount={Number(watchedShortCount)}
                longCount={Number(watchedLongCount)}
                language={watch('language')}
                source_type={watch('source_type')}
              />
              <div className="mt-3">
                <button className="btn btn-primary" onClick={() => setStep(7)}>
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 7: Review and Generate */}
          {step === 7 && (
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="card mb-4">
                <div className="card-body">
                  <h2 className="h5 card-title mb-3">Paper Summary</h2>
                  <div className="row">
                    <div className="col-md-6">
                      <p><strong>Title:</strong> {watch('title')}</p>
                      <p><strong>Class:</strong> {classes.find(c => c.id === watch('classId'))?.name}</p>
                      <p><strong>Subject:</strong> {subjects.find(s => s.id === watch('subjectId'))?.name}</p>
                      <p><strong>Paper Type:</strong> {watch('paperType')}</p>
                      <p><strong>Language:</strong> {watch('language')}</p>
                    </div>
                    <div className="col-md-6">
                      <p><strong>Chapter Coverage:</strong> {watch('chapterOption')}</p>
                      <p><strong>Selection Method:</strong> {watch('selectionMethod')}</p>
                      <p><strong>Exam Time:</strong> {watch('timeMinutes')} minutes</p>
                      <p><strong>Difficulty Distribution:</strong> Easy {watch('easyPercent')}%, Medium {watch('mediumPercent')}%, Hard {watch('hardPercent')}%</p>
                    </div>
                  </div>

                  <div className="mt-3">
                    <h3 className="h6">Question Counts & Marks</h3>
                    <ul className="list-group">
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        MCQs
                        <span className="badge bg-primary rounded-pill">
                          {watch('mcqCount') || 0} questions ({watch('mcqToAttempt') || watch('mcqCount') || 0} to attempt) × {watch('mcqMarks') || 0} marks each
                        </span>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        Short Questions
                        <span className="badge bg-primary rounded-pill">
                          {watch('shortCount') || 0} questions ({watch('shortToAttempt') || watch('shortCount') || 0} to attempt) × {watch('shortMarks') || 0} marks each
                        </span>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        Long Questions
                        <span className="badge bg-primary rounded-pill">
                          {watch('longCount') || 0} questions ({watch('longToAttempt') || watch('longCount') || 0} to attempt) × {watch('longMarks') || 0} marks each
                        </span>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center">
                        <strong>Total Marks</strong>
                        <span className="badge bg-success rounded-pill">
                          {(watch('mcqToAttempt') || watch('mcqCount') || 0) * (watch('mcqMarks') || 0) + 
                          (watch('shortToAttempt') || watch('shortCount') || 0) * (watch('shortMarks') || 0) + 
                          (watch('longToAttempt') || watch('longCount') || 0) * (watch('longMarks') || 0)} marks
                        </span>
                      </li>
                    </ul>
                  </div>

                  <div className="mt-3">
                    <p><strong>MCQ Placement:</strong> {watch('mcqPlacement') === 'separate' ? 'Separate page' : 'Same page as other questions'}</p>
                  </div>
                </div>
              </div>

              <div className="d-flex gap-2 flex-wrap">
                <button 
                  className="btn btn-success" 
                  type="submit" 
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Generating...
                    </>
                  ) : 'Generate Paper'}
                </button>

                <button
                  className="btn btn-info text-white"
                  type="button"
                  onClick={async () => {
                    setIsDownloadingKey(true);
                    try {
                      const { data: { session } } = await supabase.auth.getSession();
                      if (!session) {
                        alert('You must be logged in to download the MCQ key.');
                        return;
                      }

                      // Get the current form values
                      const formValues = getValues();
                      const method = formValues.selectionMethod;
                      
                      // Prepare payload with the same parameters used for paper generation
                      const payload = {
                        subjectId: watchedSubjectId,
                        selectedChapters: formValues.selectedChapters || [],
                        mcqCount: formValues.mcqCount,
                        selectionMethod: method,
                        chapterOption: formValues.chapterOption,
                        paperTitle: formValues.title,
                        mcqDifficulty: formValues.mcqDifficulty,
                        sourceType: formValues.source_type,
                        difficultyDistribution: {
                          easy: formValues.easyPercent,
                          medium: formValues.mediumPercent,
                          hard: formValues.hardPercent
                        },
                        // For manual selection, pass the exact question IDs
                        selectedQuestions: method === "manual" ? selectedQuestions : undefined
                      };

                      const response = await fetch("/api/generate-mcq-key", {
                        method: "POST",
                        headers: {
                          "Content-Type": "application/json",
                          "Authorization": `Bearer ${session.access_token}`,
                        },
                        body: JSON.stringify(payload),
                      });

                      if (response.ok) {
                        const blob = await response.blob();
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `${payload.paperTitle.replace(/[^a-z0-9]/gi, '_')}-key.pdf`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        window.URL.revokeObjectURL(url);
                      } else {
                        // Try to get error message from JSON response
                        try {
                          const err = await response.json();
                          alert("Failed: " + (err.message || 'Unknown error'));
                        } catch {
                          alert("Failed to generate answer key");
                        }
                      }
                    } catch (error) {
                      console.error("Error downloading MCQ key:", error);
                      alert("Failed to download MCQ key.");
                    } finally {
                      setIsDownloadingKey(false);
                    }
                  }}
                  disabled={isLoading || isDownloadingKey || watchedMcqCount === 0}
                >
                  {isDownloadingKey ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Downloading Key...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-key me-2"></i> Download MCQ Key
                    </>
                  )}
                </button>
                <button 
                  className="btn btn-outline-primary" 
                  type="button" 
                  onClick={resetForm}
                  disabled={isLoading}
                >
                  Generate New Paper
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Show upgrade prompt if trial expired */}
        {!canGeneratePaper() && trialStatus && isAuthenticated && (
          <div className="card mt-4">
            <div className="card-body text-center">
              <h3 className="card-title">Upgrade to Continue</h3>
              <p className="card-text">
                {trialStatus.papersGenerated >= 5 
                  ? "You've used all 5 papers from your free trial." 
                  : "Your free trial has ended."
                } Subscribe to unlock unlimited paper generation.
              </p>
              <button 
                className="btn btn-primary btn-lg"
                onClick={() => window.location.href = '/academy/packages'}
              >
                View Subscription Plans
              </button>
            </div>
          </div>
        )}
      </div>
    </AcademyLayout>
  );
}