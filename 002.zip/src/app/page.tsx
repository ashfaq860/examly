'use client';
import { useState, useEffect, useRef } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import ThemeMode from '@/components/themeMode';
export default function Home() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [darkMode, setDarkMode] = useState(false);
  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Check for user's preferred color scheme
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isDark = localStorage.getItem('darkMode') === 'true' || 
                    (!localStorage.getItem('darkMode') && 
                    window.matchMedia('(prefers-color-scheme: dark)').matches);
      setDarkMode(isDark);
    }
  }, []);

  // Apply dark mode class to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const slides = [
    {
      title: "Smart Paper Generation for Educators",
      description: "Create perfect exam papers in minutes with AI-assisted question selection",
      image: "/educator-hero.jpg",
      cta: "Try Generator Now",
      link: "/generate-papers",
      bgClass: "bg-educator"
    },
    {
      title: "Comprehensive Exam Preparation",
      description: "10,000+ curriculum-aligned questions with detailed solutions",
      image: "/student-hero.jpg",
      cta: "Start Practicing",
      link: "/student-quizzes",
      bgClass: "bg-student"
    },
    {
      title: "Professional Career Test Prep",
      description: "Specialized question banks for CSS, PMS, PPSC and other competitive exams",
      image: "/career-hero.jpg",
      cta: "Explore Career Tests",
      link: "/career-exams",
      bgClass: "bg-career"
    }
  ];

  // Auto-rotate slides every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Scroll animation effect
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fadeInUp');
        }
      });
    }, {
      threshold: 0.1
    });

    sectionRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => {
      sectionRefs.current.forEach((ref) => {
        if (ref) observer.unobserve(ref);
      });
    };
  }, []);

  const nextSlide = () => {
    setActiveSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setActiveSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <>
      <Header darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
      
      {/* Enhanced Hero Slider */}
      <div className="hero-slider-container position-relative">
        <div className="hero-slider-track" style={{ transform: `translateX(-${activeSlide * 100}%)` }}>
          {slides.map((slide, index) => (
            <div key={index} className={`hero-slide ${slide.bgClass}`}>
              <div className="container h-100">
                <div className="row align-items-center h-100">
                  <div className="col-lg-6 text-white">
                    <h1 className="display-3 fw-bold mb-4">{slide.title}</h1>
                    <p className="lead mb-4">{slide.description}</p>
                    <Link href={slide.link} className="btn btn-light btn-lg px-4 py-3 rounded-pill shadow">
                      {slide.cta} <i className="bi bi-arrow-right ms-2"></i>
                    </Link>
                  </div>
                  <div className="col-lg-6 d-none d-lg-block">
                    <img src={slide.image} alt={slide.title} className="img-fluid slide-image" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Slider Arrows */}
        <button className="slider-arrow slider-prev" onClick={prevSlide}>
          <i className="bi bi-chevron-left"></i>
        </button>
        <button className="slider-arrow slider-next" onClick={nextSlide}>
          <i className="bi bi-chevron-right"></i>
        </button>
        
        {/* Slider Indicators */}
        <div className="slider-indicators">
          {slides.map((_, index) => (
            <button 
              key={index}
              className={activeSlide === index ? "active" : ""}
              onClick={() => setActiveSlide(index)}
            />
          ))}
        </div>
      </div>

      {/* Enhanced Paper Generation Tools */}
      <section 
        ref={el => sectionRefs.current[0] = el}
        className="py-5 bg-white dark:bg-gray-900 opacity-0 transition-all duration-500"
      >
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="display-5 fw-bold text-primary dark:text-primary-300">Advanced Paper Generation</h2>
            <p className="lead text-muted dark:text-gray-300">Professional tools with complete customization</p>
          </div>

          <div className="row g-4">
            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/chapter-papers.jpg" alt="Chapter-wise Papers" className="feature-image" />
                  <div className="image-overlay bg-primary"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Chapter-wise Tests</h3>
                  <ul className="text-muted dark:text-gray-300 mb-4">
                    <li>Full chapter or half chapter tests</li>
                    <li>Topic-wise question selection</li>
                    <li>Difficulty level control</li>
                  </ul>
                  <Link href="/generate/chapter-wise" className="btn btn-outline-primary dark:border-primary-300 dark:text-primary-300 dark:hover:bg-primary-300 dark:hover:text-gray-900">
                    Try Now
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/custom-papers.jpg" alt="Custom Papers" className="feature-image" />
                  <div className="image-overlay bg-primary"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Custom Paper Builder</h3>
                  <ul className="text-muted dark:text-gray-300 mb-4">
                    <li>Manually pick questions</li>
                    <li>Multiple question types</li>
                    <li>Save papers for future use</li>
                  </ul>
                  <Link href="/generate/custom" className="btn btn-outline-primary dark:border-primary-300 dark:text-primary-300 dark:hover:bg-primary-300 dark:hover:text-gray-900">
                    Create
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/random-papers.jpg" alt="Random Papers" className="feature-image" />
                  <div className="image-overlay bg-primary"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Randomized Papers</h3>
                  <ul className="text-muted dark:text-gray-300 mb-4">
                    <li>Unique papers for each student</li>
                    <li>Question shuffling</li>
                    <li>Answer key generation</li>
                  </ul>
                  <Link href="/generate/random" className="btn btn-outline-primary dark:border-primary-300 dark:text-primary-300 dark:hover:bg-primary-300 dark:hover:text-gray-900">
                    Generate
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Student Exam Preparation */}
      <section 
        ref={el => sectionRefs.current[1] = el}
        className="py-5 bg-light dark:bg-gray-800 opacity-0 transition-all duration-500"
      >
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="display-5 fw-bold text-success dark:text-success-300">Student Exam Preparation</h2>
            <p className="lead text-muted dark:text-gray-300">Practice with intelligent quizzes and track progress</p>
          </div>

          <div className="row g-4">
            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-700 dark:border-gray-600">
                <div className="card-img-top feature-image-container">
                  <img src="/chapter-quiz.jpg" alt="Chapter Tests" className="feature-image" />
                  <div className="image-overlay bg-success"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Chapter Tests</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Focused quizzes on specific topics and concepts
                  </p>
                  <Link href="/quiz/chapter-tests" className="btn btn-outline-success dark:border-success-300 dark:text-success-300 dark:hover:bg-success-300 dark:hover:text-gray-900">
                    Start Now
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-700 dark:border-gray-600">
                <div className="card-img-top feature-image-container">
                  <img src="/mock-exam.jpg" alt="Mock Exams" className="feature-image" />
                  <div className="image-overlay bg-success"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Mock Exams</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Full-length timed tests simulating real exam conditions
                  </p>
                  <Link href="/quiz/mock-exams" className="btn btn-outline-success dark:border-success-300 dark:text-success-300 dark:hover:bg-success-300 dark:hover:text-gray-900">
                    Try Exam
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-700 dark:border-gray-600">
                <div className="card-img-top feature-image-container">
                  <img src="/performance-analytics.jpg" alt="Performance Analytics" className="feature-image" />
                  <div className="image-overlay bg-success"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Performance Analytics</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Detailed reports on strengths and areas for improvement
                  </p>
                  <Link href="/quiz/analytics" className="btn btn-outline-success dark:border-success-300 dark:text-success-300 dark:hover:bg-success-300 dark:hover:text-gray-900">
                    View Dashboard
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Career Exam Preparation */}
      <section 
        ref={el => sectionRefs.current[2] = el}
        className="py-5 bg-white dark:bg-gray-900 opacity-0 transition-all duration-500"
      >
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="display-5 fw-bold text-warning dark:text-warning-300">Career Exam Preparation</h2>
            <p className="lead text-muted dark:text-gray-300">Specialized tests for professional certifications and jobs</p>
          </div>

          <div className="row g-4">
            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/css-test.jpg" alt="CSS/PMS Tests" className="feature-image" />
                  <div className="image-overlay bg-warning"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">CSS/PMS Tests</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Comprehensive preparation for civil service examinations
                  </p>
                  <Link href="/career/css-tests" className="btn btn-outline-warning dark:border-warning-300 dark:text-warning-300 dark:hover:bg-warning-300 dark:hover:text-gray-900">
                    Start Prep
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/banking-test.jpg" alt="Banking Exams" className="feature-image" />
                  <div className="image-overlay bg-warning"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Banking Exams</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Practice tests for IBPS, NTS, and other banking exams
                  </p>
                  <Link href="/career/banking-tests" className="btn btn-outline-warning dark:border-warning-300 dark:text-warning-300 dark:hover:bg-warning-300 dark:hover:text-gray-900">
                    Take Tests
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100 border-0 overflow-hidden shadow-sm dark:bg-gray-800 dark:border-gray-700">
                <div className="card-img-top feature-image-container">
                  <img src="/teaching-test.jpg" alt="Teaching Exams" className="feature-image" />
                  <div className="image-overlay bg-warning"></div>
                </div>
                <div className="card-body p-4">
                  <h3 className="fw-bold mb-3 dark:text-white">Teaching Exams</h3>
                  <p className="text-muted dark:text-gray-300 mb-4">
                    Subject-specific tests for educator positions
                  </p>
                  <Link href="/career/teaching-tests" className="btn btn-outline-warning dark:border-warning-300 dark:text-warning-300 dark:hover:bg-warning-300 dark:hover:text-gray-900">
                    Browse Tests
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Unified CTA */}
      <section 
        ref={el => sectionRefs.current[3] = el}
        className="py-5 bg-dark dark:bg-gray-950 text-white opacity-0 transition-all duration-500"
      >
        <div className="container text-center">
          <h2 className="display-5 fw-bold mb-4">Ready to Get Started?</h2>
          <div className="d-flex justify-content-center gap-3 flex-wrap">
            <Link href="/auth/signup?role=teacher" className="btn btn-primary btn-lg px-4 py-3 dark:bg-primary-600 dark:hover:bg-primary-700">
              I'm an Educator
            </Link>
            <Link href="/auth/signup?role=student" className="btn btn-success btn-lg px-4 py-3 dark:bg-success-600 dark:hover:bg-success-700">
              I'm a Student
            </Link>
            <Link href="/auth/signup?role=career" className="btn btn-warning btn-lg px-4 py-3 dark:bg-warning-600 dark:hover:bg-warning-700">
              Career Preparation
            </Link>
          </div>
        </div>
      </section>

      <Footer darkMode={darkMode} />

      <style jsx>{`
        /* Enhanced Slider Styles */
        .hero-slider-container {
          position: relative;
          overflow: hidden;
          height: 500px;
        }
        .hero-slider-track {
          display: flex;
          transition: transform 0.5s cubic-bezier(0.645, 0.045, 0.355, 1);
          height: 100%;
        }
        .hero-slide {
          min-width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          position: relative;
        }
        .bg-educator {
          background: linear-gradient(135deg, #3a7bd5 0%, #00d2ff 100%);
        }
        .bg-student {
          background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);
        }
        .bg-career {
          background: linear-gradient(135deg, #f46b45 0%, #eea849 100%);
        }
        .slide-image {
          border-radius: 1rem;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          animation: float 6s cubic-bezier(0.37, 0, 0.63, 1) infinite;
        }
        
        /* Slider Navigation */
        .slider-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 50px;
          height: 50px;
          background: rgba(255,255,255,0.2);
          border: none;
          border-radius: 50%;
          color: white;
          font-size: 1.5rem;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          z-index: 10;
        }
        .slider-arrow:hover {
          background: rgba(255,255,255,0.3);
          transform: translateY(-50%) scale(1.1);
        }
        .slider-prev {
          left: 20px;
        }
        .slider-next {
          right: 20px;
        }
        
        /* Slider Indicators */
        .slider-indicators {
          position: absolute;
          bottom: 20px;
          left: 0;
          right: 0;
          display: flex;
          justify-content: center;
          gap: 10px;
          z-index: 10;
        }
        .slider-indicators button {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          border: none;
          background: rgba(255,255,255,0.5);
          padding: 0;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .slider-indicators button.active {
          background: white;
          transform: scale(1.2);
        }
        
        /* Feature Cards */
        .feature-card {
          transition: all 0.3s ease;
          border-radius: 0.5rem;
        }
        .feature-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1) !important;
        }
        .feature-image-container {
          height: 200px;
          position: relative;
          overflow: hidden;
        }
        .feature-image {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.5s ease;
        }
        .feature-card:hover .feature-image {
          transform: scale(1.05);
        }
        .image-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          opacity: 0.1;
        }

        /* Scroll Animation */
        .animate-fadeInUp {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
        
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
          100% { transform: translateY(0px); }
        }
      `}</style>

      <style jsx global>{`
        /* Global styles for scroll animation */
        section {
          transform: translateY(20px);
        }

        /* Dark mode transitions */
        html {
          transition: background-color 0.3s ease, color 0.3s ease;
        }
        
        body {
          background-color: white;
          color: #212529;
          transition: background-color 0.3s ease, color 0.3s ease;
        }
        
        body.dark {
          background-color: #111827;
          color: #f3f4f6;
        }
        
        /* Dark mode text colors */
        .dark .text-muted {
          color: #9ca3af !important;
        }
        
        /* Dark mode card styles */
        .dark .card {
          background-color: #1f2937;
          border-color: #374151;
        }
        
        /* Dark mode button outlines */
        .dark .btn-outline-primary {
          color: #93c5fd;
          border-color: #93c5fd;
        }
        
        .dark .btn-outline-success {
          color: #86efac;
          border-color: #86efac;
        }
        
        .dark .btn-outline-warning {
          color: #fcd34d;
          border-color: #fcd34d;
        }
      `}</style>
    </>
  );
}