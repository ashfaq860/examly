'use client';

import { useParams } from 'next/navigation';
import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function QuizPage() {
  const params = useParams();
  const { classId, subject } = params;

  const questions = [
    {
      id: 1,
      question: `Sample question 1 for class ${classId} ${subject}`,
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctIndex: 0,
    },
    {
      id: 2,
      question: `Sample question 2 for class ${classId} ${subject}`,
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctIndex: 2,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  function handleSelectOption(index: number) {
    setSelectedOption(index);
  }

  function handleNext() {
    if (selectedOption === null) return;

    if (selectedOption === questions[currentIndex].correctIndex) {
      setScore(score + 1);
    }

    setSelectedOption(null);

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setShowResult(true);
    }
  }

  return (
    <>
      <Header />
      <main className="container py-5">
        <h2 className="mb-4">
          Quiz: Class {classId} -{' '}
          {subject.charAt(0).toUpperCase() + subject.slice(1)}
        </h2>

        {!showResult ? (
          <div className="card p-4 shadow-sm" style={{ borderRadius: 12 }}>
            <p>
              <strong>
                Question {currentIndex + 1} of {questions.length}:
              </strong>{' '}
              {questions[currentIndex].question}
            </p>

            <div className="list-group">
              {questions[currentIndex].options.map((option, idx) => (
                <button
                  key={idx}
                  className={`list-group-item list-group-item-action ${
                    selectedOption === idx ? 'active' : ''
                  }`}
                  onClick={() => handleSelectOption(idx)}
                >
                  {option}
                </button>
              ))}
            </div>

            <button
              className="btn btn-primary mt-3"
              disabled={selectedOption === null}
              onClick={handleNext}
            >
              {currentIndex + 1 === questions.length ? 'Finish' : 'Next'}
            </button>
          </div>
        ) : (
          <div className="alert alert-success">
            Quiz completed! Your score: {score} / {questions.length}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
