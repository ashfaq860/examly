'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Header from '@/components/academy/Header';
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { useUser } from '@/app/context/userContext';

export default function AcademyLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { trialStatus, isLoading } = useUser();
  const supabase = createClientComponentClient();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
    }
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-mode');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const isActive = (path: string) => pathname?.startsWith(path);

  // Get data from context
  const daysRemaining = trialStatus?.daysRemaining ?? 0;
  const hasActiveSubscription = trialStatus?.hasActiveSubscription ?? false;
  const subscriptionName = trialStatus?.subscriptionName || 'Premium';
  const subscriptionType = trialStatus?.subscriptionType;
  const subscriptionEndDate = trialStatus?.subscriptionEndDate;
  const papersRemaining = trialStatus?.papersRemaining ?? 0;
  const isShowingExpiredSubscription = trialStatus?.isShowingExpiredSubscription ?? false;

  // Format subscription end date
  const formatDate = (date: Date | null | undefined) => {
    if (!date) return 'N/A';
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className={`d-flex ${darkMode ? 'bg-dark text-light' : 'bg-light text-dark'}`} style={{ minHeight: '100vh' }}>
      {/* Sidebar Overlay for Mobile */}
      {sidebarOpen && (
        <div 
          className="d-lg-none position-fixed w-100 h-100"
          style={{ 
            backgroundColor: 'rgba(0,0,0,0.5)', 
            zIndex: 999, 
            top: 0, 
            left: 0 
          }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div 
        className={`sidebar d-flex flex-column flex-shrink-0 p-3 shadow-sm ${sidebarOpen ? 'open' : ''}`}
        style={{ 
          width: '260px',
          zIndex: 1000,
          backgroundColor: darkMode ? '#212529' : '#fff'
        }}
      >
        <div className="d-flex justify-content-between align-items-center mb-3">
          <Link 
            href="/dashboard" 
            className="text-decoration-none fs-5 fw-bold text-primary"
            onClick={() => setSidebarOpen(false)}
          >
            <i className="bi bi-mortarboard me-2"></i> Dashboard
          </Link>
          <button 
            className="btn btn-close d-lg-none"
            onClick={() => setSidebarOpen(false)}
          />
        </div>
        <hr />
        <ul className="nav nav-pills flex-column gap-2">
          <li>
            <Link 
              href="/dashboard" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-speedometer2 me-2"></i> Dashboard
            </Link>
          </li>
          
          <li>
            <Link 
              href="/dashboard/generate-paper" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/generate-paper') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-file-earmark-text me-2"></i> Generate Paper
            </Link>
          </li>
          <li>
            <Link 
              href="/dashboard/profile" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/profile') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-person me-2"></i> Profile
            </Link>
          </li>
          <li>
            <Link 
              href="/dashboard/settings" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/settings') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-gear me-2"></i> Settings
            </Link>
          </li>
           <li>
            <Link 
              href="/dashboard/packages" 
              className={`nav-link d-flex align-items-center ${isActive('/dashboard/packages') ? 'active' : 'text-secondary'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-box-seam me-2"></i> Best Packages
            </Link>
          </li>
        </ul>
        <hr />
        
        {/* Subscription Status Section */}
        {isLoading ? (
          <div className="alert alert-info text-center small shadow-sm">
            <div className="spinner-border spinner-border-sm" role="status">
              <span className="visually-hidden">Loading subscription info...</span>
            </div>
          </div>
        ) : hasActiveSubscription ? (
          /* Active Subscription Info */
          <div className="alert alert-success text-center small shadow-sm">
            <div className="d-flex align-items-center justify-content-center mb-2">
              <i className="bi bi-patch-check-fill me-2"></i>
              <strong>{subscriptionName}</strong>
            </div>
            
            {subscriptionType === 'paper_pack' ? (
              <>
                <div className="mb-2">
                  <i className="bi bi-file-text me-1"></i>
                  {papersRemaining} paper{papersRemaining !== 1 ? 's' : ''} remaining
                </div>
                {subscriptionEndDate && (
                  <div className="mb-2">
                    <i className="bi bi-calendar me-1"></i>
                    Expires: {formatDate(subscriptionEndDate)}
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="mb-2">
                  <i className="bi bi-infinity me-1"></i>
                  Unlimited paper generation
                </div>
                {subscriptionEndDate && (
                  <div className="mb-2">
                    <i className="bi bi-arrow-repeat me-1"></i>
                    Renews: {formatDate(subscriptionEndDate)}
                  </div>
                )}
              </>
            )}
            
            <Link 
              href="/dashboard/profile" 
              className="btn btn-sm btn-outline-success w-100 mt-2 shadow-sm rounded-pill"
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-gear me-1"></i> Manage Account
            </Link>
          </div>
        ) : isShowingExpiredSubscription ? (
          /* Expired Subscription Info */
          <div className="alert alert-warning text-center small shadow-sm">
            <div className="d-flex align-items-center justify-content-center mb-2">
              <i className="bi bi-exclamation-triangle me-2"></i>
              <strong>Expired: {subscriptionName}</strong>
            </div>
            
            <div className="mb-2">
              <i className="bi bi-file-text me-1"></i>
              {papersRemaining} paper{papersRemaining !== 1 ? 's' : ''} used
            </div>
            
            {subscriptionEndDate && (
              <div className="mb-2">
                <i className="bi bi-calendar-x me-1"></i>
                Expired: {formatDate(subscriptionEndDate)}
              </div>
            )}
            
            <Link 
              href="/dashboard/packages" 
              className="btn btn-sm btn-warning w-100 mt-2 shadow-sm rounded-pill"
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-arrow-repeat me-1"></i> Renew Now
            </Link>
          </div>
        ) : (
          /* Trial Period Info */
          <div className="alert alert-info text-center small shadow-sm">
            <div className="d-flex align-items-center justify-content-center mb-2">
              <i className="bi bi-clock-history me-2"></i>
              <strong>Free Trial</strong>
            </div>
            
            <div className="mb-2">
              <i className="bi bi-file-text me-1"></i>
              {papersRemaining} paper{papersRemaining !== 1 ? 's' : ''} remaining
            </div>
            
            <div className="mb-2">
              <i className="bi bi-calendar me-1"></i>
              {daysRemaining} day{daysRemaining !== 1 ? 's' : ''} left
            </div>
            
            <Link 
              href="/dashboard/packages" 
              className="btn btn-sm btn-primary w-100 mt-2 shadow-sm rounded-pill"
              onClick={() => setSidebarOpen(false)}
            >
              <i className="bi bi-arrow-up-circle me-1"></i> Upgrade Now
            </Link>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 d-flex flex-column">
        <Header 
          darkMode={darkMode} 
          setDarkMode={setDarkMode} 
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        <main className="flex-grow-1 p-3">
          {children}
        </main>
      </div>
    </div>
  );
}