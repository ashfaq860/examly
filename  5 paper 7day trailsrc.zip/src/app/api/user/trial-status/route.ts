// src/app/api/user/trial-status/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    // --- Fetch user profile ---
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (profileError || !profile) {
      console.error('Profile fetch error:', profileError);
      return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 });
    }

    // --- Fetch latest active subscription ---
    const { data: activeSubscription, error: subscriptionError } = await supabaseAdmin
      .from('user_packages')
      .select(
        `
        *,
        package:packages (
          name,
          type,
          paper_quantity,
          duration_days
        )
      `
      )
      .eq('user_id', userId)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .maybeSingle();

    if (subscriptionError && subscriptionError.code !== 'PGRST116') {
      console.error('Subscription fetch error:', subscriptionError);
      return NextResponse.json({ error: 'Failed to fetch subscription' }, { status: 500 });
    }

    // --- Check subscription validity ---
    const now = new Date();
    let hasValidActiveSubscription = false;

    if (activeSubscription) {
      const isNotExpired = activeSubscription.expires_at
        ? new Date(activeSubscription.expires_at) > now
        : true;

      const hasPapersRemaining =
        activeSubscription.package?.type === 'paper_pack'
          ? activeSubscription.papers_remaining !== null &&
            activeSubscription.papers_remaining > 0
          : true; // unlimited for subs

      hasValidActiveSubscription = isNotExpired && hasPapersRemaining;
    }

    // --- Trial calculation ---
    const createdAt = new Date(profile.created_at);
    const trialEndsAt = profile.trial_ends_at
      ? new Date(profile.trial_ends_at)
      : (() => {
          const d = new Date(createdAt);
          d.setDate(d.getDate() + 7); // default trial = 7 days
          return d;
        })();

    const daysRemaining = Math.max(
      0,
      Math.ceil((trialEndsAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    );

    const isTrial = daysRemaining > 0 && !hasValidActiveSubscription;

    // --- Papers remaining ---
    let papersRemaining = 0;
    if (hasValidActiveSubscription) {
      if (activeSubscription.package?.type === 'paper_pack') {
        papersRemaining = activeSubscription.papers_remaining || 0;
      } else {
        papersRemaining = Infinity;
      }
    } else if (isTrial) {
      papersRemaining = Math.max(0, 5 - (profile.papers_generated || 0));
    }

    // --- Response ---
    return NextResponse.json({
      isTrial,
      trialEndsAt: trialEndsAt.toISOString(),
      daysRemaining,
      hasActiveSubscription: hasValidActiveSubscription,
      papersGenerated: profile.papers_generated || 0,
      papersRemaining,
      subscriptionStatus: hasValidActiveSubscription ? 'active' : 'inactive',
      subscriptionExpiresAt: activeSubscription?.expires_at || null,
      subscriptionName: activeSubscription?.package?.name || null,
      subscriptionType: activeSubscription?.package?.type || null,
      subscriptionEndDate: activeSubscription?.expires_at
        ? new Date(activeSubscription.expires_at)
        : null,
    });
  } catch (error: any) {
    console.error('Trial status route hard fail:', error.message || error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
