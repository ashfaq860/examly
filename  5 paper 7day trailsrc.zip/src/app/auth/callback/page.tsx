// app/auth/callback/page.tsx
'use client';
import { useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import toast from 'react-hot-toast';

export default function AuthCallback() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const access_token = searchParams.get('access_token');
    if (access_token) {
      // Supabase handles this automatically, but you can fetch session if needed
      supabase.auth.getSession().then(({ data }) => {
        console.log("Session after confirmation:", data);
        toast.success("Email confirmed! Welcome 🎉");
        router.push('/dashboard'); // redirect wherever you like
      });
    }
  }, [router, searchParams]);

  return <p>Completing sign-in…</p>;
}

